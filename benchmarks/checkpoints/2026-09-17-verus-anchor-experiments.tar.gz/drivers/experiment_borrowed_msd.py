#!/usr/bin/env python3
"""Try reading cached bit lengths under the existing lock, without changing root sources."""
import hashlib,json,os,shutil,subprocess,time
from pathlib import Path
Q=Path(__file__).resolve().parent;S=Q/'source';O=Q/'borrowed-msd-experiment';O.mkdir()
C=json.loads((Q/'run.json').read_text());REV='c61d6d876d30be92faa038d1ad9fe657e241fe0c';E=C['environment']|{'CARGO_BUILD_JOBS':'4','CARGO_NET_OFFLINE':'true','CCACHE_DISABLE':'1'}
assert not subprocess.check_output(['git','status','--porcelain'],cwd=S,text=True)
original=subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip();records=[];binaries={}
paths=['src/computable/node/representation.rs','src/computable/node/approximation_queries.rs']
def replace_once(text,before,after):
 assert text.count(before)==1,before
 return text.replace(before,after)
def run(name,command,artifact=False,cwd=S):
 start=time.time()
 with (O/(name+'.stdout')).open('w') as out,(O/(name+'.stderr')).open('w') as err:r=subprocess.run(command,cwd=cwd,env=os.environ|E,stdout=out,stderr=err)
 records.append({'step':name,'command':command,'cwd':str(cwd),'environment':E,'exit_code':r.returncode,'seconds':time.time()-start,'native_timing':False});(O/'runs.json').write_text(json.dumps(records,indent=2)+'\n');print(name,r.returncode,round(time.time()-start,1),flush=True)
 if r.returncode:raise RuntimeError(name+' failed')
 if artifact:
  for line in (O/(name+'.stdout')).read_text().splitlines():
   a=json.loads(line)
   if a.get('reason')=='compiler-artifact' and a.get('executable') and a['target']['kind'] in [['bench'],['example']]:
    source=Path(a['executable']);dest=O/'bin'/a['target']['name'];shutil.copy2(source,dest);binaries[dest.name]={'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'bytes':dest.stat().st_size,'features':a['features'],'target':a['target']}
  (O/'binaries.json').write_text(json.dumps(binaries,indent=2)+'\n')
try:
 subprocess.run(['git','checkout','--detach',REV],cwd=S,check=True)
 p=S/paths[0];text=p.read_text()
 text=replace_once(text,'    pub(crate) fn cached_value(&self) -> Option<(Precision, BigInt)> {','    pub(crate) fn cached_magnitude_bits(&self) -> Option<(Precision, u64)> {\n        self.cache.magnitude_bits()\n    }\n\n    pub(crate) fn cached_value(&self) -> Option<(Precision, BigInt)> {')
 text=replace_once(text,'    fn get(&self) -> Option<(Precision, BigInt)> {','    fn magnitude_bits(&self) -> Option<(Precision, u64)> {\n        let guard = self.cell()?.read().unwrap_or_else(|error| error.into_inner());\n        let cached = guard.as_ref()?;\n        Some((cached.precision, cached.value.magnitude().bits()))\n    }\n\n    fn get(&self) -> Option<(Precision, BigInt)> {')
 p.write_text(text)
 p=S/paths[1];text=p.read_text()
 text=replace_once(text,'if let Some((prec, appr)) = self.cached() {\n            crate::verified::word::checked_bit_length_msd(appr.magnitude().bits(), 1, false, prec)','if let Some((prec, bits)) = self.internal.cached_magnitude_bits() {\n            crate::verified::word::checked_bit_length_msd(bits, 1, false, prec)')
 text=replace_once(text,'let cache = self.cached();\n        let mut try_once = false;','let cache = self.internal.cached_magnitude_bits();\n        let mut try_once = false;')
 text=replace_once(text,'} else if let Some((_prec, appr)) = cache {\n            let one = signed::ONE.deref();\n            let minus_one = signed::MINUS_ONE.deref();','} else if let Some((_prec, bits)) = cache {')
 text=replace_once(text,'            if appr >= *minus_one && appr <= *one {\n                try_once = true;','            if bits <= 1 {\n                try_once = true;')
 p.write_text(text)
 (O/'change.patch').write_bytes(subprocess.check_output(['git','diff','--',*paths],cwd=S))
 names=subprocess.check_output(['git','ls-files','-z','src','tests','benches','Cargo.toml','Cargo.lock'],cwd=S,text=True).split('\0')
 (O/'inputs.json').write_text(json.dumps({'base_revision':REV,'baseline':C['baseline'],'compiler':C['compiler'],'environment':E,'files':{n:hashlib.sha256((S/n).read_bytes()).hexdigest() for n in names if n},'status':'isolated_experiment_not_adopted','purpose':'Avoid cloning cached BigInts when only their precision and magnitude bit length are read. Existing two-read control flow and zero-separation threshold are retained.'},indent=2)+'\n')
 for n in paths:p=O/'overlay'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((S/n).read_bytes())
 (O/'bin').mkdir()
 run('all-feature-tests',['cargo','test','--locked','--all-features','--lib','--tests'])
 run('clippy',['cargo','clippy','--locked','--all-features','--all-targets','--','-D','warnings'])
 run('bench-build',['cargo','bench','--locked','--features','simple','--benches','--no-run','--message-format=json'],True)
 run('allocation-build',['cargo','build','--locked','--release','--all-features','--example','allocation_profile','--message-format=json'],True)
 run('allocations',[str(O/'bin/allocation_profile'),'64'],cwd=O)
finally:
 subprocess.run(['git','restore','--',*paths],cwd=S,check=True)
 subprocess.run(['git','checkout','--detach',original],cwd=S,check=True)
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=S,text=True)
 (O/'restoration.json').write_text(json.dumps({'revision':original,'clean':True},indent=2)+'\n')
