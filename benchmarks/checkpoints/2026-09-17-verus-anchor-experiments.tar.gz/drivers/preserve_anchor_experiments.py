#!/usr/bin/env python3
"""Retain all allocation experiments, their qualification, and unresolved memory growth."""
import gzip,hashlib,io,json,re,tarfile
from pathlib import Path
Q=Path(__file__).resolve().parent;R=Path('/home/tim/Documents/GitHub/workspace/hyperreal');D=R/'benchmarks/checkpoints';folders=['borrowed-msd-experiment','certified-anchor-experiment','certified-anchor-v2'];summary={}
for name in folders:
 p=Q/name;runs=json.loads((p/'runs.json').read_text());assert all(r['exit_code']==0 for r in runs)
 assert len(runs)==(15 if name=='certified-anchor-v2' else 5)
 summary[name]={'inputs':json.loads((p/'inputs.json').read_text()),'runs':runs,'restoration':json.loads((p/'restoration.json').read_text())}
v2=Q/folders[-1];fuzz=[r for r in summary[folders[-1]]['runs'] if r['step'].startswith('fuzz-')];assert len(fuzz)==6 and sum(r['corpus_files'] for r in fuzz)==6492
counts={}
for name in ['default-all-targets','all-feature-all-targets']:
 s=(v2/(name+'.stdout')).read_text();matches=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',s);assert matches
 counts[name]={'passed':sum(int(m[0]) for m in matches),'ignored':sum(int(m[2]) for m in matches),'criterion_fixture_successes':sum(line=='Success' for line in s.splitlines())}
profiles=json.loads((v2/'profiles/runs.json').read_text());assert len(profiles)==10 and all(r['exit_code']==0 for r in profiles)
alloc=json.loads((v2/'profiles/allocations.json').read_text());assert len(alloc['rows'])==20
assert all(r['experiment_minus_baseline'][k]<=0 for r in alloc['rows'] for k in ['allocations','reallocations','allocated_bytes','peak_live_delta_bytes','retained_bytes'])
massif=json.loads((v2/'profiles/matched-massif.json').read_text());assert [r['maxima']['combined_peak'] for r in massif['rows'] if r['label']=='experiment']==[24968,24968]
callgrind={label:int(re.search(r'^summary: (\d+)$',(v2/'profiles'/label/'callgrind.out').read_text(),re.M)[1]) for label in ['baseline','experiment']}
files=[];excluded=[]
for folder in folders:
 for p in (Q/folder).rglob('*'):
  if not p.is_file() or 'corpus' in p.relative_to(Q/folder).parts:continue
  with p.open('rb') as f:magic=f.read(4)
  if magic in [b'\x7fELF',b'\x00asm']:excluded.append({'path':str(p.relative_to(Q)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
  else:files.append((p,str(p.relative_to(Q))))
p=Q/'anchor-experiment-executables.json';p.write_text(json.dumps(excluded,indent=2)+'\n');files.append((p,p.name))
for n in ['experiment_borrowed_msd.py','experiment_certified_anchor.py','qualify_certified_anchor_v2.py','profile_certified_anchor_v2.py','preserve_anchor_experiments.py']:files.append((Q/n,'drivers/'+n))
archive=D/'2026-09-17-verus-anchor-experiments.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as tar:
   for p,n in sorted(files,key=lambda r:r[1]):
    data=p.read_bytes();info=tarfile.TarInfo(n);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
report={'schema':1,'status':'isolated_experiments_not_adopted_or_accepted','baseline':'a2da8e2b5de9a1a4653d3662f2f05cb6533fd7ef','production_base':'c61d6d876d30be92faa038d1ad9fe657e241fe0c',
 'experiments':summary,'v2_validation_counts':counts,'v2_resources':{'allocations':alloc,'massif':massif,'callgrind_instructions':callgrind,'memcheck_errors':0},
 'method':'Read cached magnitude bits under the existing lock without copying BigInt, then select one available certified multiplication anchor before requesting the other operand at its required precision. Original coarse/overflow fallback is retained. Version2 also preserves shared-constant cache routing; earlier variants examined only node caches and are not adopted.',
 'limits':['All runtime changes are isolated overlays; current committed production remains c61d6d8.','All20 per-representation allocation/byte/peak/retained measurements are at or below baseline, but whole-process combined peak remains72bytes higher in both matched pairs (24896 versus24968). It was328bytes higher for committed c61d6d8. Heap and allocator-overhead maxima increase independently; every component is recorded.','Matched aggregate Callgrind counts decrease but do not establish native or per-workload performance parity. Native timings and final consumer/size/coverage qualification remain pending.','Fuzz runs replay6492 previously frozen inputs underASan; LSan remains disabled for the observed ptrace limitation. They do not prove arbitrary-input correctness.','Full graph, cache ownership, precision-range and dependency refinement proofs remain incomplete.','Executable bytes remain frozen in temporary storage with archived hashes. Frozen corpus bytes are in the existing2026-09-17-verus-corpora.tar.gz checkpoint.'],
 'artifact':{'path':str(archive.relative_to(R)),'files':len(files),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}}
(D/'2026-09-17-verus-anchor-experiments.json').write_text(json.dumps(report,indent=2)+'\n');print(report['artifact']);print(counts);print(callgrind)
