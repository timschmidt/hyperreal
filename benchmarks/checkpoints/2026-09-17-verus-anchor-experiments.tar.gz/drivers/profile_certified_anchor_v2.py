#!/usr/bin/env python3
"""Measure frozen prototype resource usage, without treating profiler time as native speed."""
import csv,hashlib,json,os,re,shutil,subprocess,time
from pathlib import Path
Q=Path(__file__).resolve().parent;B=Q/'certified-anchor-v2';O=B/'profiles';O.mkdir();C=json.loads((Q/'run.json').read_text());E=C['environment']
records=json.loads((B/'runs.json').read_text());assert len(records)==15 and all(r['exit_code']==0 for r in records);assert (B/'restoration.json').is_file()
RUNTIME=Q/'metadata-profile-runtime';RUNTIME.mkdir(exist_ok=True);EXE=RUNTIME/'allocation_profile';PROFILE=RUNTIME/'massif.out';runs=[];rows=[]
binaries={'baseline':Q/'baseline/bin/allocation_profile','committed':Q/'bound-composition-complete/bin/allocation_profile','experiment':B/'bin/allocation_profile'}
for pair in [1,2]:
 for label in (['baseline','committed','experiment'] if pair==1 else ['experiment','committed','baseline']):
  folder=O/str(pair)/label;folder.mkdir(parents=True);shutil.copy2(binaries[label],EXE)
  cmd=['valgrind','--tool=massif','--stacks=yes','--time-unit=B','--detailed-freq=1000','--max-snapshots=100','--peak-inaccuracy=0','--threshold=100.0','--depth=1','--massif-out-file='+str(PROFILE),str(EXE),'64'];start=time.time()
  with (folder/'stdout').open('w') as out,(folder/'stderr').open('w') as err:r=subprocess.run(cmd,cwd=RUNTIME,env=os.environ|E,stdout=out,stderr=err)
  if PROFILE.exists():PROFILE.rename(folder/'massif.out')
  digest=hashlib.sha256(EXE.read_bytes()).hexdigest()
  runs.append({'pair':pair,'label':label,'command':cmd,'cwd':str(RUNTIME),'environment':E,'exit_code':r.returncode,'seconds':time.time()-start,'native_timing':False,'binary_sha256':digest});(O/'runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(pair,label,r.returncode,round(time.time()-start,1),flush=True)
  assert r.returncode==0
  raw=(folder/'massif.out').read_text();values=[dict((k,int(v)) for k,v in re.findall(r'^(mem_heap_B|mem_heap_extra_B|mem_stacks_B)=(\d+)$',snap,re.M)) for snap in raw.split('snapshot=')[1:]]
  assert values and all(len(v)==3 for v in values)
  rows.append({'pair':pair,'label':label,'binary_sha256':digest,'profile_sha256':hashlib.sha256((folder/'massif.out').read_bytes()).hexdigest(),'maxima':{**{k:max(v[k] for v in values) for k in values[0]},'combined_peak':max(sum(v.values()) for v in values)}})
(O/'matched-massif.json').write_text(json.dumps({'rows':rows,'method':'Same executable/argv/cwd/environment, forward/reverse three-variant pairs, zero peak inaccuracy, heap and stack enabled.','native_timing':False},indent=2)+'\n')
def read_alloc(path):
 with path.open() as f:return {r['representation']:{k:int(v) for k,v in r.items() if k!='representation'} for r in csv.DictReader(f)}
# All profiles use the same 64-iteration workload; parse its emitted allocation counters as a cross-check.
alloc={label:read_alloc(O/'1'/label/'stdout') for label in binaries};assert all(list(a)==list(alloc['baseline']) for a in alloc.values())
assert all(read_alloc(O/'2'/label/'stdout')==alloc[label] for label in binaries)
comparison=[]
for name in alloc['baseline']:
 row={'representation':name,**{label:a[name] for label,a in alloc.items()}}
 for label in ['committed','experiment']:row[label+'_minus_baseline']={k:v-alloc['baseline'][name][k] for k,v in alloc[label][name].items()}
 comparison.append(row)
(O/'allocations.json').write_text(json.dumps({'rows':comparison,'note':'Exact allocation counters, with independently observed matched Massif whole-process peaks reported separately.','native_timing':False},indent=2)+'\n')
for label in ['baseline','experiment']:
 folder=O/label;folder.mkdir();shutil.copy2(binaries[label],EXE)
 for tool,args in [('callgrind',['--tool=callgrind','--callgrind-out-file='+str(folder/'callgrind.out')]),('memcheck',['--tool=memcheck','--leak-check=full','--show-leak-kinds=all','--errors-for-leak-kinds=definite,indirect','--error-exitcode=98'])]:
  cmd=['valgrind',*args,str(EXE),'64'];start=time.time()
  with (folder/(tool+'.stdout')).open('w') as out,(folder/(tool+'.stderr')).open('w') as err:r=subprocess.run(cmd,cwd=RUNTIME,env=os.environ|E,stdout=out,stderr=err)
  runs.append({'label':label,'tool':tool,'command':cmd,'cwd':str(RUNTIME),'environment':E,'exit_code':r.returncode,'seconds':time.time()-start,'native_timing':False,'binary_sha256':hashlib.sha256(EXE.read_bytes()).hexdigest()});(O/'runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(label,tool,r.returncode,round(time.time()-start,1),flush=True);assert r.returncode==0
print(json.dumps(rows),flush=True)
