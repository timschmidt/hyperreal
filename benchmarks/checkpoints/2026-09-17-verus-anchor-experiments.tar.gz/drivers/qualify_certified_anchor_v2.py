#!/usr/bin/env python3
"""Qualify an isolated product-anchor experiment while preserving shared-cache routing."""
import hashlib,json,os,shutil,subprocess,tarfile,time
from pathlib import Path
Q=Path(__file__).resolve().parent;R=Path('/home/tim/Documents/GitHub/workspace/hyperreal');S=Q/'source';O=Q/'certified-anchor-v2';O.mkdir()
C=json.loads((Q/'run.json').read_text());REV='c61d6d876d30be92faa038d1ad9fe657e241fe0c';E=C['environment']|{'CARGO_TARGET_DIR':str(Q/'target'),'CARGO_BUILD_JOBS':'4','CARGO_NET_OFFLINE':'true','CCACHE_DISABLE':'1'}
assert not subprocess.check_output(['git','status','--porcelain'],cwd=S,text=True)
original=subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip();records=[];binaries={}
paths=['src/computable/node/representation.rs','src/computable/node/approximation_queries.rs','src/computable/approximation/arithmetic_kernels.rs']
def run(name,command,artifact=False,cwd=S,environment=None,extra=None):
 env=E|(environment or {});start=time.time()
 with (O/(name+'.stdout')).open('w') as out,(O/(name+'.stderr')).open('w') as err:r=subprocess.run(command,cwd=cwd,env=os.environ|env,stdout=out,stderr=err)
 records.append({'step':name,'command':command,'cwd':str(cwd),'environment':env,'exit_code':r.returncode,'seconds':time.time()-start,'native_timing':False}|(extra or {}));(O/'runs.json').write_text(json.dumps(records,indent=2)+'\n');print(name,r.returncode,round(time.time()-start,1),flush=True)
 if r.returncode:raise RuntimeError(name+' failed')
 if artifact:
  for line in (O/(name+'.stdout')).read_text().splitlines():
   a=json.loads(line)
   if a.get('reason')=='compiler-artifact' and a.get('executable') and a['target']['kind'] in [['bench'],['example']]:
    source=Path(a['executable']);dest=O/'bin'/a['target']['name'];shutil.copy2(source,dest);binaries[dest.name]={'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'bytes':dest.stat().st_size,'features':a['features'],'target':a['target']}
  (O/'binaries.json').write_text(json.dumps(binaries,indent=2)+'\n')
try:
 subprocess.run(['git','checkout','--detach',REV],cwd=S,check=True)
 for n in paths:(S/n).write_bytes((Q/'certified-anchor-experiment/overlay'/n).read_bytes())
 p=S/paths[1];text=p.read_text();assert text.count('self.internal.cached_magnitude_bits()')==2
 text=text.replace('self.internal.cached_magnitude_bits()','self.cached_magnitude_bits()')
 needle='    fn cached(&self) -> Option<(Precision, BigInt)> {';assert text.count(needle)==1
 text=text.replace(needle,'''    fn cached_magnitude_bits(&self) -> Option<(Precision, u64)> {
        if let Some(constant) = self.shared_constant_kind() {
            SHARED_CONSTANT_CACHES[constant.cache_index()].magnitude_bits()
        } else {
            self.internal.cached_magnitude_bits()
        }
    }

'''+needle);p.write_text(text)
 (O/'change.patch').write_bytes(subprocess.check_output(['git','diff','--',*paths],cwd=S))
 names=subprocess.check_output(['git','ls-files','-z','src','tests','benches','Cargo.toml','Cargo.lock','fuzz'],cwd=S,text=True).split('\0')
 hashes={n:hashlib.sha256((S/n).read_bytes()).hexdigest() for n in names if n}
 (O/'inputs.json').write_text(json.dumps({'base_revision':REV,'baseline':C['baseline'],'compiler':C['compiler'],'environment':E,'files':hashes,'status':'isolated_experiment_not_adopted','difference_from_original_experiment':'Preserves Computable::cached routing through shared constant caches, instead of looking only at a node cache. No production root source changed.'},indent=2)+'\n')
 for n in paths:p=O/'overlay'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((S/n).read_bytes())
 (O/'bin').mkdir()
 for name,cmd in [
  ('fmt',['cargo','fmt','--all','--','--check']),
  ('default-all-targets',['cargo','test','--locked','--all-targets']),
  ('all-feature-all-targets',['cargo','test','--locked','--all-features','--all-targets']),
  ('representations',['bash','scripts/representation_coverage.sh']),
  ('clippy',['cargo','clippy','--locked','--all-features','--all-targets','--','-D','warnings']),
  ('doctests',['cargo','test','--locked','--all-features','--doc'])]:run(name,cmd)
 run('bench-build',['cargo','bench','--locked','--features','simple','--benches','--no-run','--message-format=json'],True)
 run('allocation-build',['cargo','build','--locked','--release','--all-features','--example','allocation_profile','--message-format=json'],True)
 run('allocations',[str(O/'bin/allocation_profile'),'64'],cwd=O)
 inventory=json.loads((Q/'saved-corpora.json').read_text())
 for target,files in inventory.items():
  folder=O/'fuzz'/target;(folder/'corpus').mkdir(parents=True);(folder/'artifacts').mkdir()
  with tarfile.open(R/'benchmarks/checkpoints/2026-09-17-verus-corpora.tar.gz') as archive:
   for name,digest in files.items():
    data=archive.extractfile(target+'/'+name).read();assert hashlib.sha256(data).hexdigest()==digest;(folder/'corpus'/name).write_bytes(data)
  cmd=['cargo','+nightly','fuzz','run',target,str(folder/'corpus'),'--fuzz-dir','fuzz','--target-dir',str(Q/'fuzz-target'),'--','-runs=0','-timeout=10','-seed=93537','-artifact_prefix='+str(folder/'artifacts')+'/']
  run('fuzz-'+target,cmd,environment={'CARGO_BUILD_JOBS':'2','ASAN_OPTIONS':'detect_leaks=0'},extra={'corpus_files':len(files),'sanitizer':'address','leak_checker_note':'LSan disabled for previously observed ptrace limitation.'})
 assert hashes=={n:hashlib.sha256((S/n).read_bytes()).hexdigest() for n in names if n}
finally:
 subprocess.run(['git','restore','--',*paths],cwd=S,check=True)
 subprocess.run(['git','checkout','--detach',original],cwd=S,check=True)
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=S,text=True)
 (O/'restoration.json').write_text(json.dumps({'revision':original,'clean':True},indent=2)+'\n')
