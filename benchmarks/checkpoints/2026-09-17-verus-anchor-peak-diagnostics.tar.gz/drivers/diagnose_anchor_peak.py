#!/usr/bin/env python3
"""Capture allocation call trees at the unresolved whole-process peak."""
import hashlib,json,os,re,shutil,subprocess,time
from pathlib import Path
Q=Path(__file__).resolve().parent;O=Q/'anchor-peak-diagnostics';O.mkdir();C=json.loads((Q/'run.json').read_text());E=C['environment'];runtime=Q/'metadata-profile-runtime';exe=runtime/'allocation_profile';profile=runtime/'massif.out';rows=[]
for label,source in [('baseline',Q/'baseline/bin/allocation_profile'),('experiment',Q/'certified-anchor-v2/bin/allocation_profile')]:
 folder=O/label;folder.mkdir();shutil.copy2(source,exe)
 cmd=['valgrind','--tool=massif','--stacks=yes','--time-unit=B','--detailed-freq=1','--max-snapshots=100','--peak-inaccuracy=0','--threshold=0.01','--depth=40','--massif-out-file='+str(profile),str(exe),'64'];start=time.time()
 with (folder/'stdout').open('w') as out,(folder/'stderr').open('w') as err:r=subprocess.run(cmd,cwd=runtime,env=os.environ|E,stdout=out,stderr=err)
 profile.rename(folder/'massif.out');raw=(folder/'massif.out').read_text();snapshots=raw.split('snapshot=')[1:]
 peak=max(snapshots,key=lambda s:sum(int(v) for v in re.findall(r'^(?:mem_heap_B|mem_heap_extra_B|mem_stacks_B)=(\d+)$',s,re.M)));(folder/'peak.txt').write_text(peak)
 rows.append({'label':label,'command':cmd,'environment':E,'cwd':str(runtime),'exit_code':r.returncode,'seconds':time.time()-start,'binary_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'native_timing':False});(O/'runs.json').write_text(json.dumps(rows,indent=2)+'\n');print(label,r.returncode,flush=True);assert r.returncode==0
