#!/usr/bin/env python3
"""Retain all three screen inventories, including external comparator movement."""
import gzip,hashlib,json
from pathlib import Path
Q=Path(__file__).resolve().parent;O=Q/'anchor-candidates-screen';INVENTORY=json.loads((Q/'inventory.json').read_text())['baseline'];RUNS=json.loads((O/'runs.json').read_text());assert len(RUNS)==27 and all(r['exit_code']==0 for r in RUNS)
raw={'runs.json':RUNS};rows=[]
for suite,count in INVENTORY.items():
 sides={}
 for label in ['baseline','committed','experiment']:
  data={}
  for p in sorted((O/suite/label/'criterion').glob('**/new/benchmark.json')):
   ident=json.loads(p.read_text())['full_id'];assert ident not in data;data[ident]=json.loads((p.parent/'estimates.json').read_text())
   for file in p.parent.glob('*.json'):raw[str(file.relative_to(O))]=json.loads(file.read_text())
  assert len(data)==(2 if suite=='adversarial_library' else count),(suite,label,len(data),count)
  sides[label]=data
 assert all(side.keys()==sides['baseline'].keys() for side in sides.values())
 for name in sorted(sides['baseline']):
  estimates={l:s[name]['median'] for l,s in sides.items()};row={'suite':suite,'case':name,'medians':estimates,'comparisons':{}}
  for left,right in [('baseline','committed'),('baseline','experiment'),('committed','experiment')]:
   a,b=estimates[left],estimates[right];row['comparisons'][right+'_vs_'+left]={'median_change_percent':100*(b['point_estimate']/a['point_estimate']-1),'positive_nonoverlapping_run_intervals':b['confidence_interval']['lower_bound']>a['confidence_interval']['upper_bound'],'negative_nonoverlapping_run_intervals':b['confidence_interval']['upper_bound']<a['confidence_interval']['lower_bound']}
  rows.append(row)
archive=O/'raw.json.gz';archive.write_bytes(gzip.compress(json.dumps(raw,sort_keys=True,separators=(',',':')).encode(),mtime=0))
report={'status':'screen_only_not_acceptance','rows':rows,'suites':len(INVENTORY),'total_rows':len(rows),'runs':RUNS,'raw_archive':str(archive),'raw_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'interpretation':'One short run per variant per suite. Within-run confidence intervals identify follow-ups, not repeated-pair effect uncertainty. All comparator cases are retained.'};(O/'comparison.json').write_text(json.dumps(report,indent=2)+'\n');print('Matched rows:',len(rows))
for label in ['committed_vs_baseline','experiment_vs_baseline','experiment_vs_committed']:
 flagged=[r for r in rows if r['comparisons'][label]['positive_nonoverlapping_run_intervals']];print(label,'flags',len(flagged))
 for r in sorted(flagged,key=lambda r:r['comparisons'][label]['median_change_percent'],reverse=True)[:12]:print(round(r['comparisons'][label]['median_change_percent'],2),r['suite'],r['case'])
