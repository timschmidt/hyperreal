#!/usr/bin/env python3
"""Preserve the completed three-way screen, all samples, and frozen input bindings."""
import gzip
import hashlib
import io
import json
import tarfile
from pathlib import Path

Q = Path(__file__).resolve().parent
R = Path('/home/tim/Documents/GitHub/workspace/hyperreal')
O = Q / 'anchor-candidates-screen'
D = R / 'benchmarks/checkpoints'
comparison = json.loads((O / 'comparison.json').read_text())
config = json.loads((O / 'config.json').read_text())
runs = json.loads((O / 'runs.json').read_text())
assert len(runs) == 27 and all(r['exit_code'] == 0 for r in runs)
assert comparison['total_rows'] == len(comparison['rows']) == 1449
assert comparison['suites'] == 9
assert config['baseline'] == 'a2da8e2b5de9a1a4653d3662f2f05cb6533fd7ef'
assert config['committed'] == 'c61d6d876d30be92faa038d1ad9fe657e241fe0c'
assert hashlib.sha256((O / 'raw.json.gz').read_bytes()).hexdigest() == comparison['raw_sha256']

folders = {'baseline': Q / 'baseline', 'committed': Q / 'bound-composition-complete',
           'experiment': Q / 'certified-anchor-v2'}
metadata = {label: json.loads((folder / 'binaries.json').read_text())
            for label, folder in folders.items()}
for run in runs:
    assert run['binary_sha256'] == metadata[run['label']][run['suite']]['sha256']

files = [(O / name, 'screen/' + name)
         for name in ['config.json', 'runs.json', 'comparison.json', 'raw.json.gz']]
files.extend((p, 'screen/' + str(p.relative_to(O))) for p in sorted(O.glob('*/*/run.log')))
assert len(files) == 31
for label, folder in folders.items():
    files.append((folder / 'binaries.json', 'inputs/' + label + '-binaries.json'))
    if label != 'baseline':
        files.append((folder / 'inputs.json', 'inputs/' + label + '-sources.json'))
files.append((Q / 'run.json', 'inputs/original-baseline-run.json'))
files.append((Q / 'inventory.json', 'inputs/original-inventory.json'))
files.append((folders['baseline'] / 'source-inventory.json', 'inputs/baseline-sources.json'))
files.append((folders['experiment'] / 'change.patch', 'inputs/experimental-change.patch'))
for name in ['screen_anchor_candidates.py', 'compare_anchor_candidates.py', 'preserve_anchor_screen.py']:
    files.append((Q / name, 'drivers/' + name))

archive = D / '2026-09-17-verus-anchor-screen.tar.gz'
assert not archive.exists()
with archive.open('wb') as raw:
    with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for path, name in sorted(files, key=lambda pair: pair[1]):
                data = path.read_bytes()
                info = tarfile.TarInfo(name)
                info.size = len(data)
                info.mode = 0o644
                tar.addfile(info, io.BytesIO(data))

flags = {}
for pair in ['committed_vs_baseline', 'experiment_vs_baseline', 'experiment_vs_committed']:
    flags[pair] = [
        {'suite': row['suite'], 'case': row['case'], **row['comparisons'][pair]}
        for row in comparison['rows']
        if row['comparisons'][pair]['positive_nonoverlapping_run_intervals']
    ]
report = {
    'schema': 1,
    'status': 'complete_screen_not_acceptance',
    'baseline': config['baseline'],
    'committed': config['committed'],
    'experiment': config['experiment'],
    'config': config,
    'runs': runs,
    'matching_cases_per_variant': 1449,
    'positive_nonoverlapping_flags': flags,
    'flag_counts': {pair: len(rows) for pair, rows in flags.items()},
    'related_evidence': [
        'benchmarks/checkpoints/2026-09-17-verus-baseline.json',
        'benchmarks/checkpoints/2026-09-17-verus-bound-composition-resources.json',
        'benchmarks/checkpoints/2026-09-17-verus-anchor-experiments.json',
        'benchmarks/checkpoints/2026-09-17-verus-anchor-peak-diagnostics.json',
    ],
    'limits': [
        'One short run per variant per suite screens for follow-up; it does not establish performance parity or repeated-pair uncertainty.',
        'All workloads, including external comparators, remain in the archived raw samples and complete comparison.',
        'The experimental runtime remains an unadopted three-file overlay. This screen cannot qualify subsequent source changes.',
        'CPU2 is pinned and suite order rotates. Host frequency, thermal conditions, ASLR, and unrelated user activity are uncontrolled.',
        'No owned builds, tests, verifiers, profilers, archives, or other native timings ran during these 27 serial processes.',
        'Offset rewrite and precision-boundary probes remain separate exactness work; benchmark completion does not establish their correctness.',
        'Full proof, remaining resource effects, downstream native timings, and final baseline acceptance remain unresolved.',
    ],
    'artifact': {'path': str(archive.relative_to(R)), 'files': len(files),
                 'bytes': archive.stat().st_size,
                 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()},
}
(D / '2026-09-17-verus-anchor-screen.json').write_text(json.dumps(report, indent=2) + '\n')
print(report['artifact'])
print(report['flag_counts'])
