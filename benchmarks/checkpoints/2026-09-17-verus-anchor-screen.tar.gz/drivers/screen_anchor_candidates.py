#!/usr/bin/env python3
"""Screen all nine suites for baseline/current/prototype at the same paths, serially."""
import hashlib,json,os,shutil,subprocess,time
from pathlib import Path
Q=Path(__file__).resolve().parent;C=json.loads((Q/'run.json').read_text());OUT=Q/'anchor-candidates-screen';RUN=Q/'anchor-candidates-screen-runtime';CRITERION=RUN/'criterion'
LABELS=['baseline','committed','experiment'];B={'baseline':Q/'baseline','committed':Q/'bound-composition-complete','experiment':Q/'certified-anchor-v2'}
META={label:json.loads((root/'binaries.json').read_text()) for label,root in B.items()}
I={label:json.loads((B[label]/'inputs.json').read_text()) for label in ['committed','experiment']}
# The prototype uses exactly the same benchmark/lock/build inputs as the committed candidate.
for n,h in I['experiment']['files'].items():
 if n.startswith('benches/') or n in ['Cargo.toml','Cargo.lock']:
  assert I['committed']['files'][n]==h,n
assert I['experiment']['base_revision']==I['committed']['revision']
assert I['experiment']['compiler']==I['committed']['compiler']==C['compiler']
assert len(json.loads((B['experiment']/'runs.json').read_text()))==15
OUT.mkdir();RUN.mkdir();E=C['environment']|{'CRITERION_HOME':str(CRITERION),'LC_ALL':'C'}
SUITES=['float_convert','borrowed_ops','real_representations','scalar_micro','numerical_micro','library_perf','gmp_api','adversarial_transcendentals','adversarial_library']
config={'baseline':C['baseline'],'committed':I['committed']['revision'],'experiment':{'base':I['experiment']['base_revision'],'patch_sha256':hashlib.sha256((B['experiment']/'change.patch').read_bytes()).hexdigest()},'input_manifests':{l:hashlib.sha256((B[l]/'inputs.json').read_bytes()).hexdigest() for l in I},'environment':E,'compiler':C['compiler'],'suites':SUITES,'cwd':str(Q/'source'),'order':'Rotate baseline/committed/experiment across suites so each is first, second and third three times.','limits':['A short full-inventory screen identifies follow-ups; it is not repeated-pair evidence or acceptance.','Execute only after every owned build/test/verifier/profiler/archive process has completed.','CPU2 is pinned; host frequency, thermal state, ASLR and unrelated user activity remain uncontrolled.']}
(OUT/'config.json').write_text(json.dumps(config,indent=2)+'\n');records=[]
for index,suite in enumerate(SUITES):
 order=LABELS[index%3:]+LABELS[:index%3]
 for label in order:
  folder=OUT/suite/label;folder.mkdir(parents=True);assert not CRITERION.exists()
  source=B[label]/'bin'/suite;digest=hashlib.sha256(source.read_bytes()).hexdigest();assert digest==META[label][suite]['sha256']
  executable=RUN/suite;shutil.copy2(source,executable)
  cmd=['taskset','-c','2',str(executable),'--bench','--warm-up-time','0.1','--measurement-time','0.2','--sample-size','10','--nresamples','10000','--noplot'];start=time.time();before=os.getloadavg()
  with (folder/'run.log').open('w') as log:r=subprocess.run(cmd,cwd=Q/'source',env=os.environ|E,stdout=log,stderr=subprocess.STDOUT)
  if CRITERION.exists():CRITERION.rename(folder/'criterion')
  records.append({'suite':suite,'label':label,'command':cmd,'cwd':str(Q/'source'),'start_unix':start,'seconds':time.time()-start,'exit_code':r.returncode,'load_before':before,'load_after':os.getloadavg(),'binary_sha256':digest,'directory':str(folder)});(OUT/'runs.json').write_text(json.dumps(records,indent=2)+'\n');print(suite,label,r.returncode,round(time.time()-start,1),flush=True)
  if r.returncode:raise SystemExit(r.returncode)
