#!/usr/bin/env python3
"""Bind the conditional multiplication proof and guard evidence to its commit."""
import gzip,hashlib,io,json,subprocess,tarfile
from pathlib import Path
Q=Path(__file__).resolve().parent;R=Path('/home/tim/Documents/GitHub/workspace/hyperreal');O=Q/'asymmetric-product-proof';D=R/'benchmarks/checkpoints';REV='6124684e68e1ca85a925df7a618c31a07708ec62'
e=json.loads((O/'official/evidence.json').read_text());assert e['verification_results']['verified']==604 and e['verification_results']['success']
for n,h in e['sources'].items():assert hashlib.sha256(subprocess.check_output(['git','show',REV+':'+n],cwd=R)).hexdigest()==h,n
log=(O/'new-guards.log').read_text();assert log.count('Rejected incorrect')==7 and 'Rejected attempted assumption bypass' in log
assert 'Ran 10 tests' in (O/'acceptance-tests.log').read_text() and '\nOK\n' in (O/'acceptance-tests.log').read_text()
identity=json.loads((O/'runtime-identity.json').read_text());assert identity['all_production_and_manifest_bytes_unchanged']
files=[(p,str(p.relative_to(Q))) for p in O.rglob('*') if p.is_file()]
for package in e['dependencies']['packages']:
 source=Path(package['manifest_path']).parent
 for n,h in e['dependencies']['sources'][package['id']].items():
  p=source/n;assert hashlib.sha256(p.read_bytes()).hexdigest()==h;files.append((p,'dependency-sources/'+package['name']+'-'+package['version']+'/'+n))
for n in ['preserve_asymmetric_product.py','run_asymmetric_product_guards.py']:files.append((Q/n,'drivers/'+n))
archive=D/'2026-09-17-verus-asymmetric-product.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as tar:
   for p,n in sorted(files,key=lambda r:r[1]):
    data=p.read_bytes();info=tarfile.TarInfo(n);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
report={'schema':1,'status':'conditional_real_error_model_milestone_not_implementation_proof','baseline':'a2da8e2b5de9a1a4653d3662f2f05cb6533fd7ef','proof_revision':REV,'runtime_reference':identity['runtime_reference'],
 'verification':{'units':604,'production_contracts':94,'model_theorems':117,'source_hashes':len(e['sources']),'all_match_commit':True,'no_cheating':True,'entire_target':True,'open_obligation_groups':13},
 'new_models':['Signed integer scaling has at most half a unit of rounding error, including negative operands and shifts.','A valid cached approximation and its integer bit-length bound supply an upper bound for the real value even when their binades differ.','Three-guard-bit asymmetric operand precision limits pre-rounding product error to half the target unit.','The complete mathematical asymmetric schedule preserves a one-unit approximation after signed scaling.','The early zero result is within one unit when the other operand approximates to zero at the scheduled precision.'],
 'guards':{'new_mutations_rejected':7,'attempted_assumption_bypass_rejected':True,'acceptance_and_dependency_tests':10,'prior_suite_rerun':False,'preparation_failures':'Three unsuccessful guard runs are preserved: two resource-limit diagnostics were not accepted as counterexamples, and one run exposed the existing guard parser omission of the pinned verifier diagnostic precondition not satisfied. The final seven guards reject mathematical/contract faults; timeouts are not accepted.'},
 'runtime':{'all_production_manifest_lock_bytes_unchanged':True,'proof_only_change':True},
 'limits':['These are exact-real mathematical models with explicit operand approximation and magnitude-bound premises. They do not verify production multiplication, its machine precision arithmetic, bit-length reading, BigInt operations, graph denotations or cache validity.','The one-unit error relation is inclusive; this milestone alone does not establish the stronger separation conditions needed by every public comparison path.','The isolated allocation experiments are not adopted or qualified by this proof alone.','All thirteen obligation groups and baseline acceptance remain open.'],
 'artifact':{'path':str(archive.relative_to(R)),'files':len(files),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}}
(D/'2026-09-17-verus-asymmetric-product.json').write_text(json.dumps(report,indent=2)+'\n');print(report['artifact'])
