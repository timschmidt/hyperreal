#!/usr/bin/env python3
"""Preserve source-bound arithmetic metadata proofs and ordinary qualification."""
import gzip,hashlib,io,json,re,subprocess,tarfile
from pathlib import Path
Q=Path(__file__).resolve().parent;R=Path('/home/tim/Documents/GitHub/workspace/hyperreal');D=R/'benchmarks/checkpoints'
REV='2f4a433311b7f27c0ffbf44acff37735db30cbc7';E=json.loads((Q/'bound-composition-proof/official/evidence.json').read_text())
assert E['verification_results']['success'] and E['verification_results']['verified']==563
for name,expected in E['sources'].items():assert hashlib.sha256(subprocess.check_output(['git','show',REV+':'+name],cwd=R)).hexdigest()==expected,name
for name,expected in json.loads((Q/'bound-composition-validation/inputs.json').read_text())['overlays'].items():assert hashlib.sha256(subprocess.check_output(['git','show',REV+':'+name],cwd=R)).hexdigest()==expected,name
runs=json.loads((Q/'bound-composition-validation/runs.json').read_text());assert len(runs)==6 and all(r['exit_code']==0 for r in runs)
assert (Q/'bound-composition-proof/bound-rejections.log').read_text().count('Rejected incorrect')==54
assert 'Ran 10 tests' in (Q/'bound-composition-proof/acceptance-tests.log').read_text() and '\nOK\n' in (Q/'bound-composition-proof/acceptance-tests.log').read_text()
unchanged=[str(p.relative_to(R)) for p in (R/'src/verified').glob('*.rs')]+['src/structural.rs','src/computable/node/representation.rs','verification/cache_encoding_model.rs','verification/real_approximation_model.rs','verification/integer_approximation_model.rs','verification/magnitude_model.rs','verification/test_rejections.py','verification/test_cache_rejections.py','verification/test_structural_rejections.py']
for name in unchanged:assert subprocess.check_output(['git','show',REV+':'+name],cwd=R)==subprocess.check_output(['git','show','89c89e2:'+name],cwd=R),name
counts={}
for n in ['default','all-feature']:
 text=(Q/'bound-composition-validation'/('candidate-'+n+'-all-targets.log')).read_text();counts[n]={'passed_tests':sum(map(int,re.findall(r'test result: ok\. (\d+) passed;',text))),'benchmark_fixtures':text.count('\nSuccess\n')}
files=[]
for folder in ['bound-composition-proof','bound-composition-validation']:
 files.extend((p,str(p.relative_to(Q))) for p in (Q/folder).rglob('*') if p.is_file())
for package in E['dependencies']['packages']:
 source=Path(package['manifest_path']).parent
 for name,expected in E['dependencies']['sources'][package['id']].items():
  p=source/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==expected;files.append((p,'dependency-sources/'+package['name']+'-'+package['version']+'/'+name))
for name in ['preserve_bound_composition.py','qualify_bound_composition.py']:files.append((Q/name,'drivers/'+name))
archive=D/'2026-09-17-verus-bound-composition.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as tar:
   for p,name in sorted(files,key=lambda pair:pair[1]):
    data=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
report={'schema':1,'status':'bound_propagation_milestone_not_full_verification_or_acceptance','baseline':'a2da8e2b5de9a1a4653d3662f2f05cb6533fd7ef','proof_revision':REV,'runtime_qualification_revision':'c61d6d876d30be92faa038d1ad9fe657e241fe0c','verification':{'units':563,'production_contracts':94,'functions':86,'constants':8,'model_theorems':107,'source_hashes':len(E['sources']),'all_hashes_match_commit':True,'entire_target':True,'no_cheating':True,'open_obligation_groups':13},'new_contracts':['BoundInfo::square','BoundInfo::multiply','BoundInfo::add'],'new_denotation_lemmas':['Square preserves valid nonzero/sign bounds.','Product preserves valid nonzero/sign bounds.','Distinct real binades strictly order absolute magnitudes.','Addition preserves valid bounds; opposite-sign dominance requires distinct exact binades.'],'runtime_body_changes':'Equivalent primitive matches replace bool combinators and derived Sign equality in the three included operations. No extra runtime state, removed branch, stronger input precondition or weakened known result is introduced. Full typed contracts cover all stored states, including absent exponents and signed overflow. Runtime performance and resources still require measurement.','guards':{'fresh_bound_mutations_rejected':54,'new_cases':16,'acceptance_tests_passed':10,'prior_unchanged_kernel_cache_public_guards':119,'prior_artifact':'benchmarks/checkpoints/2026-09-17-verus-certified-planning.json','note':'The guarded kernel, cache and public-carrier sources are byte-identical to89c89e2. No fresh combined173-case run is claimed.'},'ordinary_validation':{'all_passed':True,'runs':runs,'counts':counts,'directed_precision_and_tolerance_tests':4},'failed_attempts':['The first direct proof attempt encountered Verus unsupported syntax for an or-pattern with a match guard. An equivalent nested condition verifies; raw diagnostics are retained.'],'limits':['Real denotation lemmas require valid incoming bounds; production construction, caller, cache and graph invariants are not yet proved.','Inexact magnitude estimates have no accuracy guarantee and cannot justify precision or tolerance decisions.','The unchanged predicate and precision repair tests pass, but the consuming kernels and comparison algorithm still need whole-body refinement proofs.','Frozen fuzz, release/WASM/coverage/resource and pinned consumer qualification for the final runtime are running separately.','All thirteen proof groups and fixed-baseline acceptance remain incomplete.'],'artifact':{'path':str(archive.relative_to(R)),'bytes':archive.stat().st_size,'files':len(files),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}}
(D/'2026-09-17-verus-bound-composition.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'artifact':report['artifact'],'counts':counts}))
