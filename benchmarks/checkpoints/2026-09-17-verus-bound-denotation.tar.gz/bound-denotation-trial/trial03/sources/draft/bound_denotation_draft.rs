// UNVERIFIED DRAFT. Include after the production bounds in a temporary proof
// module so call_ensures refers to the actual checked implementation contracts.
use crate::real_approximation_model::{binary_unit, binary_unit_positive, binary_unit_composes,
    approximates, separated_approximation_certifies_sign};
use vstd::arithmetic::power2::lemma2_to64;

verus! {
pub(crate) open spec fn absolute(value: real) -> real {
    if value >= 0real { value } else { -value }
}

pub(crate) open spec fn real_binade(value: real, exponent: int) -> bool {
    binary_unit(exponent) <= absolute(value) < 2real * binary_unit(exponent)
}

pub(crate) open spec fn sign_denotes(sign: Option<Sign>, value: real) -> bool {
    match sign {
        None => true,
        Some(Sign::NoSign) => value == 0real,
        Some(Sign::Plus) => value > 0real,
        Some(Sign::Minus) => value < 0real,
    }
}

// This predicate covers sign, nonzero and exact magnitude certificates.
// It intentionally does not claim an error bound for inexact planning metadata.
pub(crate) open spec fn bound_denotes(bound: BoundInfo, value: real) -> bool {
    match bound {
        BoundInfo::Unknown => true,
        BoundInfo::Zero => value == 0real,
        BoundInfo::NonZero { sign, msd, exact_msd } => value != 0real
            && sign_denotes(sign, value)
            && match msd { Some(e) => exact_msd ==> real_binade(value, e as int), None => true },
    }
}

proof fn constructor_preserves_certificates(
    sign: Sign, msd: Option<i32>, exact_msd: bool, value: real, result: BoundInfo,
)
    requires sign_denotes(Some(sign), value),
        match msd { Some(e) => exact_msd ==> real_binade(value, e as int), None => true },
        call_ensures(BoundInfo::with_sign_msd, (sign, msd, exact_msd), result),
    ensures bound_denotes(result, value),
{}

proof fn separated_approximation_yields_a_bound(
    value: real, approximation: int, unit: real, sign: Sign, msd: Option<i32>, result: BoundInfo,
)
    requires approximates(value, approximation, unit),
        approximation > 1 || approximation < -1,
        if approximation > 0 { sign == Sign::Plus } else { sign == Sign::Minus },
        call_ensures(BoundInfo::with_sign_msd, (sign, msd, false), result),
    ensures bound_denotes(result, value),
{
    separated_approximation_certifies_sign(value, approximation, unit);
    constructor_preserves_certificates(sign, msd, false, value, result);
}

proof fn negation_preserves_bound_denotation(bound: BoundInfo, value: real, result: BoundInfo)
    requires bound_denotes(bound, value), call_ensures(BoundInfo::negate, (bound,), result),
    ensures bound_denotes(result, -value),
{
    assert(absolute(-value) == absolute(value));
}

proof fn inverse_preserves_bound_denotation(bound: BoundInfo, value: real, result: BoundInfo)
    requires value != 0real, bound_denotes(bound, value),
        call_ensures(BoundInfo::inverse, (bound,), result),
    ensures bound_denotes(result, 1real / value),
{
    assert(value > 0real ==> 1real / value > 0real) by (nonlinear_arith);
    assert(value < 0real ==> 1real / value < 0real) by (nonlinear_arith);
    assert(1real / value != 0real) by (nonlinear_arith) requires value != 0real;
}

proof fn positive_root_binade(value: real, root: real, exponent: i32)
    requires value > 0real, root >= 0real, root * root == value,
        real_binade(value, exponent as int),
    ensures real_binade(root, exponent as int / 2),
{
    let half = exponent as int / 2;
    let remainder = exponent as int - 2 * half;
    assert(remainder == 0 || remainder == 1);
    binary_unit_positive(half);
    binary_unit_composes(half, half);
    binary_unit_composes(2 * half, remainder);
    lemma2_to64();
    assert(binary_unit(0) == 1real && binary_unit(1) == 2real);
    let unit = binary_unit(half);
    let factor = binary_unit(remainder);
    assert(factor == 1real || factor == 2real);
    assert(binary_unit(exponent as int) == unit * unit * factor);
    assert(unit * unit <= root * root < 4real * unit * unit) by (nonlinear_arith)
        requires unit > 0real, factor == 1real || factor == 2real,
            unit * unit * factor <= value < 2real * unit * unit * factor,
            root * root == value;
    assert(unit <= root < 2real * unit) by (nonlinear_arith)
        requires unit > 0real, root >= 0real,
            unit * unit <= root * root < 4real * unit * unit;
}

proof fn square_root_preserves_bound_denotation(
    bound: BoundInfo, value: real, root: real, result: BoundInfo,
)
    requires root >= 0real, root * root == value, bound_denotes(bound, value),
        call_ensures(BoundInfo::sqrt, (bound,), result),
    ensures bound_denotes(result, root),
{
    assert(value == 0real ==> root == 0real) by (nonlinear_arith)
        requires root * root == value;
    assert(value > 0real ==> root > 0real) by (nonlinear_arith)
        requires root >= 0real, root * root == value;
    match bound {
        BoundInfo::NonZero { sign: Some(Sign::Plus), msd: Some(exponent), exact_msd: true } => {
            positive_root_binade(value, root, exponent);
            assert(i32::MIN <= exponent as int / 2 <= i32::MAX);
        },
        _ => {},
    }
}

proof fn queried_magnitude_is_a_certificate(bound: &BoundInfo, value: real, result: Option<Option<i32>>)
    requires bound_denotes(*bound, value), call_ensures(BoundInfo::known_msd, (bound,), result),
    ensures result == Some(None) ==> value == 0real,
        match result { Some(Some(e)) => real_binade(value, e as int), _ => true },
{}

proof fn queried_sign_is_a_certificate(bound: &BoundInfo, value: real, result: Option<Sign>)
    requires bound_denotes(*bound, value), call_ensures(BoundInfo::known_sign, (bound,), result),
    ensures sign_denotes(result, value),
{}
}
