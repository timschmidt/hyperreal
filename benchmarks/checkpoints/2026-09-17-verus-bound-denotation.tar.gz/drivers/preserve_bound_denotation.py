#!/usr/bin/env python3
"""Preserve real-denotation refinements and their source-bound checks."""
import gzip, hashlib, io, json, subprocess, tarfile
from pathlib import Path
Q = Path(__file__).resolve().parent
R = Path('/home/tim/Documents/GitHub/workspace/hyperreal')
O = Q / 'bound-denotation-trial'
D = R / 'benchmarks/checkpoints'
def digest(data): return hashlib.sha256(data).hexdigest()
def git(*args): return subprocess.check_output(['git', *args], cwd=R, text=True).strip()
revision = git('rev-parse', 'HEAD')
e = json.loads((R / 'target/verification/evidence.json').read_text())
assert e['verification_results']['verified'] == 460 and e['verification_results']['success']
assert len(e['scope']['verified_executable_contracts']) == 65
assert len(e['scope']['verified_model_theorems']) == 95
for name, h in e['sources'].items():
    assert digest(subprocess.check_output(['git', 'show', revision + ':' + name], cwd=R)) == h, name
assert not git('diff', '1514ad4', '--', 'src', 'tests', 'Cargo.toml', 'Cargo.lock')
rejections = (O / 'rejections.log').read_text()
assert rejections.count('Rejected incorrect BoundInfo::') == 13
assert rejections.count('Rejected incorrect bound denotation:') == 6
assert 'Traceback' not in rejections
assert 'Ran 10 tests' in (O / 'acceptance-tests.log').read_text()
assert '\nOK\n' in (O / 'acceptance-tests.log').read_text()
for p in list((R / 'src/verified').glob('*.rs')) + list((R / 'verification').glob('*_model.rs')):
    assert p.read_bytes() == subprocess.check_output(['git', 'show', '49f2b8f:' + str(p.relative_to(R))], cwd=R)
files = [(p, str(p.relative_to(Q))) for p in O.rglob('*') if p.is_file()]
for name in ['evidence.json', 'verus.json', 'verus.stderr', 'dependencies.json',
             'dependencies-build.stdout', 'dependencies-build.stderr']:
    files.append((R / 'target/verification' / name, 'official/' + name))
for package in e['dependencies']['packages']:
    root = Path(package['manifest_path']).parent
    for name, h in e['dependencies']['sources'][package['id']].items():
        p = root / name; assert digest(p.read_bytes()) == h
        files.append((p, 'dependency-sources/' + package['name'] + '-' + package['version'] + '/' + name))
for name in ['verification/bound_denotation.rs', 'verification/computable_bounds.rs',
             'verification/test_bound_rejections.py', 'verification/scope.json', 'verification/README.md']:
    files.append((R / name, 'committed/' + name))
for name in ['preserve_bound_denotation.py', 'run_bound_denotation_trial.py']:
    files.append((Q / name, 'drivers/' + name))
archive = D / '2026-09-17-verus-bound-denotation.tar.gz'
with archive.open('wb') as raw:
    with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for p, name in sorted(files, key=lambda item: item[1]):
                data = p.read_bytes(); info = tarfile.TarInfo(name)
                info.size = len(data); info.mode = 0o644
                tar.addfile(info, io.BytesIO(data))
report = {
    'schema': 1, 'status': 'conditional_bound_denotation_proof_not_complete',
    'baseline': 'a2da8e2b5de9a1a4653d3662f2f05cb6533fd7ef',
    'proof_revision': revision, 'runtime_reference': git('rev-parse', 'cdc6d3a'),
    'verification': {'units': 460, 'executable_contracts': 65, 'model_theorems': 95,
        'source_hashes': len(e['sources']), 'source_hashes_match_commit': True,
        'no_cheating': True, 'entire_proof_target': True, 'open_obligation_groups': 13},
    'new_theorems': [n for n in e['scope']['verified_model_theorems'] if n.startswith('computable_bounds::')],
    'negative_guards': {'production_bound_mutations_rejected': 13, 'bound_denotation_mutations_rejected': 6,
        'acceptance_and_dependency_identity_tests': 10, 'unchanged_kernel_model_mutations': 85,
        'reused_evidence': 'benchmarks/checkpoints/2026-09-17-verus-real-approximation-model.json',
        'note': 'Nineteen bound guards were run on the final source. The unchanged kernel/model inputs retain their prior 85-mutation and assumption-bypass evidence; no fresh combined 104-mutation run is claimed.'},
    'dependency_import': {'packages': len(e['dependencies']['packages']),
        'source_files': sum(map(len, e['dependencies']['sources'].values())),
        'all_registry_pins_match_production': True, 'source_and_artifact_identity_checked': True,
        'scope': e['dependencies']['scope']},
    'ordinary_runtime': {'source_tests_and_cargo_inputs_identical_to': git('rev-parse', '1514ad4'),
        'reused_erasure_evidence': 'benchmarks/checkpoints/2026-09-17-verus-bound-refinement.json',
        'note': 'Only proof models, the proof entry module, scope documentation and rejection guards changed. Runtime sources are unchanged; the existing erasure comparison remains applicable.'},
    'failed_experiments': [
        'Initial draft visibility exceeded the production private methods; refinement lemmas retain module-local visibility.',
        'The square-root proof needed explicit real-division and multiplication facts. Failed proof attempts are retained.',
        'The first expanded mutation driver correctly rejected the weakened separation premise but did not recognize the precondition diagnostic. The failed invocation and corrected passing suite are retained.'
    ],
    'limits': [
        'Denotation lemmas are conditional on valid incoming sign, nonzero and exact-magnitude certificates. They use call_ensures for the actual checked production functions.',
        'Inexact planning magnitudes have no claimed error bound. The expression graph, rational/BigInt import, cache validity and production callers remain open.',
        'All thirteen whole-implementation obligation groups and baseline qualification remain incomplete. Existing timing, resource and pinned-consumer failures are not dismissed.'
    ],
    'artifact': {'path': str(archive.relative_to(R)), 'bytes': archive.stat().st_size,
        'files': len(files), 'sha256': digest(archive.read_bytes())},
}
(D / '2026-09-17-verus-bound-denotation.json').write_text(json.dumps(report, indent=2) + '\n')
print(report['artifact'])
