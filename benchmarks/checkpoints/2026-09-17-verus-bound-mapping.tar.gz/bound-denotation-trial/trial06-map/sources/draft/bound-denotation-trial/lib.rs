#![feature(proc_macro_hygiene)]
#[path = "/home/tim/Documents/GitHub/workspace/hyperreal/src/verified/mod.rs"] mod verified;
#[path = "/home/tim/Documents/GitHub/workspace/hyperreal/verification/magnitude_model.rs"] mod magnitude_model;
#[path = "/home/tim/Documents/GitHub/workspace/hyperreal/verification/integer_approximation_model.rs"] mod integer_approximation_model;
#[path = "/home/tim/Documents/GitHub/workspace/hyperreal/verification/real_approximation_model.rs"] mod real_approximation_model;
mod computable_bounds;
