#!/usr/bin/env python3
"""Preserve magnitude-mapping refinements and their source-bound checks."""
import gzip, hashlib, io, json, subprocess, tarfile
from pathlib import Path
Q = Path(__file__).resolve().parent
R = Path('/home/tim/Documents/GitHub/workspace/hyperreal')
O = Q / 'bound-mapping-proof'
D = R / 'benchmarks/checkpoints'
def digest(data): return hashlib.sha256(data).hexdigest()
def git(*args): return subprocess.check_output(['git', *args], cwd=R, text=True).strip()
revision = git('rev-parse', 'HEAD')
e = json.loads((R / 'target/verification/evidence.json').read_text())
assert e['verification_results']['verified'] == 468 and e['verification_results']['success']
assert len(e['scope']['verified_executable_contracts']) == 66
assert len(e['scope']['verified_model_theorems']) == 97
for name, h in e['sources'].items():
    assert digest(subprocess.check_output(['git', 'show', revision + ':' + name], cwd=R)) == h, name
expanded = (Q / 'bound-mapping-erasure/candidate-expanded-runtime.log').read_bytes()
assert expanded == (Q / 'computable-metadata-complete/expanded-runtime.rs').read_bytes()
assert all(row['exit_code'] == 0 for row in json.loads((Q / 'bound-mapping-erasure/runs.json').read_text()))
assert json.loads((Q / 'bound-mapping-erasure/restoration.json').read_text())['clean']
rejections = (O / 'rejections.log').read_text()
assert rejections.count('Rejected incorrect BoundInfo::') == 16
assert rejections.count('Rejected incorrect bound denotation:') == 9
assert 'Traceback' not in rejections
assert 'Ran 10 tests' in (O / 'acceptance-tests.log').read_text()
assert '\nOK\n' in (O / 'acceptance-tests.log').read_text()
for p in list((R / 'src/verified').glob('*.rs')) + list((R / 'verification').glob('*_model.rs')):
    assert p.read_bytes() == subprocess.check_output(['git', 'show', '49f2b8f:' + str(p.relative_to(R))], cwd=R)
files = [(p, str(p.relative_to(Q))) for folder in [O, Q / 'bound-mapping-erasure', Q / 'bound-denotation-trial/trial06-map', Q / 'bound-denotation-trial/trial07-offset'] for p in folder.rglob('*') if p.is_file()]
for name in ['evidence.json', 'verus.json', 'verus.stderr', 'dependencies.json',
             'dependencies-build.stdout', 'dependencies-build.stderr']:
    files.append((R / 'target/verification' / name, 'official/' + name))
for package in e['dependencies']['packages']:
    root = Path(package['manifest_path']).parent
    for name, h in e['dependencies']['sources'][package['id']].items():
        p = root / name; assert digest(p.read_bytes()) == h
        files.append((p, 'dependency-sources/' + package['name'] + '-' + package['version'] + '/' + name))
for name in ['src/computable/node/bounds.rs', 'verification/bound_denotation.rs', 'verification/computable_bounds.rs',
             'verification/test_bound_rejections.py', 'verification/scope.json', 'verification/README.md']:
    files.append((R / name, 'committed/' + name))
for name in ['preserve_bound_mapping.py', 'run_bound_denotation_trial.py', 'check_bound_mapping_erasure.py']:
    files.append((Q / name, 'drivers/' + name))
archive = D / '2026-09-17-verus-bound-mapping.tar.gz'
with archive.open('wb') as raw:
    with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for p, name in sorted(files, key=lambda item: item[1]):
                data = p.read_bytes(); info = tarfile.TarInfo(name)
                info.size = len(data); info.mode = 0o644
                tar.addfile(info, io.BytesIO(data))
report = {
    'schema': 1, 'status': 'magnitude_mapping_proof_not_complete',
    'baseline': 'a2da8e2b5de9a1a4653d3662f2f05cb6533fd7ef',
    'proof_revision': revision, 'runtime_reference': git('rev-parse', 'cdc6d3a'),
    'verification': {'units': 468, 'executable_contracts': 66, 'model_theorems': 97,
        'source_hashes': len(e['sources']), 'source_hashes_match_commit': True,
        'no_cheating': True, 'entire_proof_target': True, 'open_obligation_groups': 13},
    'new_contracts': ['computable_bounds::BoundInfo::map_msd'],
    'new_theorems': ['computable_bounds::binary_scaling_preserves_real_binade', 'computable_bounds::binary_offset_preserves_bound_denotation'],
    'negative_guards': {'production_bound_mutations_rejected': 16, 'bound_denotation_mutations_rejected': 9,
        'acceptance_and_dependency_identity_tests': 10, 'unchanged_kernel_model_mutations': 85,
        'reused_evidence': 'benchmarks/checkpoints/2026-09-17-verus-real-approximation-model.json',
        'note': 'Twenty-five bound guards were run on the final source. The unchanged kernel/model inputs retain their prior 85-mutation and assumption-bypass evidence; no fresh combined 110-mutation run is claimed.'},
    'dependency_import': {'packages': len(e['dependencies']['packages']),
        'source_files': sum(map(len, e['dependencies']['sources'].values())),
        'all_registry_pins_match_production': True, 'source_and_artifact_identity_checked': True,
        'scope': e['dependencies']['scope']},
    'ordinary_runtime': {'byte_identical_expansion_to_runtime_reference': True,
        'expanded_sha256': digest(expanded), 'lines': len(expanded.splitlines()),
        'checks': json.loads((Q / 'bound-mapping-erasure/runs.json').read_text()),
        'note': 'The mapping implementation is unchanged. Its annotations pass strict all-feature all-target Clippy and erase to the same ordinary Rust as cdc6d3a.'},
    'experiments': ['The direct production mapping contract and the two binary-scaling refinements both pass their first focused verification runs. These inputs and verifier outputs are retained.'],
    'limits': [
        'The mapping contract preserves every non-magnitude field and available callback result. It proves the callback precondition exactly when an exponent exists. Binary-offset denotation requires the callback to return the checked mathematical exponent sum.',
        'Inexact planning magnitudes have no claimed error bound. The expression graph, rational/BigInt import, cache validity and production mapping callbacks/callers remain open.',
        'All thirteen whole-implementation obligation groups and baseline qualification remain incomplete. Existing timing, resource and pinned-consumer failures are not dismissed.'
    ],
    'artifact': {'path': str(archive.relative_to(R)), 'bytes': archive.stat().st_size,
        'files': len(files), 'sha256': digest(archive.read_bytes())},
}
(D / '2026-09-17-verus-bound-mapping.json').write_text(json.dumps(report, indent=2) + '\n')
print(report['artifact'])
