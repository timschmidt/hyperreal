#!/usr/bin/env python3
"""Record each exploratory proof, including failures, against actual bounds."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

Q = Path(__file__).resolve().parent
REPO = Path('/home/tim/Documents/GitHub/workspace/hyperreal')
sys.path.insert(0, str(REPO / 'scripts'))
from verus_dependencies import check_dependency_identity

name = sys.argv[1]
out = Q / 'bound-denotation-trial' / name
out.mkdir()
dependencies = json.loads((REPO / 'target/verification/dependencies.json').read_text())
check_dependency_identity(dependencies)
sources = [Q / 'bound_denotation_draft.rs', Q / 'bound-denotation-trial/lib.rs',
           Q / 'bound-denotation-trial/computable_bounds.rs',
           REPO / 'src/computable/node/bounds.rs',
           REPO / 'verification/magnitude_model.rs',
           REPO / 'verification/integer_approximation_model.rs',
           REPO / 'verification/real_approximation_model.rs',
           *sorted((REPO / 'src/verified').glob('*.rs'))]
hashes = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}
for p in sources:
    if p.is_relative_to(REPO):
        target = out / 'sources' / p.relative_to(REPO)
    else:
        target = out / 'sources/draft' / p.relative_to(Q)
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(p, target)
pin = json.loads((REPO / 'verification/toolchain.json').read_text())
command = [str(REPO / 'target/verus' / pin['version'] / 'verus-x86-linux/verus'),
           '--edition=2024', '--crate-type=lib', '--crate-name=bound_denotation_trial',
           '--no-cheating', '--output-json', *dependencies['verus_arguments'],
           str(Q / 'bound-denotation-trial/lib.rs')]
started = time.time()
result = subprocess.run(command, cwd=Q / 'bound-denotation-trial', text=True, capture_output=True)
(out / 'stdout.json').write_text(result.stdout)
(out / 'stderr.log').write_text(result.stderr)
assert hashes == {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}
check_dependency_identity(dependencies)
record = {'command': command, 'exit_code': result.returncode, 'seconds': time.time() - started,
          'sources': hashes, 'dependencies': dependencies}
(out / 'run.json').write_text(json.dumps(record, indent=2) + '\n')
print(result.stderr)
if result.stdout:
    try:
        print(json.loads(result.stdout).get('verification-results', result.stdout))
    except ValueError:
        print(result.stdout)
raise SystemExit(result.returncode)
