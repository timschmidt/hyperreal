#!/usr/bin/env python3
"""Retain actual typed-bound proofs, dependency identity and failed experiments."""
import gzip, hashlib, io, json, subprocess, tarfile
from pathlib import Path
Q = Path(__file__).resolve().parent
R = Path('/home/tim/Documents/GitHub/workspace/hyperreal')
O = Q / 'bounds-refinement-proof'
D = R / 'benchmarks/checkpoints'
revision = subprocess.check_output(['git', 'rev-parse', '1514ad4'], cwd=R, text=True).strip()
runtime = subprocess.check_output(['git', 'rev-parse', 'cdc6d3a'], cwd=R, text=True).strip()
def digest(data): return hashlib.sha256(data).hexdigest()
def read(path): return json.loads(path.read_text())
e = read(R / 'target/verification/evidence.json')
assert e['verification_results']['verified'] == 443 and e['verification_results']['success']
assert len(e['scope']['verified_executable_contracts']) == 65
for name, h in e['sources'].items():
    assert digest(subprocess.check_output(['git', 'show', revision + ':' + name], cwd=R)) == h
assert (O / 'rejections.log').read_text().count('Rejected incorrect BoundInfo::') == 13
assert 'Ran 10 tests' in (O / 'acceptance-tests.log').read_text() and '\nOK\n' in (O / 'acceptance-tests.log').read_text()
for p in list((R / 'src/verified').glob('*.rs')) + list((R / 'verification').glob('*_model.rs')):
    assert p.read_bytes() == subprocess.check_output(['git', 'show', '49f2b8f:' + str(p.relative_to(R))], cwd=R)
final = Q / 'bounds-annotation-final-erasure'
for name, h in read(final / 'inputs.json')['overlays'].items():
    assert digest((R / name).read_bytes()) == h
expanded = (final / 'candidate-expanded-runtime.log').read_bytes()
assert expanded == (Q / 'bounds-annotation-validation/candidate-expanded-runtime.log').read_bytes()
assert expanded == (Q / 'computable-metadata-complete/expanded-runtime.rs').read_bytes()
for name in ['bounds-annotation-validation', 'bounds-annotation-final-erasure']:
    assert all(row['exit_code'] == 0 for row in read(Q / name / 'runs.json'))
    assert read(Q / name / 'restoration.json')['clean']

files = []
for folder in [O, Q / 'sign-refinement-trial', Q / 'bounds-annotation-validation', final]:
    files += [(p, str(p.relative_to(Q))) for p in folder.rglob('*') if p.is_file()]
for name in ['evidence.json', 'verus.json', 'verus.stderr', 'dependencies.json',
             'dependencies-build.stdout', 'dependencies-build.stderr']:
    files.append((R / 'target/verification' / name, 'official/' + name))
for package in e['dependencies']['packages']:
    root = Path(package['manifest_path']).parent
    for name, h in e['dependencies']['sources'][package['id']].items():
        p = root / name; assert digest(p.read_bytes()) == h
        files.append((p, 'dependency-sources/' + package['name'] + '-' + package['version'] + '/' + name))
for name in ['src/computable/node/bounds.rs', 'verification/computable_bounds.rs',
             'scripts/verus_dependencies.py', 'scripts/verify_verus.py',
             'verification/test_bound_rejections.py', 'verification/test_dependency_identity.py',
             'verification/dependencies/Cargo.toml', 'verification/dependencies/Cargo.lock',
             'verification/dependencies/src/lib.rs']:
    files.append((R / name, 'committed/' + name))
for name in ['preserve_bound_refinement.py', 'qualify_bounds_annotations.py', 'check_bounds_annotation_erasure.py']:
    files.append((Q / name, 'drivers/' + name))
archive = D / '2026-09-17-verus-bound-refinement.tar.gz'
with archive.open('wb') as raw:
    with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for p, name in sorted(files, key=lambda item: item[1]):
                data = p.read_bytes(); info = tarfile.TarInfo(name)
                info.size = len(data); info.mode = 0o644
                tar.addfile(info, io.BytesIO(data))
report = {
    'schema': 1, 'status': 'typed_bound_proof_milestone_not_complete',
    'baseline': 'a2da8e2b5de9a1a4653d3662f2f05cb6533fd7ef',
    'proof_revision': revision, 'runtime_reference': runtime,
    'verification': {'units': 443, 'executable_contracts': 65, 'model_theorems': 87,
        'source_hashes': len(e['sources']), 'source_hashes_match_commit': True,
        'no_cheating': True, 'entire_proof_target': True, 'open_obligation_groups': 13},
    'new_contracts': ['BoundInfo::' + n for n in ['with_sign', 'with_sign_msd', 'negate', 'inverse',
        'sqrt', 'known_msd', 'planning_msd', 'known_sign']] + ['negate_sign'],
    'negative_guards': {'new_bound_mutations_rejected': 13, 'acceptance_and_dependency_identity_tests': 10,
        'unchanged_kernel_model_mutations': 85,
        'reused_evidence': 'benchmarks/checkpoints/2026-09-17-verus-real-approximation-model.json',
        'note': 'Thirteen bound mutations were run on the final contracts. The unchanged kernel/model inputs retain the prior 85-mutation and assumption-bypass evidence; a fresh full 98-mutation run is not claimed.'},
    'dependency_import': {'packages': len(e['dependencies']['packages']),
        'source_files': sum(map(len, e['dependencies']['sources'].values())),
        'all_registry_pins_match_production': True, 'source_and_artifact_identity_checked': True,
        'scope': 'Transparent import of the actual Sign enum variants only; no arithmetic or equality operation is assumed or certified by this import.'},
    'ordinary_runtime': {'byte_identical_expansion_to_runtime_reference': True,
        'expanded_sha256': digest(expanded), 'lines': len(expanded.splitlines()),
        'annotation_checks': read(Q / 'bounds-annotation-validation/runs.json'),
        'final_erasure_check': read(final / 'runs.json'),
        'note': 'Focused debug/release and strict all-feature Clippy used the initial annotations. Final strengthened query contracts have identical ordinary expansion, which also matches the fully qualified metadata runtime.'},
    'failed_experiments': [
        'The exploratory sign build initially used different transitive pins; subsequent trials and the official proof use the exact production dependency versions and checksums.',
        'An explicit equality experiment fails without a verified equality implementation. No assumption was added to make it pass.',
        'Copied-body API experiments exposed attribute expansion, closure-contract and unsupported Option::flatten/bool::then_some limitations. These trials are diagnostics, not production proof. The official harness includes the production file directly.',
        'The first bound rejection driver did not recognize a correctly rejected inverse closure postcondition. Its unsuccessful run is retained; the final driver recognizes that diagnostic and passes all thirteen mutations.'
    ],
    'limits': [
        'Typed contracts cover complete constructor/transformation/query results, including unavailable exponents and preservation of available answers. Real denotation and validity of incoming bound/cache states remain open.',
        'Rational import, mapping callbacks, addition, square, multiplication, public magnitude conversion, constant certificates and concurrency remain outside the added executable boundary.',
        'All thirteen whole-implementation obligation groups and baseline qualification remain incomplete. Earlier timing/resource and pinned-consumer failures are not dismissed.'
    ],
    'artifact': {'path': str(archive.relative_to(R)), 'bytes': archive.stat().st_size,
        'files': len(files), 'sha256': digest(archive.read_bytes())},
}
(D / '2026-09-17-verus-bound-refinement.json').write_text(json.dumps(report, indent=2) + '\n')
print(report['artifact'])
