from pathlib import Path
p=Path(__file__).resolve().parent;s=(p/'bounds-1.rs').read_text();(p/'bounds-source-3.rs').write_text(s)
s='''#[cfg(verus_keep_ghost)]
verus! {
open spec fn checked_metadata_exponent(value: int) -> Option<i32> {
    if i32::MIN <= value <= i32::MAX { Some(value as i32) } else { None }
}
}
''' + s
contracts={
'negate':'''ensures result == match self {
    Self::NonZero { sign: Some(Sign::Plus), msd, exact_msd } => Self::NonZero { sign: Some(Sign::Minus), msd, exact_msd },
    Self::NonZero { sign: Some(Sign::Minus), msd, exact_msd } => Self::NonZero { sign: Some(Sign::Plus), msd, exact_msd },
    _ => self,
},''',
'inverse':'''ensures result == match self {
    Self::NonZero { sign, msd, .. } => Self::NonZero { sign, exact_msd: false,
        msd: match msd { Some(e) => checked_metadata_exponent(1 - e as int), None => None } },
    _ => self,
},''',
'square':'''ensures result == match self {
    Self::NonZero { msd, exact_msd, .. } => Self::NonZero { sign: Some(Sign::Plus), exact_msd: false,
        msd: if exact_msd { match msd { Some(e) => checked_metadata_exponent(2 * e as int), None => None } } else { None } },
    _ => self,
},''',
'sqrt':'''ensures result == match self {
    Self::Zero => Self::Zero,
    Self::NonZero { sign: Some(Sign::Plus), msd, exact_msd } => Self::NonZero { sign: Some(Sign::Plus), exact_msd,
        msd: match msd { Some(e) => Some((e as int / 2) as i32), None => None } },
    _ => Self::Unknown,
},''',
'multiply':'''ensures result == match (self, other) {
    (Self::Zero, _) | (_, Self::Zero) => Self::Zero,
    (Self::NonZero { sign: a, msd: m, exact_msd: x }, Self::NonZero { sign: b, msd: n, exact_msd: y }) => Self::NonZero {
        sign: match (a, b) {
            (Some(Sign::Plus), Some(Sign::Plus)) | (Some(Sign::Minus), Some(Sign::Minus)) => Some(Sign::Plus),
            (Some(Sign::Plus), Some(Sign::Minus)) | (Some(Sign::Minus), Some(Sign::Plus)) => Some(Sign::Minus),
            _ => None,
        },
        exact_msd: false,
        msd: if x && y { match (m, n) { (Some(m), Some(n)) => checked_metadata_exponent(m as int + n as int), _ => None } } else { None },
    },
    _ => Self::Unknown,
},''',
'known_sign':'''ensures result == match *self {
    Self::Zero => Some(Sign::NoSign),
    Self::NonZero { sign, .. } => sign,
    Self::Unknown => None,
},''',
}
for name,contract in contracts.items():
 anchor='    fn '+name+'('
 assert s.count(anchor)==1,name
 s=s.replace(anchor,'    #[cfg_attr(verus_keep_ghost, allow(unused, verus_impl_method_marker))]\n    #[cfg_attr(verus_keep_ghost, verus_spec(result =>\n        '+contract+'\n    ))]\n'+anchor)
s=s.replace('fn negate_sign(','''#[cfg_attr(verus_keep_ghost, verus_spec(result =>
    ensures result == match sign { Sign::Plus => Sign::Minus, Sign::Minus => Sign::Plus, Sign::NoSign => Sign::NoSign },
))]
fn negate_sign(''')
(p/'bounds-1.rs').write_text(s)
