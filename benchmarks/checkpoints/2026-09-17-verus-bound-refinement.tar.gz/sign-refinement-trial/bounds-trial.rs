#![feature(proc_macro_hygiene)]
use vstd::prelude::*;
use num::bigint::Sign;
verus! {
#[verifier::external_type_specification]
pub struct ExSign(Sign);
}
#[path = "/home/tim/Documents/GitHub/workspace/hyperreal/src/verified/mod.rs"]
mod verified;
include!("bounds-1.rs");
