import subprocess,json,hashlib,sys
from pathlib import Path
p=Path(__file__).resolve().parent;q=p.parent
artifact=next(x for x in map(json.loads,(p/'pinned-build.stdout').read_text().splitlines()) if x.get('reason')=='compiler-artifact' and x['target']['name']=='num')
lib=next(x for x in artifact['filenames'] if x.endswith('.rlib'));n=sys.argv[1]
cmd=['/home/tim/Documents/GitHub/workspace/hyperreal/target/verus/0.2026.09.13.671956e/verus-x86-linux/verus','--crate-type=lib','--edition=2024','--no-cheating','--output-json','--extern','num='+lib,'-L','dependency='+str(q/'verus-dependency-target/debug/deps'),str(p/'bounds-trial.rs')]
r=subprocess.run(cmd,cwd=p,capture_output=True,text=True)
(p/('bounds-'+n+'.stdout')).write_text(r.stdout);(p/('bounds-'+n+'.stderr')).write_text(r.stderr)
(p/('bounds-'+n+'.json')).write_text(json.dumps({'command':cmd,'exit_code':r.returncode,'source_sha256':hashlib.sha256((p/'bounds-1.rs').read_bytes()).hexdigest(),'status':'unintegrated copied-body API experiment; not production proof'},indent=2)+'\n');print('exit',r.returncode);print(r.stderr);print(r.stdout[-1500:])
