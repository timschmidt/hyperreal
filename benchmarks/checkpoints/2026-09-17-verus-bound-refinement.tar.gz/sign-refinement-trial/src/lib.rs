pub fn sign() -> num::bigint::Sign { num::bigint::Sign::NoSign }
