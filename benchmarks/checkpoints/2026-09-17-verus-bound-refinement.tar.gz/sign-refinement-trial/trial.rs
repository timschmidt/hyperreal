use vstd::prelude::*;
use num::bigint::Sign;
verus! {
#[verifier::external_type_specification]
pub struct ExSign(Sign);
pub fn negate(sign: Sign) -> (result: Sign)
 ensures match sign { Sign::Plus => result == Sign::Minus, Sign::Minus => result == Sign::Plus, Sign::NoSign => result == Sign::NoSign },
{
 match sign { Sign::Plus => Sign::Minus, Sign::Minus => Sign::Plus, Sign::NoSign => Sign::NoSign }
}
pub fn compare(a: Sign, b: Sign) -> (same: bool)
 ensures same == (a == b),
{ a == b }
}
