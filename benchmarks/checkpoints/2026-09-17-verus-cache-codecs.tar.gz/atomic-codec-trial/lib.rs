#![feature(proc_macro_hygiene)]
mod verified {
#[path = "/home/tim/Documents/GitHub/workspace/hyperreal/src/verified/word.rs"] pub(crate) mod word;
}
mod bounds {
use num::bigint::Sign;
verus! {
#[verifier::external_type_specification]
pub struct ImportedSign(Sign);
}
include!("/home/tim/Documents/GitHub/workspace/hyperreal/src/computable/node/bounds.rs");
include!("atomic_facts.rs");
}
