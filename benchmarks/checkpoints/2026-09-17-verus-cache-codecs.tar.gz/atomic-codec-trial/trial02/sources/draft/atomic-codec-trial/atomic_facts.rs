// EXPERIMENT ONLY: copied actual codec bodies with proof annotations.
// This is not an implementation refinement until the production file is included.
verus! {
spec fn exact_sign_denotation(value: u64) -> ExactSignCache {
    match (value >> 6) & 7 {
        0 => ExactSignCache::Invalid,
        1 => ExactSignCache::Unknown,
        2 => ExactSignCache::Valid(Sign::Minus),
        3 => ExactSignCache::Valid(Sign::NoSign),
        _ => ExactSignCache::Valid(Sign::Plus),
    }
}
}
#[derive(Debug)]
#[cfg_attr(verus_keep_ghost, verus_verify)]
struct AtomicFacts(std::sync::atomic::AtomicU64);

#[cfg(not(verus_keep_ghost))]
impl Default for AtomicFacts {
    #[cfg(not(verus_keep_ghost))]
    fn default() -> Self {
        Self(std::sync::atomic::AtomicU64::new(0))
    }
}

impl AtomicFacts {
    #[cfg_attr(verus_keep_ghost, verus_verify)]
    const TAG_INVALID: u64 = 0;
    #[cfg_attr(verus_keep_ghost, verus_verify)]
    const TAG_UNKNOWN: u64 = 1;
    #[cfg_attr(verus_keep_ghost, verus_verify)]
    const TAG_ZERO: u64 = 2;
    #[cfg_attr(verus_keep_ghost, verus_verify)]
    const TAG_NONZERO: u64 = 3;
    #[cfg_attr(verus_keep_ghost, verus_verify)]
    const SIGN_SHIFT: u32 = 2;
    #[cfg_attr(verus_keep_ghost, verus_verify)]
    const MSD_PRESENT: u64 = 1 << 4;
    #[cfg_attr(verus_keep_ghost, verus_verify)]
    const EXACT_MSD: u64 = 1 << 5;
    #[cfg_attr(verus_keep_ghost, verus_verify)]
    const EXACT_SIGN_SHIFT: u32 = 6;
    #[cfg_attr(verus_keep_ghost, verus_verify)]
    const EXACT_SIGN_MASK: u64 = 0b111 << Self::EXACT_SIGN_SHIFT;
    #[cfg_attr(verus_keep_ghost, verus_verify)]
    const INVERSE_TRIG_OR_PI_KNOWN: u64 = 1 << 9;
    #[cfg_attr(verus_keep_ghost, verus_verify)]
    const CONTAINS_INVERSE_TRIG_OR_PI: u64 = 1 << 10;
    // Signed saturated precision decrement along Add/Negate/Offset paths.
    // Used only for child ordering, never as a numerical bound. Deserialized
    // nodes default to zero and retain ordinary evaluation order.
    #[cfg_attr(verus_keep_ghost, verus_verify)]
    const LINEAR_DEMAND_SHIFT: u32 = 16;
    #[cfg_attr(verus_keep_ghost, verus_verify)]
    const LINEAR_DEMAND_MASK: u64 = (u16::MAX as u64) << Self::LINEAR_DEMAND_SHIFT;
    #[cfg_attr(verus_keep_ghost, verus_verify)]
    const NON_BOUND_MASK: u64 = Self::EXACT_SIGN_MASK
        | Self::INVERSE_TRIG_OR_PI_KNOWN
        | Self::CONTAINS_INVERSE_TRIG_OR_PI
        | Self::LINEAR_DEMAND_MASK;
    #[cfg_attr(verus_keep_ghost, verus_verify)]
    const MSD_SHIFT: u32 = 32;

    #[cfg(not(verus_keep_ghost))]
    fn new(
        bound: BoundCache,
        exact_sign: ExactSignCache,
        contains_inverse_trig_or_pi: bool,
        linear_demand: i16,
    ) -> Self {
        Self(std::sync::atomic::AtomicU64::new(
            Self::encode_bound(bound)
                | Self::encode_exact_sign(exact_sign)
                | ((linear_demand as u16 as u64) << Self::LINEAR_DEMAND_SHIFT)
                | Self::INVERSE_TRIG_OR_PI_KNOWN
                | if contains_inverse_trig_or_pi {
                    Self::CONTAINS_INVERSE_TRIG_OR_PI
                } else {
                    0
                },
        ))
    }

    #[cfg(not(verus_keep_ghost))]
    fn linear_demand(&self) -> i16 {
        ((self.0.load(std::sync::atomic::Ordering::Relaxed) & Self::LINEAR_DEMAND_MASK)
            >> Self::LINEAR_DEMAND_SHIFT) as u16 as i16
    }

    #[cfg(not(verus_keep_ghost))]
    fn contains_inverse_trig_or_pi(&self) -> Option<bool> {
        let bits = self.0.load(std::sync::atomic::Ordering::Relaxed);
        (bits & Self::INVERSE_TRIG_OR_PI_KNOWN != 0)
            .then_some(bits & Self::CONTAINS_INVERSE_TRIG_OR_PI != 0)
    }

    #[cfg(not(verus_keep_ghost))]
    fn store_contains_inverse_trig_or_pi(&self, value: bool) {
        let bits = Self::INVERSE_TRIG_OR_PI_KNOWN
            | if value {
                Self::CONTAINS_INVERSE_TRIG_OR_PI
            } else {
                0
            };
        self.0.fetch_or(bits, std::sync::atomic::Ordering::Relaxed);
    }

    #[cfg(not(verus_keep_ghost))]
    fn encode_bound(value: BoundCache) -> u64 {
        match value {
            BoundCache::Invalid => Self::TAG_INVALID,
            BoundCache::Valid(BoundInfo::Unknown) => Self::TAG_UNKNOWN,
            BoundCache::Valid(BoundInfo::Zero) => Self::TAG_ZERO,
            BoundCache::Valid(BoundInfo::NonZero {
                sign,
                msd,
                exact_msd,
            }) => {
                let sign = match sign {
                    None => 0,
                    Some(Sign::Plus) => 1,
                    Some(Sign::Minus) => 2,
                    Some(Sign::NoSign) => 3,
                };
                let mut encoded =
                    Self::TAG_NONZERO | ((sign as u64) << Self::SIGN_SHIFT);
                if let Some(msd) = msd {
                    encoded |= Self::MSD_PRESENT | ((msd as u32 as u64) << Self::MSD_SHIFT);
                }
                if exact_msd {
                    encoded |= Self::EXACT_MSD;
                }
                encoded
            }
        }
    }

    #[cfg(not(verus_keep_ghost))]
    fn decode_bound(value: u64) -> BoundCache {
        match value & 0b11 {
            Self::TAG_INVALID => BoundCache::Invalid,
            Self::TAG_UNKNOWN => BoundCache::Valid(BoundInfo::Unknown),
            Self::TAG_ZERO => BoundCache::Valid(BoundInfo::Zero),
            Self::TAG_NONZERO => {
                let sign = match (value >> Self::SIGN_SHIFT) & 0b11 {
                    0 => None,
                    1 => Some(Sign::Plus),
                    2 => Some(Sign::Minus),
                    3 => Some(Sign::NoSign),
                    _ => unreachable!(),
                };
                let msd = (value & Self::MSD_PRESENT != 0)
                    .then_some(((value >> Self::MSD_SHIFT) as u32) as i32);
                BoundCache::Valid(BoundInfo::NonZero {
                    sign,
                    msd,
                    exact_msd: value & Self::EXACT_MSD != 0,
                })
            }
            _ => unreachable!(),
        }
    }

    #[cfg(not(verus_keep_ghost))]
    fn bound(&self) -> BoundCache {
        Self::decode_bound(
            self.0.load(std::sync::atomic::Ordering::Relaxed) & !Self::EXACT_SIGN_MASK,
        )
    }

    #[cfg(not(verus_keep_ghost))]
    fn snapshot(&self) -> (BoundCache, ExactSignCache) {
        let encoded = self.0.load(std::sync::atomic::Ordering::Relaxed);
        (
            Self::decode_bound(encoded & !Self::EXACT_SIGN_MASK),
            Self::decode_exact_sign(encoded),
        )
    }

    #[cfg(not(verus_keep_ghost))]
    fn set_bound(&self, value: BoundCache) {
        let encoded = Self::encode_bound(value);
        let mut current = self.0.load(std::sync::atomic::Ordering::Relaxed);
        loop {
            let updated = (current & Self::NON_BOUND_MASK) | encoded;
            match self.0.compare_exchange_weak(
                current,
                updated,
                std::sync::atomic::Ordering::Relaxed,
                std::sync::atomic::Ordering::Relaxed,
            ) {
                Ok(_) => return,
                Err(observed) => current = observed,
            }
        }
    }

    #[cfg(not(verus_keep_ghost))]
    fn set_bound_if_invalid(&self, value: BoundCache) {
        let encoded = Self::encode_bound(value);
        let mut current = self.0.load(std::sync::atomic::Ordering::Relaxed);
        loop {
            if current & 0b11 != Self::TAG_INVALID {
                return;
            }
            let updated = (current & Self::NON_BOUND_MASK) | encoded;
            match self.0.compare_exchange_weak(
                current,
                updated,
                std::sync::atomic::Ordering::Relaxed,
                std::sync::atomic::Ordering::Relaxed,
            ) {
                Ok(_) => return,
                Err(observed) => current = observed,
            }
        }
    }

    #[cfg(not(verus_keep_ghost))]
    fn set_bound_if_unresolved(&self, value: BoundCache) {
        let encoded = Self::encode_bound(value);
        let mut current = self.0.load(std::sync::atomic::Ordering::Relaxed);
        loop {
            let tag = current & 0b11;
            if tag != Self::TAG_INVALID && tag != Self::TAG_UNKNOWN {
                return;
            }
            let updated = (current & Self::NON_BOUND_MASK) | encoded;
            match self.0.compare_exchange_weak(
                current,
                updated,
                std::sync::atomic::Ordering::Relaxed,
                std::sync::atomic::Ordering::Relaxed,
            ) {
                Ok(_) => return,
                Err(observed) => current = observed,
            }
        }
    }

    #[cfg_attr(verus_keep_ghost, allow(unused, verus_impl_method_marker))]
    #[cfg_attr(verus_keep_ghost, verus_spec(result =>
        ensures exact_sign_denotation(result) == value,
            result & !0x1c0u64 == 0,
            ((result >> 6) & 7) <= 4,
    ))]
    fn encode_exact_sign(value: ExactSignCache) -> u64 {
        let encoded = match value {
            ExactSignCache::Invalid => 0,
            ExactSignCache::Unknown => 1,
            ExactSignCache::Valid(Sign::Minus) => 2,
            ExactSignCache::Valid(Sign::NoSign) => 3,
            ExactSignCache::Valid(Sign::Plus) => 4,
        };
        proof! {
            assert(((encoded << 6u32) >> 6u32) & 7u64 == encoded) by (bit_vector)
                requires encoded <= 4u64;
            assert((encoded << 6u32) & !0x1c0u64 == 0u64) by (bit_vector)
                requires encoded <= 4u64;
        }
        encoded << Self::EXACT_SIGN_SHIFT
    }

    #[cfg_attr(verus_keep_ghost, allow(unused, verus_impl_method_marker))]
    #[cfg_attr(verus_keep_ghost, verus_spec(result =>
        requires ((value >> 6) & 7) <= 4,
        ensures result == exact_sign_denotation(value),
    ))]
    fn decode_exact_sign(value: u64) -> ExactSignCache {
        proof! {
            assert((value & 0x1c0u64) >> 6u32 == (value >> 6u32) & 7u64) by (bit_vector);
        }
        match (value & Self::EXACT_SIGN_MASK) >> Self::EXACT_SIGN_SHIFT {
            0 => ExactSignCache::Invalid,
            1 => ExactSignCache::Unknown,
            2 => ExactSignCache::Valid(Sign::Minus),
            3 => ExactSignCache::Valid(Sign::NoSign),
            4 => ExactSignCache::Valid(Sign::Plus),
            _ => unreachable!("invalid atomic exact-sign cache state"),
        }
    }

    #[cfg(not(verus_keep_ghost))]
    fn exact_sign(&self) -> ExactSignCache {
        Self::decode_exact_sign(self.0.load(std::sync::atomic::Ordering::Relaxed))
    }

    #[cfg(not(verus_keep_ghost))]
    fn replace_exact_sign(&self, value: ExactSignCache) -> ExactSignCache {
        let encoded = Self::encode_exact_sign(value);
        let mut current = self.0.load(std::sync::atomic::Ordering::Relaxed);
        loop {
            let updated = (current & !Self::EXACT_SIGN_MASK) | encoded;
            match self.0.compare_exchange_weak(
                current,
                updated,
                std::sync::atomic::Ordering::Relaxed,
                std::sync::atomic::Ordering::Relaxed,
            ) {
                Ok(_) => return Self::decode_exact_sign(current),
                Err(observed) => current = observed,
            }
        }
    }
}

