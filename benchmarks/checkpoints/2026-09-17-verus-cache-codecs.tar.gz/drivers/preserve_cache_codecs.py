#!/usr/bin/env python3
"""Preserve source-bound cache codec proof and its explicit limits."""
import gzip, hashlib, io, json, subprocess, tarfile
from pathlib import Path
Q=Path(__file__).resolve().parent
R=Path('/home/tim/Documents/GitHub/workspace/hyperreal')
O=Q/'cache-codec-proof'; D=R/'benchmarks/checkpoints'
def digest(data): return hashlib.sha256(data).hexdigest()
def git(*args): return subprocess.check_output(['git',*args],cwd=R,text=True).strip()
revision=git('rev-parse','HEAD')
e=json.loads((R/'target/verification/evidence.json').read_text())
assert e['verification_results']['verified']==496 and e['verification_results']['success']
assert len(e['scope']['verified_executable_contracts'])==69
assert len(e['scope']['verified_model_theorems'])==99
for name,h in e['sources'].items():
    assert digest(subprocess.check_output(['git','show',revision+':'+name],cwd=R))==h,name
assert (O/'rejections.log').read_text().count('Rejected incorrect cache codec/model:')==13
assert 'Traceback' not in (O/'rejections.log').read_text()
assert 'Ran 10 tests' in (O/'acceptance-tests.log').read_text() and '\nOK\n' in (O/'acceptance-tests.log').read_text()
for path in list((R/'src/verified').glob('*.rs'))+[R/'verification'/n for n in ['magnitude_model.rs','integer_approximation_model.rs','real_approximation_model.rs']]:
    assert path.read_bytes()==subprocess.check_output(['git','show','49f2b8f:'+str(path.relative_to(R))],cwd=R)
for name in ['src/computable/node/bounds.rs','verification/computable_bounds.rs','verification/bound_denotation.rs','verification/test_bound_rejections.py']:
    assert (R/name).read_bytes()==subprocess.check_output(['git','show','2d8cb1a:'+name],cwd=R)
erasure=Q/'cache-codec-erasure'
expanded=(erasure/'candidate-expanded-runtime.log').read_bytes()
assert expanded==(Q/'computable-metadata-complete/expanded-runtime.rs').read_bytes()
assert all(row['exit_code']==0 for row in json.loads((erasure/'runs.json').read_text()))
assert json.loads((erasure/'restoration.json').read_text())['clean']
for name,h in json.loads((erasure/'inputs.json').read_text())['overlays'].items():
    assert digest((R/name).read_bytes())==h
files=[(p,str(p.relative_to(Q))) for folder in [O,Q/'atomic-codec-trial',erasure] for p in folder.rglob('*') if p.is_file()]
for name in ['evidence.json','verus.json','verus.stderr','dependencies.json','dependencies-build.stdout','dependencies-build.stderr']:
    files.append((R/'target/verification'/name,'official/'+name))
for package in e['dependencies']['packages']:
    source=Path(package['manifest_path']).parent
    for name,h in e['dependencies']['sources'][package['id']].items():
        p=source/name;assert digest(p.read_bytes())==h
        files.append((p,'dependency-sources/'+package['name']+'-'+package['version']+'/'+name))
for name in ['src/computable/node/representation.rs','verification/computable_cache.rs','verification/cache_encoding_model.rs','verification/test_cache_rejections.py','verification/test_rejections.py','verification/scope.json','verification/README.md']:
    files.append((R/name,'committed/'+name))
for name in ['preserve_cache_codecs.py','run_atomic_codec_trial.py','check_cache_codec_erasure.py']:
    files.append((Q/name,'drivers/'+name))
archive=D/'2026-09-17-verus-cache-codecs.tar.gz'
with archive.open('wb') as raw:
    with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as compressed:
        with tarfile.open(fileobj=compressed,mode='w') as tar:
            for p,name in sorted(files,key=lambda item:item[1]):
                data=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644
                tar.addfile(info,io.BytesIO(data))
report={
    'schema':1,'status':'pure_cache_codec_proof_not_complete',
    'baseline':'a2da8e2b5de9a1a4653d3662f2f05cb6533fd7ef','proof_revision':revision,'runtime_reference':git('rev-parse','cdc6d3a'),
    'verification':{'units':496,'executable_contracts':69,'model_theorems':99,'source_hashes':len(e['sources']),
        'source_hashes_match_commit':True,'no_cheating':True,'entire_proof_target':True,'open_obligation_groups':13},
    'new_contracts':['computable_cache::AtomicFacts::'+n for n in ['encode_bound','encode_exact_sign','decode_exact_sign']],
    'new_theorems':['computable_cache::packed_bound_fields','computable_cache::encoded_bound_round_trip'],
    'negative_guards':{'new_cache_mutations_rejected':13,'acceptance_and_dependency_identity_tests':10,
        'reused_guards':[{'count':85,'artifact':'benchmarks/checkpoints/2026-09-17-verus-real-approximation-model.json'},
                       {'count':25,'artifact':'benchmarks/checkpoints/2026-09-17-verus-bound-mapping.json'}],
        'note':'The kernel/model and bound inputs are unchanged from their cited guard runs. No fresh combined 123-mutation or assumption-bypass run is claimed.'},
    'ordinary_runtime':{'byte_identical_expansion_to_runtime_reference':True,'expanded_sha256':digest(expanded),
        'lines':len(expanded.splitlines()),'checks':json.loads((erasure/'runs.json').read_text()),
        'note':'Production bodies and layout are unchanged. Added annotations and proof blocks disappear from ordinary builds; strict all-feature all-target Clippy passes.'},
    'dependency_import':{'packages':len(e['dependencies']['packages']),'source_files':sum(map(len,e['dependencies']['sources'].values())),
        'source_and_artifact_identity_checked':True,'scope':e['dependencies']['scope']},
    'experiments':[
        'Copied codec bodies were used only for exploratory verifier support checks; their failed and passing runs are retained. The official target includes the actual production representation file.',
        'Bit-vector identities discharge mask, signed payload and round-trip obligations. No project assumptions or operation axioms were added.',
        'A tmpfs user quota exhausted during separate consumer feature tests also prevented the first erasure-driver write. That invocation performed no erasure check and is not counted as a pass. After cache cleanup, the complete driver passed.'
    ],
    'limits':[
        'Pure packing preserves every typed BoundCache state and all sign, exponent and exactness fields. The lossless theorem uses the actual encode_bound contract and an independent decoder specification.',
        'Exact-sign decoding requires a valid tag (0 through 4); production callers must still establish that invariant. The actual bound decoder remains outside this added executable boundary.',
        'Atomic loads, updates, memory ordering, cache publication, stored denotation, unsafe memory, allocation, cancellation and callers remain open. Importing the AtomicU64 datatype does not certify any of those operations.',
        'All thirteen whole-implementation proof groups and final baseline acceptance remain incomplete.'
    ],
    'artifact':{'path':str(archive.relative_to(R)),'bytes':archive.stat().st_size,'files':len(files),'sha256':digest(archive.read_bytes())},
}
(D/'2026-09-17-verus-cache-codecs.json').write_text(json.dumps(report,indent=2)+'\n')
print(report['verification']);print(report['artifact'])
