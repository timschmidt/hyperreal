#!/usr/bin/env python3
"""Build original Criterion suites with the isolated cache accessor hint."""
import hashlib,json,os,shutil,subprocess,time
from pathlib import Path
Q=Path(__file__).resolve().parent
SOURCE=Q/'source'; OUT=Q/'cache-inline-fix'; CONFIG=json.loads((Q/'run.json').read_text())
ENV=CONFIG['environment'] | {'CARGO_BUILD_JOBS':'4','CCACHE_DISABLE':'1'}
assert not subprocess.check_output(['git','status','--porcelain'],cwd=SOURCE,text=True)
path=SOURCE/'src/real/arithmetic/classification.rs'; original=path.read_bytes()
needle=b'    pub(super) fn get(&self) -> PrimitiveApproxCache {'
assert original.count(needle)==1
command=['cargo','bench','--locked','--offline','--features','simple','--benches','--no-run','--message-format=json']
started=time.time()
try:
 path.write_bytes(original.replace(needle,b'    #[inline]\n'+needle))
 with (OUT/'bench-build.stdout').open('w') as out, (OUT/'bench-build.stderr').open('w') as err:
  result=subprocess.run(command,cwd=SOURCE,env=os.environ | ENV,stdout=out,stderr=err)
 records={}
 if result.returncode==0:
  (OUT/'bin').mkdir(exist_ok=True)
  for line in (OUT/'bench-build.stdout').read_text().splitlines():
   a=json.loads(line)
   if a.get('reason')!='compiler-artifact' or not a.get('executable') or a['target']['kind']!=['bench']:continue
   dest=OUT/'bin'/a['target']['name'];shutil.copy2(a['executable'],dest)
   records[dest.name]={'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'bytes':dest.stat().st_size,'features':a['features'],'target':a['target']}
  (OUT/'binaries.json').write_text(json.dumps(records,indent=2)+'\n')
 (OUT/'bench-build.json').write_text(json.dumps({'runtime_base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip(),
  'patch_sha256':hashlib.sha256((OUT/'change.patch').read_bytes()).hexdigest(),'command':command,'environment':ENV,'cwd':str(SOURCE),
  'exit_code':result.returncode,'seconds':time.time()-started,'binaries':records},indent=2)+'\n')
 print('bench-build',result.returncode,round(time.time()-started,1),flush=True)
finally:
 path.write_bytes(original)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=SOURCE,text=True)
raise SystemExit(result.returncode)
