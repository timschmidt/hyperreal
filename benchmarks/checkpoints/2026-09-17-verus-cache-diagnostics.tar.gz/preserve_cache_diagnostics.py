#!/usr/bin/env python3
"""Preserve cache regression investigations and completed pinned-consumer follow-ups."""
import gzip,hashlib,io,json,tarfile
from pathlib import Path
Q=Path(__file__).resolve().parent;REPO=Path('/home/tim/Documents/GitHub/workspace/hyperreal');DEST=REPO/'benchmarks/checkpoints'
config=json.loads((Q/'run.json').read_text())
for name,count in [('three-probe-native',54),('cache-inline-native',54),('cache-inline-criterion',18)]:
 runs=json.loads((Q/name/'runs.json').read_text())
 assert len(runs)==count and all(r['exit_code']==0 for r in runs)
 assert (Q/name/'comparison.json').exists()
followups=[r for r in json.loads((Q/'consumer-resumed-results.json').read_text()) if r['step'] in ['tests-all-remaining-6','isolated-slow-5','isolated-slow-6']]
assert len(followups)==6
files={Q/name for name in ['run.json','consumers.json','representation-probe-builds.json','consumer-resumed-results.json',
 'resume_consumers.py','resume_consumers_v2.py','time_three_representation_probes.py','time_cache_inline_probes.py',
 'summarize_native_probes.py','time_cache_inline_criterion.py','summarize_cache_criterion.py','build_cache_inline_benches.py','preserve_cache_diagnostics.py',
 'representation-probe/Cargo.toml','representation-probe/Cargo.lock','representation-probe/src/main.rs',
 'fraction-candidate/representation-probe/binary.json','fraction-candidate/binaries.json']}
for name in ['three-probe-native','three-probe-native-initial','cache-inline-native','cache-inline-criterion']:
 files.update(p for p in (Q/name).rglob('*') if p.is_file())
files.update(p for p in (Q/'cache-inline-fix').iterdir() if p.is_file() and p.name!='probe')
for r in followups:files.update(Path(r[k]) for k in ['stdout','stderr'])
archive=DEST/'2026-09-17-verus-cache-diagnostics.tar.gz'
with archive.open('wb') as output:
 with gzip.GzipFile(fileobj=output,mode='wb',filename='',mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as tar:
   for path in sorted(files):
    data=path.read_bytes();info=tarfile.TarInfo(str(path.relative_to(Q)));info.size=len(data);info.mode=0o644
    tar.addfile(info,io.BytesIO(data))
def compact_native(name):
 data=json.loads((Q/name/'comparison.json').read_text())
 return [{'case':r['case'],'label':r['label'],
          'median_paired_change_percent':r.get('median_paired_change_percent',r.get('median_pair_change_percent')),
          'paired_cycles_change_percent':[p.get('change_percent',p.get('percent'))['cycles:u'] for p in r.get('pairs',r.get('rounds'))]}
         for r in data.get('comparisons',data.get('rows'))]
def compact_criterion():
 data=json.loads((Q/'cache-inline-criterion/comparison.json').read_text())
 return [{'case':r['case'],'label':r['label'],'median_paired_mean_change_percent':r['median_paired_mean_change_percent'],
          'paired_mean_change_percent':[p['mean_change_percent'] for p in r['pairs']],
          'paired_mean_intervals_overlap':[p['mean_intervals_overlap'] for p in r['pairs']]}
         for r in data['comparisons']]
report={'schema':1,'status':'investigation_not_acceptance','baseline':config['baseline'],
 'runtime_candidate':'8c7484915da3f39d6a6754c7411277b2809cb467',
 'earlier_runtime_candidate':config['candidate'],
 'native_original':compact_native('three-probe-native'),
 'native_inline_experiment':compact_native('cache-inline-native'),
 'criterion_inline_experiment':compact_criterion(),
 'assembly_observation':{'function':'AtomicPrimitiveApproxCache::get','bytes':55,'identical_instruction_bytes':True,
  'start_address_mod_64':{'baseline':0,'598f059':0,'8c74849':48},
  'interpretation':'Identical out-of-line accessor instructions cross a cache-line boundary only in the fraction probe. Placement may contribute to extra cycles; this observation does not establish it as the sole cause.'},
 'consumer_followups':{'consumer':'hypercurve','revision':'8228394f174be2ae607694682defb167f030f540','records':followups,
  'interpretation':'Both pinned variants time out in remaining-six (900 seconds) and radical cusp (120 seconds); both fail retained mixed fillet with Blocked(Boolean,RationalBezier,Predicate) at analytic_parallel_region.rs:247. These are failures, not passes. Live Hypercurve was not edited.'},
 'limits':['Experiments are based on 8c74849; neither inline overlay nor direct cache snapshot is accepted by this checkpoint.',
  'Focused timings do not establish baseline parity across the repository; the full proof and source-bound acceptance remain pending.',
  'No owned compilation, tests or profilers ran during native timing. Host frequency, thermals, ASLR and unrelated activity remain uncontrolled.',
  'The initial software-counter parser failure is retained and excluded from the restarted balanced run.'],
 'artifact':{'path':str(archive.relative_to(REPO)),'bytes':archive.stat().st_size,'files':len(files),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}}
(DEST/'2026-09-17-verus-cache-diagnostics.json').write_text(json.dumps(report,indent=2)+'\n')
print(report['artifact'])
