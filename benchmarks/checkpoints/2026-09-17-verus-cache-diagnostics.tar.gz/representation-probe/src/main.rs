use hyperreal::{Rational, Real};
use std::{hint::black_box, time::Instant};

fn main() {
    let mut arguments = std::env::args().skip(1);
    let case = arguments.next().expect("case");
    let iterations: u64 = arguments.next().expect("iterations").parse().unwrap();
    assert!(arguments.next().is_none());
    let value = match case.as_str() {
        "pi_pow_clone" => {
            let pi = Real::pi();
            &pi * &pi
        }
        "pi_clone" => Real::pi(),
        "tan_pi_cached" => Real::new(Rational::fraction(1, 5).unwrap()).tan_pi().unwrap(),
        _ => panic!("unknown case"),
    };
    let expected = value.to_f64_lossy().unwrap();
    assert!(expected.is_finite());
    let started = Instant::now();
    if case == "tan_pi_cached" {
        for _ in 0..iterations {
            black_box(black_box(&value).to_f64_lossy());
        }
    } else {
        for _ in 0..iterations {
            black_box(black_box(&value).clone());
        }
    }
    let elapsed = started.elapsed();
    assert_eq!(value.to_f64_lossy(), Some(expected));
    assert_eq!(value.clone().to_f64_lossy(), Some(expected));
    println!("{case},{iterations},{},{}", elapsed.as_nanos(), expected.to_bits());
}
