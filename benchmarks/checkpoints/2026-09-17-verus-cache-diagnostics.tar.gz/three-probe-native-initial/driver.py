#!/usr/bin/env python3
"""Balanced native diagnostics for baseline and both runtime revisions.

Run only after all owned compilation, tests and profiling have finished.
These auxiliary probes do not replace the original Criterion comparisons.
"""
import csv,hashlib,json,os,shutil,subprocess,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
CONFIG=json.loads((ROOT/'run.json').read_text())
REVISIONS={'baseline':CONFIG['baseline'],'candidate':CONFIG['candidate'],
           'fraction-candidate':'8c7484915da3f39d6a6754c7411277b2809cb467'}
ORDERS=[['baseline','candidate','fraction-candidate'],['fraction-candidate','candidate','baseline'],
        ['candidate','fraction-candidate','baseline'],['baseline','fraction-candidate','candidate'],
        ['fraction-candidate','baseline','candidate'],['candidate','baseline','fraction-candidate']]
CASES={'pi_pow_clone':20_000_000,'pi_clone':40_000_000,'tan_pi_cached':1_000_000_000}
OUTPUT=ROOT/'three-probe-native'
RUNTIME=ROOT/'three-probe-runtime'
OUTPUT.mkdir();RUNTIME.mkdir()
CONTROLLED=CONFIG['environment'] | {'LC_ALL':'C'}
ENV=os.environ | CONTROLLED
RECORDS=[]
DIGESTS={label:hashlib.sha256((ROOT/label/'representation-probe/probe').read_bytes()).hexdigest() for label in REVISIONS}
for build in json.loads((ROOT/'representation-probe-builds.json').read_text()):
    assert build['revision']==REVISIONS[build['label']]
    assert build['binary_sha256']==DIGESTS[build['label']]
latest=json.loads((ROOT/'fraction-candidate/representation-probe/binary.json').read_text())
assert latest['revision']==REVISIONS['fraction-candidate'] and latest['sha256']==DIGESTS['fraction-candidate']
EVENTS={'task-clock','cycles:u','instructions:u','branches:u','branch-misses:u'}
(OUTPUT/'config.json').write_text(json.dumps({'revisions':REVISIONS,'orders':ORDERS,'cases':CASES,'environment':CONTROLLED,
    'binary_sha256':DIGESTS,'cpu':2,'compiler':CONFIG['compiler'],
    'limits':['Auxiliary native loops, not original Criterion call sites','Host frequency, temperature, ASLR and unrelated user activity are uncontrolled']},indent=2)+'\n')

def frequency():
    p=Path('/sys/devices/system/cpu/cpu2/cpufreq/scaling_cur_freq')
    return p.read_text().strip() if p.exists() else None

for case,iterations in CASES.items():
    for round_number,order in enumerate(ORDERS,1):
        for label in order:
            folder=OUTPUT/case/str(round_number)/label;folder.mkdir(parents=True)
            binary=RUNTIME/'probe';shutil.copy2(ROOT/label/'representation-probe/probe',binary)
            assert hashlib.sha256(binary.read_bytes()).hexdigest()==DIGESTS[label]
            counter_file=RUNTIME/'perf.csv'
            command=['perf','stat','--no-big-num','-x',',','-o',str(counter_file),'-e',
                     'task-clock,cycles:u,instructions:u,branches:u,branch-misses:u','--','taskset','-c','2',str(binary),case,str(iterations)]
            before=os.getloadavg();frequency_before=frequency();start=time.time()
            with (folder/'run.log').open('w') as log:
                result=subprocess.run(command,cwd=RUNTIME,env=ENV,stdout=log,stderr=subprocess.STDOUT)
            counters=[]
            if counter_file.exists():
                shutil.move(counter_file,folder/'perf.csv')
                for row in csv.reader((folder/'perf.csv').read_text().splitlines()):
                    if len(row)<3 or row[0].startswith('#') or row[2].strip() not in EVENTS:continue
                    try:value=float(row[0])
                    except ValueError:value=None
                    counters.append({'value':value,'unit':row[1],'event':row[2].strip(),'raw':row})
            record={'label':label,'revision':REVISIONS[label],'case':case,'iterations':iterations,'round':round_number,
                    'command':command,'cwd':str(RUNTIME),'exit_code':result.returncode,'seconds':time.time()-start,
                    'start_unix':start,'binary_sha256':DIGESTS[label],'load_before':before,'load_after':os.getloadavg(),
                    'frequency_khz_before':frequency_before,'frequency_khz_after':frequency(),
                    'counters':counters,'directory':str(folder),'all_counters_numeric':len(counters)==5 and all(c['value'] is not None for c in counters)}
            RECORDS.append(record)
            (OUTPUT/'runs.json').write_text(json.dumps(RECORDS,indent=2)+'\n')
            print(case,round_number,label,result.returncode,round(record['seconds'],1),record['all_counters_numeric'],flush=True)
            if result.returncode or not record['all_counters_numeric']:
                raise SystemExit(result.returncode or 1)
