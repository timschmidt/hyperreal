
baseline/representation-probe/probe:     file format elf64-x86-64


Disassembly of section .text:

0000000000075940 <<hyperreal::real::arithmetic::AtomicPrimitiveApproxCache>::get>:
   75940:	48 8b 07             	mov    (%rdi),%rax
   75943:	48 b9 03 00 00 00 00 	movabs $0x7ff8000000000003,%rcx
   7594a:	00 f8 7f 
   7594d:	48 39 c8             	cmp    %rcx,%rax
   75950:	74 17                	je     75969 <<hyperreal::real::arithmetic::AtomicPrimitiveApproxCache>::get+0x29>
   75952:	48 b9 01 00 00 00 00 	movabs $0x7ff8000000000001,%rcx
   75959:	00 f8 7f 
   7595c:	48 39 c8             	cmp    %rcx,%rax
   7595f:	75 0b                	jne    7596c <<hyperreal::real::arithmetic::AtomicPrimitiveApproxCache>::get+0x2c>
   75961:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   75968:	c3                   	ret
   75969:	31 c0                	xor    %eax,%eax
   7596b:	c3                   	ret
   7596c:	66 48 0f 6e c0       	movq   %rax,%xmm0
   75971:	b8 01 00 00 00       	mov    $0x1,%eax
   75976:	c3                   	ret
