
baseline/representation-probe/probe:     file format elf64-x86-64


Disassembly of section .text:

000000000004b760 <hyperreal_representation_probe::main>:
   4b760:	push   %rbp
   4b761:	push   %r15
   4b763:	push   %r14
   4b765:	push   %r13
   4b767:	push   %r12
   4b769:	push   %rbx
   4b76a:	sub    $0x128,%rsp
   4b771:	lea    0x58(%rsp),%rbx
   4b776:	mov    %rbx,%rdi
   4b779:	call   *0x106491(%rip)        # 151c10 <_DYNAMIC+0x3c8>
   4b77f:	movq   $0x0,0x78(%rsp)
   4b788:	lea    0x10(%rsp),%rdi
   4b78d:	mov    %rbx,%rsi
   4b790:	call   *0x106472(%rip)        # 151c08 <_DYNAMIC+0x3c0>
   4b796:	mov    0x10(%rsp),%rsi
   4b79b:	test   %rsi,%rsi
   4b79e:	je     4b7ba <hyperreal_representation_probe::main+0x5a>
   4b7a0:	cmp    $0xffffffffffffffff,%rsi
   4b7a4:	je     4bf85 <hyperreal_representation_probe::main+0x825>
   4b7aa:	mov    0x18(%rsp),%rdi
   4b7af:	mov    $0x1,%edx
   4b7b4:	call   *0x10634e(%rip)        # 151b08 <_DYNAMIC+0x2c0>
   4b7ba:	lea    0x10(%rsp),%rdi
   4b7bf:	lea    0x58(%rsp),%rsi
   4b7c4:	call   *0x10643e(%rip)        # 151c08 <_DYNAMIC+0x3c0>
   4b7ca:	cmpq   $0xffffffffffffffff,0x10(%rsp)
   4b7d0:	je     4bf85 <hyperreal_representation_probe::main+0x825>
   4b7d6:	mov    0x20(%rsp),%rax
   4b7db:	mov    %rax,0xc0(%rsp)
   4b7e3:	movdqu 0x10(%rsp),%xmm0
   4b7e9:	movdqa %xmm0,0xb0(%rsp)
   4b7f2:	mov    0x78(%rsp),%rsi
   4b7f7:	test   %rsi,%rsi
   4b7fa:	jne    4bfa3 <hyperreal_representation_probe::main+0x843>
   4b800:	lea    0x10(%rsp),%rdi
   4b805:	lea    0x58(%rsp),%rsi
   4b80a:	call   *0x1063f8(%rip)        # 151c08 <_DYNAMIC+0x3c0>
   4b810:	mov    0x10(%rsp),%rsi
   4b815:	cmp    $0xffffffffffffffff,%rsi
   4b819:	je     4bfbf <hyperreal_representation_probe::main+0x85f>
   4b81f:	mov    0x18(%rsp),%rdi
   4b824:	mov    0x20(%rsp),%rcx
   4b829:	cmp    $0x1,%rcx
   4b82d:	je     4b83d <hyperreal_representation_probe::main+0xdd>
   4b82f:	test   %rcx,%rcx
   4b832:	je     4c108 <hyperreal_representation_probe::main+0x9a8>
   4b838:	movzbl (%rdi),%edx
   4b83b:	jmp    4b854 <hyperreal_representation_probe::main+0xf4>
   4b83d:	movzbl (%rdi),%edx
   4b840:	mov    $0x1,%al
   4b842:	cmp    $0x2b,%edx
   4b845:	je     4bf51 <hyperreal_representation_probe::main+0x7f1>
   4b84b:	cmp    $0x2d,%edx
   4b84e:	je     4bf51 <hyperreal_representation_probe::main+0x7f1>
   4b854:	xor    %r8d,%r8d
   4b857:	cmp    $0x2b,%dl
   4b85a:	sete   %r8b
   4b85e:	mov    %r8,%rax
   4b861:	neg    %rax
   4b864:	mov    %rcx,%rdx
   4b867:	sub    %r8,%rdx
   4b86a:	add    %rdi,%r8
   4b86d:	cmp    $0x11,%rdx
   4b871:	jae    4b8b8 <hyperreal_representation_probe::main+0x158>
   4b873:	test   %rdx,%rdx
   4b876:	je     4b909 <hyperreal_representation_probe::main+0x1a9>
   4b87c:	add    %rax,%rcx
   4b87f:	neg    %rcx
   4b882:	xor    %ebx,%ebx
   4b884:	xor    %eax,%eax
   4b886:	cs nopw 0x0(%rax,%rax,1)
   4b890:	movzbl (%r8,%rax,1),%edx
   4b895:	add    $0xffffffd0,%edx
   4b898:	cmp    $0x9,%edx
   4b89b:	ja     4c0d1 <hyperreal_representation_probe::main+0x971>
   4b8a1:	lea    (%rbx,%rbx,4),%r9
   4b8a5:	mov    %edx,%edx
   4b8a7:	lea    (%rdx,%r9,2),%rbx
   4b8ab:	inc    %rax
   4b8ae:	mov    %rcx,%rdx
   4b8b1:	add    %rax,%rdx
   4b8b4:	jne    4b890 <hyperreal_representation_probe::main+0x130>
   4b8b6:	jmp    4b90b <hyperreal_representation_probe::main+0x1ab>
   4b8b8:	add    %rax,%rcx
   4b8bb:	neg    %rcx
   4b8be:	xor    %ebx,%ebx
   4b8c0:	mov    $0xa,%r9d
   4b8c6:	xor    %r10d,%r10d
   4b8c9:	nopl   0x0(%rax)
   4b8d0:	mov    %rcx,%rax
   4b8d3:	add    %r10,%rax
   4b8d6:	je     4b90b <hyperreal_representation_probe::main+0x1ab>
   4b8d8:	mov    %rbx,%rax
   4b8db:	mul    %r9
   4b8de:	movzbl (%r8,%r10,1),%edx
   4b8e3:	jo     4bf47 <hyperreal_representation_probe::main+0x7e7>
   4b8e9:	add    $0xffffffd0,%edx
   4b8ec:	cmp    $0xa,%edx
   4b8ef:	jae    4c0d1 <hyperreal_representation_probe::main+0x971>
   4b8f5:	mov    %rax,%rbx
   4b8f8:	mov    %edx,%eax
   4b8fa:	inc    %r10
   4b8fd:	add    %rax,%rbx
   4b900:	jae    4b8d0 <hyperreal_representation_probe::main+0x170>
   4b902:	mov    $0x2,%al
   4b904:	jmp    4bf51 <hyperreal_representation_probe::main+0x7f1>
   4b909:	xor    %ebx,%ebx
   4b90b:	mov    %rbx,0x110(%rsp)
   4b913:	test   %rsi,%rsi
   4b916:	je     4b923 <hyperreal_representation_probe::main+0x1c3>
   4b918:	mov    $0x1,%edx
   4b91d:	call   *0x1061e5(%rip)        # 151b08 <_DYNAMIC+0x2c0>
   4b923:	mov    0x78(%rsp),%rsi
   4b928:	test   %rsi,%rsi
   4b92b:	jne    4bfdd <hyperreal_representation_probe::main+0x87d>
   4b931:	lea    0x10(%rsp),%rdi
   4b936:	lea    0x58(%rsp),%rsi
   4b93b:	call   *0x1062c7(%rip)        # 151c08 <_DYNAMIC+0x3c0>
   4b941:	mov    0x10(%rsp),%rsi
   4b946:	cmp    $0xffffffffffffffff,%rsi
   4b94a:	jne    4c0d8 <hyperreal_representation_probe::main+0x978>
   4b950:	mov    0xb8(%rsp),%r12
   4b958:	mov    0xc0(%rsp),%r13
   4b960:	cmp    $0x8,%r13
   4b964:	je     4b9be <hyperreal_representation_probe::main+0x25e>
   4b966:	cmp    $0xc,%r13
   4b96a:	jne    4b9e5 <hyperreal_representation_probe::main+0x285>
   4b96c:	movabs $0x635f776f705f6970,%rax
   4b976:	xor    (%r12),%rax
   4b97a:	mov    0x8(%r12),%ecx
   4b97f:	xor    $0x656e6f6c,%rcx
   4b986:	or     %rax,%rcx
   4b989:	jne    4c06d <hyperreal_representation_probe::main+0x90d>
   4b98f:	lea    0x10(%rsp),%rdi
   4b994:	call   *0x10627e(%rip)        # 151c18 <_DYNAMIC+0x3d0>
   4b99a:	lea    0xd0(%rsp),%rdi
   4b9a2:	lea    0x10(%rsp),%rdx
   4b9a7:	mov    %rdx,%rsi
   4b9aa:	call   48be0 <<&hyperreal::real::arithmetic::Real as core::ops::arith::Mul>::mul>
   4b9af:	lea    0x10(%rsp),%rdi
   4b9b4:	call   4b350 <core::ptr::drop_glue::<hyperreal::real::arithmetic::Real>>
   4b9b9:	jmp    4bab4 <hyperreal_representation_probe::main+0x354>
   4b9be:	movabs $0x656e6f6c635f6970,%rax
   4b9c8:	cmp    %rax,(%r12)
   4b9cc:	jne    4c06d <hyperreal_representation_probe::main+0x90d>
   4b9d2:	lea    0xd0(%rsp),%rdi
   4b9da:	call   *0x106238(%rip)        # 151c18 <_DYNAMIC+0x3d0>
   4b9e0:	jmp    4bab4 <hyperreal_representation_probe::main+0x354>
   4b9e5:	cmp    $0xd,%r13
   4b9e9:	jne    4c06d <hyperreal_representation_probe::main+0x90d>
   4b9ef:	movabs $0x635f69705f6e6174,%rax
   4b9f9:	xor    (%r12),%rax
   4b9fd:	movabs $0x6465686361635f69,%rcx
   4ba07:	xor    0x5(%r12),%rcx
   4ba0c:	or     %rax,%rcx
   4ba0f:	jne    4c06d <hyperreal_representation_probe::main+0x90d>
   4ba15:	lea    0x10(%rsp),%rdi
   4ba1a:	mov    $0x1,%esi
   4ba1f:	mov    $0x5,%edx
   4ba24:	call   *0x1061f6(%rip)        # 151c20 <_DYNAMIC+0x3d8>
   4ba2a:	cmpb   $0x1,0x10(%rsp)
   4ba2f:	je     4c088 <hyperreal_representation_probe::main+0x928>
   4ba35:	mov    0x18(%rsp),%rax
   4ba3a:	mov    %rax,0x20(%rsp)
   4ba3f:	movb   $0x0,0x10(%rsp)
   4ba44:	movq   $0x0,0x28(%rsp)
   4ba4d:	movabs $0x7ff8000000000001,%rax
   4ba57:	mov    %rax,0x38(%rsp)
   4ba5c:	lea    0x80(%rsp),%rdi
   4ba64:	lea    0x10(%rsp),%r14
   4ba69:	mov    %r14,%rsi
   4ba6c:	call   *0x1061b6(%rip)        # 151c28 <_DYNAMIC+0x3e0>
   4ba72:	cmpb   $0xff,0x80(%rsp)
   4ba7a:	je     4c09e <hyperreal_representation_probe::main+0x93e>
   4ba80:	movdqu 0x80(%rsp),%xmm0
   4ba89:	movupd 0x90(%rsp),%xmm1
   4ba92:	movups 0xa0(%rsp),%xmm2
   4ba9a:	movaps %xmm2,0xf0(%rsp)
   4baa2:	movapd %xmm1,0xe0(%rsp)
   4baab:	movdqa %xmm0,0xd0(%rsp)
   4bab4:	lea    0xf8(%rsp),%r14
   4babc:	mov    %r14,%rdi
   4babf:	call   *0x106133(%rip)        # 151bf8 <_DYNAMIC+0x3b0>
   4bac5:	movq   %xmm0,0x50(%rsp)
   4bacb:	mov    %rax,%r15
   4bace:	cmp    $0xffffffffffffffff,%rax
   4bad2:	jne    4bb0f <hyperreal_representation_probe::main+0x3af>
   4bad4:	lea    0xd0(%rsp),%rdi
   4badc:	call   *0x10614e(%rip)        # 151c30 <_DYNAMIC+0x3e8>
   4bae2:	movq   %xmm0,0x50(%rsp)
   4bae8:	mov    %rax,%r15
   4baeb:	lea    0xd0(%rsp),%rdi
   4baf3:	call   *0x10613f(%rip)        # 151c38 <_DYNAMIC+0x3f0>
   4baf9:	test   %al,%al
   4bafb:	jne    4bb0f <hyperreal_representation_probe::main+0x3af>
   4bafd:	mov    %r14,%rdi
   4bb00:	mov    %r15,%rsi
   4bb03:	movq   0x50(%rsp),%xmm0
   4bb09:	call   *0x1060d1(%rip)        # 151be0 <_DYNAMIC+0x398>
   4bb0f:	cmp    $0x1,%r15
   4bb13:	jne    4bffe <hyperreal_representation_probe::main+0x89e>
   4bb19:	movq   0x50(%rsp),%xmm0
   4bb1f:	movq   %xmm0,%rax
   4bb24:	movabs $0x7fffffffffffffff,%rcx
   4bb2e:	and    %rax,%rcx
   4bb31:	movabs $0x7fefffffffffffff,%rax
   4bb3b:	cmp    %rax,%rcx
   4bb3e:	jg     4c010 <hyperreal_representation_probe::main+0x8b0>
   4bb44:	call   *0x1060f6(%rip)        # 151c40 <_DYNAMIC+0x3f8>
   4bb4a:	mov    %rax,0x118(%rsp)
   4bb52:	mov    %edx,0x120(%rsp)
   4bb59:	cmp    $0xd,%r13
   4bb5d:	jne    4bb85 <hyperreal_representation_probe::main+0x425>
   4bb5f:	movabs $0x635f69705f6e6174,%rax
   4bb69:	xor    (%r12),%rax
   4bb6d:	movabs $0x6465686361635f69,%rcx
   4bb77:	xor    0x5(%r12),%rcx
   4bb7c:	or     %rax,%rcx
   4bb7f:	je     4beb3 <hyperreal_representation_probe::main+0x753>
   4bb85:	test   %rbx,%rbx
   4bb88:	je     4bbea <hyperreal_representation_probe::main+0x48a>
   4bb8a:	lea    0xd0(%rsp),%r14
   4bb92:	lea    0x10(%rsp),%r15
   4bb97:	lea    0x80(%rsp),%r12
   4bb9f:	nop
   4bba0:	mov    %r14,0x10(%rsp)
   4bba5:	mov    0x10(%rsp),%rsi
   4bbaa:	mov    %r15,%rdi
   4bbad:	call   4da90 <<hyperreal::real::arithmetic::Real as core::clone::Clone>::clone>
   4bbb2:	movdqu 0x10(%rsp),%xmm0
   4bbb8:	movupd 0x20(%rsp),%xmm1
   4bbbe:	movups 0x30(%rsp),%xmm2
   4bbc3:	movaps %xmm2,0xa0(%rsp)
   4bbcb:	movapd %xmm1,0x90(%rsp)
   4bbd4:	movdqa %xmm0,0x80(%rsp)
   4bbdd:	mov    %r12,%rdi
   4bbe0:	call   4b350 <core::ptr::drop_glue::<hyperreal::real::arithmetic::Real>>
   4bbe5:	dec    %rbx
   4bbe8:	jne    4bba0 <hyperreal_representation_probe::main+0x440>
   4bbea:	lea    0x118(%rsp),%rdi
   4bbf2:	call   *0x106050(%rip)        # 151c48 <_DYNAMIC+0x400>
   4bbf8:	lea    0xf8(%rsp),%r14
   4bc00:	mov    %rax,%r15
   4bc03:	mov    %edx,%ebx
   4bc05:	mov    %r14,%rdi
   4bc08:	call   *0x105fea(%rip)        # 151bf8 <_DYNAMIC+0x3b0>
   4bc0e:	movq   %xmm0,0x8(%rsp)
   4bc14:	mov    %rax,%r12
   4bc17:	cmp    $0xffffffffffffffff,%rax
   4bc1b:	jne    4bc58 <hyperreal_representation_probe::main+0x4f8>
   4bc1d:	lea    0xd0(%rsp),%rdi
   4bc25:	call   *0x106005(%rip)        # 151c30 <_DYNAMIC+0x3e8>
   4bc2b:	movq   %xmm0,0x8(%rsp)
   4bc31:	mov    %rax,%r12
   4bc34:	lea    0xd0(%rsp),%rdi
   4bc3c:	call   *0x105ff6(%rip)        # 151c38 <_DYNAMIC+0x3f0>
   4bc42:	test   %al,%al
   4bc44:	jne    4bc58 <hyperreal_representation_probe::main+0x4f8>
   4bc46:	mov    %r14,%rdi
   4bc49:	mov    %r12,%rsi
   4bc4c:	movq   0x8(%rsp),%xmm0
   4bc52:	call   *0x105f88(%rip)        # 151be0 <_DYNAMIC+0x398>
   4bc58:	mov    %r12,0x80(%rsp)
   4bc60:	movsd  0x8(%rsp),%xmm1
   4bc66:	movsd  %xmm1,0x88(%rsp)
   4bc6f:	movq   $0x1,0x10(%rsp)
   4bc78:	movsd  0x50(%rsp),%xmm0
   4bc7e:	movsd  %xmm0,0x18(%rsp)
   4bc84:	cmp    $0x1,%r12
   4bc88:	jne    4c02e <hyperreal_representation_probe::main+0x8ce>
   4bc8e:	ucomisd %xmm0,%xmm1
   4bc92:	jne    4c02e <hyperreal_representation_probe::main+0x8ce>
   4bc98:	jp     4c02e <hyperreal_representation_probe::main+0x8ce>
   4bc9e:	lea    0x10(%rsp),%rdi
   4bca3:	lea    0xd0(%rsp),%rsi
   4bcab:	call   4da90 <<hyperreal::real::arithmetic::Real as core::clone::Clone>::clone>
   4bcb0:	lea    0x38(%rsp),%r12
   4bcb5:	mov    %r12,%rdi
   4bcb8:	call   *0x105f3a(%rip)        # 151bf8 <_DYNAMIC+0x3b0>
   4bcbe:	movsd  %xmm0,0x8(%rsp)
   4bcc4:	mov    %rax,%r14
   4bcc7:	cmp    $0xffffffffffffffff,%rax
   4bccb:	jne    4bd02 <hyperreal_representation_probe::main+0x5a2>
   4bccd:	lea    0x10(%rsp),%rdi
   4bcd2:	call   *0x105f58(%rip)        # 151c30 <_DYNAMIC+0x3e8>
   4bcd8:	movsd  %xmm0,0x8(%rsp)
   4bcde:	mov    %rax,%r14
   4bce1:	lea    0x10(%rsp),%rdi
   4bce6:	call   *0x105f4c(%rip)        # 151c38 <_DYNAMIC+0x3f0>
   4bcec:	test   %al,%al
   4bcee:	jne    4bd02 <hyperreal_representation_probe::main+0x5a2>
   4bcf0:	mov    %r12,%rdi
   4bcf3:	mov    %r14,%rsi
   4bcf6:	movsd  0x8(%rsp),%xmm0
   4bcfc:	call   *0x105ede(%rip)        # 151be0 <_DYNAMIC+0x398>
   4bd02:	mov    %r14,0x100(%rsp)
   4bd0a:	movsd  0x8(%rsp),%xmm1
   4bd10:	movsd  %xmm1,0x108(%rsp)
   4bd19:	movq   $0x1,0x80(%rsp)
   4bd25:	movsd  0x50(%rsp),%xmm0
   4bd2b:	movsd  %xmm0,0x88(%rsp)
   4bd34:	cmp    $0x1,%r14
   4bd38:	jne    4c04c <hyperreal_representation_probe::main+0x8ec>
   4bd3e:	ucomisd %xmm0,%xmm1
   4bd42:	jne    4c04c <hyperreal_representation_probe::main+0x8ec>
   4bd48:	jp     4c04c <hyperreal_representation_probe::main+0x8ec>
   4bd4e:	lea    0x10(%rsp),%rdi
   4bd53:	call   4b350 <core::ptr::drop_glue::<hyperreal::real::arithmetic::Real>>
   4bd58:	mov    $0x3b9aca00,%ecx
   4bd5d:	mov    %r15,%rax
   4bd60:	mul    %rcx
   4bd63:	mov    %ebx,%ecx
   4bd65:	add    %rax,%rcx
   4bd68:	adc    $0x0,%rdx
   4bd6c:	mov    %rcx,0x80(%rsp)
   4bd74:	mov    %rdx,0x88(%rsp)
   4bd7c:	movq   0x50(%rsp),%xmm0
   4bd82:	movq   %xmm0,0x100(%rsp)
   4bd8b:	lea    0xb0(%rsp),%rax
   4bd93:	mov    %rax,0x10(%rsp)
   4bd98:	lea    0x2251(%rip),%rax        # 4dff0 <<alloc::string::String as core::fmt::Display>::fmt>
   4bd9f:	mov    %rax,0x18(%rsp)
   4bda4:	lea    0x110(%rsp),%rax
   4bdac:	mov    %rax,0x20(%rsp)
   4bdb1:	mov    0x105e98(%rip),%rax        # 151c50 <_DYNAMIC+0x408>
   4bdb8:	mov    %rax,0x28(%rsp)
   4bdbd:	lea    0x80(%rsp),%rcx
   4bdc5:	mov    %rcx,0x30(%rsp)
   4bdca:	mov    0x105e87(%rip),%rcx        # 151c58 <_DYNAMIC+0x410>
   4bdd1:	mov    %rcx,0x38(%rsp)
   4bdd6:	lea    0x100(%rsp),%rcx
   4bdde:	mov    %rcx,0x40(%rsp)
   4bde3:	mov    %rax,0x48(%rsp)
   4bde8:	lea    -0x29795(%rip),%rdi        # 2265a <anon.f528f8cddd6ae9d3ee873f0d5154aaae.22.llvm.10676021354292260747+0x110>
   4bdef:	lea    0x10(%rsp),%rsi
   4bdf4:	call   *0x105e66(%rip)        # 151c60 <_DYNAMIC+0x418>
   4bdfa:	lea    0xd0(%rsp),%rdi
   4be02:	call   4b350 <core::ptr::drop_glue::<hyperreal::real::arithmetic::Real>>
   4be07:	mov    0xb0(%rsp),%rsi
   4be0f:	test   %rsi,%rsi
   4be12:	je     4be27 <hyperreal_representation_probe::main+0x6c7>
   4be14:	mov    0xb8(%rsp),%rdi
   4be1c:	mov    $0x1,%edx
   4be21:	call   *0x105ce1(%rip)        # 151b08 <_DYNAMIC+0x2c0>
   4be27:	mov    0x60(%rsp),%r14
   4be2c:	mov    0x70(%rsp),%rcx
   4be31:	mov    %rcx,%rax
   4be34:	sub    %r14,%rax
   4be37:	movabs $0xaaaaaaaaaaaaaaab,%rdx
   4be41:	mul    %rdx
   4be44:	cmp    %r14,%rcx
   4be47:	je     4be7f <hyperreal_representation_probe::main+0x71f>
   4be49:	mov    %rdx,%rbx
   4be4c:	shr    $0x4,%rbx
   4be50:	add    $0x8,%r14
   4be54:	mov    0x105cad(%rip),%r15        # 151b08 <_DYNAMIC+0x2c0>
   4be5b:	jmp    4be69 <hyperreal_representation_probe::main+0x709>
   4be5d:	nopl   (%rax)
   4be60:	add    $0x18,%r14
   4be64:	dec    %rbx
   4be67:	je     4be7f <hyperreal_representation_probe::main+0x71f>
   4be69:	mov    -0x8(%r14),%rsi
   4be6d:	test   %rsi,%rsi
   4be70:	je     4be60 <hyperreal_representation_probe::main+0x700>
   4be72:	mov    (%r14),%rdi
   4be75:	mov    $0x1,%edx
   4be7a:	call   *%r15
   4be7d:	jmp    4be60 <hyperreal_representation_probe::main+0x700>
   4be7f:	mov    0x68(%rsp),%rax
   4be84:	test   %rax,%rax
   4be87:	je     4bea1 <hyperreal_representation_probe::main+0x741>
   4be89:	mov    0x58(%rsp),%rdi
   4be8e:	shl    $0x3,%rax
   4be92:	lea    (%rax,%rax,2),%rsi
   4be96:	mov    $0x8,%edx
   4be9b:	call   *0x105c67(%rip)        # 151b08 <_DYNAMIC+0x2c0>
   4bea1:	add    $0x128,%rsp
   4bea8:	pop    %rbx
   4bea9:	pop    %r12
   4beab:	pop    %r13
   4bead:	pop    %r14
   4beaf:	pop    %r15
   4beb1:	pop    %rbp
   4beb2:	ret
   4beb3:	test   %rbx,%rbx
   4beb6:	je     4bbea <hyperreal_representation_probe::main+0x48a>
   4bebc:	lea    0x10(%rsp),%r14
   4bec1:	mov    0x105d30(%rip),%rbp        # 151bf8 <_DYNAMIC+0x3b0>
   4bec8:	jmp    4beea <hyperreal_representation_probe::main+0x78a>
   4beca:	nopw   0x0(%rax,%rax,1)
   4bed0:	mov    %r15,0x10(%rsp)
   4bed5:	movq   0x8(%rsp),%xmm0
   4bedb:	movq   %xmm0,0x18(%rsp)
   4bee1:	dec    %rbx
   4bee4:	je     4bbea <hyperreal_representation_probe::main+0x48a>
   4beea:	lea    0xd0(%rsp),%rax
   4bef2:	mov    %rax,0x10(%rsp)
   4bef7:	mov    0x10(%rsp),%r13
   4befc:	lea    0x28(%r13),%r12
   4bf00:	mov    %r12,%rdi
   4bf03:	call   *%rbp
   4bf05:	movq   %xmm0,0x8(%rsp)
   4bf0b:	mov    %rax,%r15
   4bf0e:	cmp    $0xffffffffffffffff,%rax
   4bf12:	jne    4bed0 <hyperreal_representation_probe::main+0x770>
   4bf14:	mov    %r13,%rdi
   4bf17:	call   *0x105d13(%rip)        # 151c30 <_DYNAMIC+0x3e8>
   4bf1d:	movq   %xmm0,0x8(%rsp)
   4bf23:	mov    %rax,%r15
   4bf26:	mov    %r13,%rdi
   4bf29:	call   *0x105d09(%rip)        # 151c38 <_DYNAMIC+0x3f0>
   4bf2f:	test   %al,%al
   4bf31:	jne    4bed0 <hyperreal_representation_probe::main+0x770>
   4bf33:	mov    %r12,%rdi
   4bf36:	mov    %r15,%rsi
   4bf39:	movq   0x8(%rsp),%xmm0
   4bf3f:	call   *0x105c9b(%rip)        # 151be0 <_DYNAMIC+0x398>
   4bf45:	jmp    4bed0 <hyperreal_representation_probe::main+0x770>
   4bf47:	add    $0xd0,%dl
   4bf4a:	xor    %eax,%eax
   4bf4c:	cmp    $0xa,%dl
   4bf4f:	adc    $0x1,%al
   4bf51:	mov    %rdi,%r14
   4bf54:	mov    %rsi,%r15
   4bf57:	mov    %al,0x10(%rsp)
   4bf5b:	lea    -0x27830(%rip),%rdi        # 24732 <anon.989e3a3df5a9b0c8132da4bb77c7c33a.42.llvm.18117248294124708650+0x372>
   4bf62:	lea    0x10154f(%rip),%rcx        # 14d4b8 <__dso_handle+0x288>
   4bf69:	lea    0x101450(%rip),%r8        # 14d3c0 <__dso_handle+0x190>
   4bf70:	lea    0x10(%rsp),%rdx
   4bf75:	mov    $0x2b,%esi
   4bf7a:	call   *0x105ce8(%rip)        # 151c68 <_DYNAMIC+0x420>
   4bf80:	jmp    4c106 <hyperreal_representation_probe::main+0x9a6>
   4bf85:	lea    -0x27a4c(%rip),%rdi        # 24540 <anon.989e3a3df5a9b0c8132da4bb77c7c33a.42.llvm.18117248294124708650+0x180>
   4bf8c:	lea    0x1013fd(%rip),%rdx        # 14d390 <__dso_handle+0x160>
   4bf93:	mov    $0x4,%esi
   4bf98:	call   *0x105cd2(%rip)        # 151c70 <_DYNAMIC+0x428>
   4bf9e:	jmp    4c106 <hyperreal_representation_probe::main+0x9a6>
   4bfa3:	movq   $0x0,0x78(%rsp)
   4bfac:	lea    0x58(%rsp),%rdi
   4bfb1:	call   4b630 <<std::env::Args as core::iter::traits::iterator::Iterator>::try_fold::<core::num::nonzero::NonZero<usize>, <std::env::Args as core::iter::traits::iterator::Iterator::advance_by::SpecAdvanceBy>::spec_advance_by::{closure#0}, core::option::Option<core::num::nonzero::NonZero<usize>>>>
   4bfb6:	test   %rax,%rax
   4bfb9:	je     4b800 <hyperreal_representation_probe::main+0xa0>
   4bfbf:	lea    -0x27a36(%rip),%rdi        # 24590 <anon.989e3a3df5a9b0c8132da4bb77c7c33a.42.llvm.18117248294124708650+0x1d0>
   4bfc6:	lea    0x1013db(%rip),%rdx        # 14d3a8 <__dso_handle+0x178>
   4bfcd:	mov    $0xa,%esi
   4bfd2:	call   *0x105c98(%rip)        # 151c70 <_DYNAMIC+0x428>
   4bfd8:	jmp    4c106 <hyperreal_representation_probe::main+0x9a6>
   4bfdd:	movq   $0x0,0x78(%rsp)
   4bfe6:	lea    0x58(%rsp),%rdi
   4bfeb:	call   4b630 <<std::env::Args as core::iter::traits::iterator::Iterator>::try_fold::<core::num::nonzero::NonZero<usize>, <std::env::Args as core::iter::traits::iterator::Iterator::advance_by::SpecAdvanceBy>::spec_advance_by::{closure#0}, core::option::Option<core::num::nonzero::NonZero<usize>>>>
   4bff0:	test   %rax,%rax
   4bff3:	jne    4b950 <hyperreal_representation_probe::main+0x1f0>
   4bff9:	jmp    4b931 <hyperreal_representation_probe::main+0x1d1>
   4bffe:	lea    0x101433(%rip),%rdi        # 14d438 <__dso_handle+0x208>
   4c005:	call   *0x105b0d(%rip)        # 151b18 <_DYNAMIC+0x2d0>
   4c00b:	jmp    4c106 <hyperreal_representation_probe::main+0x9a6>
   4c010:	lea    -0x2790b(%rip),%rdi        # 2470c <anon.989e3a3df5a9b0c8132da4bb77c7c33a.42.llvm.18117248294124708650+0x34c>
   4c017:	lea    0x101432(%rip),%rdx        # 14d450 <__dso_handle+0x220>
   4c01e:	mov    $0x26,%esi
   4c023:	call   *0x105bbf(%rip)        # 151be8 <_DYNAMIC+0x3a0>
   4c029:	jmp    4c106 <hyperreal_representation_probe::main+0x9a6>
   4c02e:	lea    0x101433(%rip),%rdx        # 14d468 <__dso_handle+0x238>
   4c035:	lea    0x80(%rsp),%rdi
   4c03d:	lea    0x10(%rsp),%rsi
   4c042:	call   4b5e1 <core::panicking::assert_failed::<core::option::Option<f64>, core::option::Option<f64>>>
   4c047:	jmp    4c106 <hyperreal_representation_probe::main+0x9a6>
   4c04c:	lea    0x10142d(%rip),%rdx        # 14d480 <__dso_handle+0x250>
   4c053:	lea    0x100(%rsp),%rdi
   4c05b:	lea    0x80(%rsp),%rsi
   4c063:	call   4b5e1 <core::panicking::assert_failed::<core::option::Option<f64>, core::option::Option<f64>>>
   4c068:	jmp    4c106 <hyperreal_representation_probe::main+0x9a6>
   4c06d:	lea    -0x27974(%rip),%rdi        # 24700 <anon.989e3a3df5a9b0c8132da4bb77c7c33a.42.llvm.18117248294124708650+0x340>
   4c074:	lea    0x101375(%rip),%rdx        # 14d3f0 <__dso_handle+0x1c0>
   4c07b:	mov    $0x19,%esi
   4c080:	call   *0x105a8a(%rip)        # 151b10 <_DYNAMIC+0x2c8>
   4c086:	jmp    4c106 <hyperreal_representation_probe::main+0x9a6>
   4c088:	lea    0x11(%rsp),%rax
   4c08d:	lea    0x101374(%rip),%r8        # 14d408 <__dso_handle+0x1d8>
   4c094:	lea    0xd0(%rsp),%r14
   4c09c:	jmp    4c0ad <hyperreal_representation_probe::main+0x94d>
   4c09e:	lea    0x81(%rsp),%rax
   4c0a6:	lea    0x101373(%rip),%r8        # 14d420 <__dso_handle+0x1f0>
   4c0ad:	movzbl (%rax),%eax
   4c0b0:	mov    %al,(%r14)
   4c0b3:	lea    -0x27988(%rip),%rdi        # 24732 <anon.989e3a3df5a9b0c8132da4bb77c7c33a.42.llvm.18117248294124708650+0x372>
   4c0ba:	lea    0x1013d7(%rip),%rcx        # 14d498 <__dso_handle+0x268>
   4c0c1:	mov    $0x2b,%esi
   4c0c6:	mov    %r14,%rdx
   4c0c9:	call   *0x105b99(%rip)        # 151c68 <_DYNAMIC+0x420>
   4c0cf:	jmp    4c106 <hyperreal_representation_probe::main+0x9a6>
   4c0d1:	mov    $0x1,%al
   4c0d3:	jmp    4bf51 <hyperreal_representation_probe::main+0x7f1>
   4c0d8:	test   %rsi,%rsi
   4c0db:	je     4c0ed <hyperreal_representation_probe::main+0x98d>
   4c0dd:	mov    0x18(%rsp),%rdi
   4c0e2:	mov    $0x1,%edx
   4c0e7:	call   *0x105a1b(%rip)        # 151b08 <_DYNAMIC+0x2c0>
   4c0ed:	lea    -0x27b5a(%rip),%rdi        # 2459a <anon.989e3a3df5a9b0c8132da4bb77c7c33a.42.llvm.18117248294124708650+0x1da>
   4c0f4:	lea    0x1012dd(%rip),%rdx        # 14d3d8 <__dso_handle+0x1a8>
   4c0fb:	mov    $0x2c,%esi
   4c100:	call   *0x105ae2(%rip)        # 151be8 <_DYNAMIC+0x3a0>
   4c106:	ud2
   4c108:	xor    %eax,%eax
   4c10a:	jmp    4bf51 <hyperreal_representation_probe::main+0x7f1>
   4c10f:	mov    %rax,%rbx
   4c112:	lea    0x10(%rsp),%rdi
   4c117:	call   4b350 <core::ptr::drop_glue::<hyperreal::real::arithmetic::Real>>
   4c11c:	jmp    4c17e <hyperreal_representation_probe::main+0xa1e>
   4c11e:	jmp    4c133 <hyperreal_representation_probe::main+0x9d3>
   4c120:	jmp    4c14d <hyperreal_representation_probe::main+0x9ed>
   4c122:	jmp    4c14d <hyperreal_representation_probe::main+0x9ed>
   4c124:	mov    %rax,%rbx
   4c127:	lea    0x10(%rsp),%rdi
   4c12c:	call   4b350 <core::ptr::drop_glue::<hyperreal::real::arithmetic::Real>>
   4c131:	jmp    4c150 <hyperreal_representation_probe::main+0x9f0>
   4c133:	mov    %rax,%rbx
   4c136:	lea    0x58(%rsp),%rdi
   4c13b:	call   4b2b0 <core::ptr::drop_glue::<core::iter::adapters::skip::Skip<std::env::Args>>>
   4c140:	mov    %rbx,%rdi
   4c143:	call   14c070 <_Unwind_Resume@plt>
   4c148:	mov    %rax,%rbx
   4c14b:	jmp    4c17e <hyperreal_representation_probe::main+0xa1e>
   4c14d:	mov    %rax,%rbx
   4c150:	lea    0xd0(%rsp),%rdi
   4c158:	call   4b350 <core::ptr::drop_glue::<hyperreal::real::arithmetic::Real>>
   4c15d:	jmp    4c17e <hyperreal_representation_probe::main+0xa1e>
   4c15f:	call   *0x10598b(%rip)        # 151af0 <_DYNAMIC+0x2a8>
   4c165:	mov    %rax,%rbx
   4c168:	test   %r15,%r15
   4c16b:	je     4c17e <hyperreal_representation_probe::main+0xa1e>
   4c16d:	mov    %r15,%rsi
   4c170:	mov    $0x1,%edx
   4c175:	mov    %r14,%rdi
   4c178:	call   *0x10598a(%rip)        # 151b08 <_DYNAMIC+0x2c0>
   4c17e:	mov    0xb0(%rsp),%rsi
   4c186:	test   %rsi,%rsi
   4c189:	je     4c19e <hyperreal_representation_probe::main+0xa3e>
   4c18b:	mov    0xb8(%rsp),%rdi
   4c193:	mov    $0x1,%edx
   4c198:	call   *0x10596a(%rip)        # 151b08 <_DYNAMIC+0x2c0>
   4c19e:	lea    0x58(%rsp),%rdi
   4c1a3:	call   4b2b0 <core::ptr::drop_glue::<core::iter::adapters::skip::Skip<std::env::Args>>>
   4c1a8:	mov    %rbx,%rdi
   4c1ab:	call   14c070 <_Unwind_Resume@plt>
