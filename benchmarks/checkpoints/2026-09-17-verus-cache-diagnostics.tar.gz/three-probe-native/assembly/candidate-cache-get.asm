
candidate/representation-probe/probe:     file format elf64-x86-64


Disassembly of section .text:

0000000000075340 <<hyperreal::real::arithmetic::AtomicPrimitiveApproxCache>::get>:
   75340:	48 8b 07             	mov    (%rdi),%rax
   75343:	48 b9 03 00 00 00 00 	movabs $0x7ff8000000000003,%rcx
   7534a:	00 f8 7f 
   7534d:	48 39 c8             	cmp    %rcx,%rax
   75350:	74 17                	je     75369 <<hyperreal::real::arithmetic::AtomicPrimitiveApproxCache>::get+0x29>
   75352:	48 b9 01 00 00 00 00 	movabs $0x7ff8000000000001,%rcx
   75359:	00 f8 7f 
   7535c:	48 39 c8             	cmp    %rcx,%rax
   7535f:	75 0b                	jne    7536c <<hyperreal::real::arithmetic::AtomicPrimitiveApproxCache>::get+0x2c>
   75361:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   75368:	c3                   	ret
   75369:	31 c0                	xor    %eax,%eax
   7536b:	c3                   	ret
   7536c:	66 48 0f 6e c0       	movq   %rax,%xmm0
   75371:	b8 01 00 00 00       	mov    $0x1,%eax
   75376:	c3                   	ret
