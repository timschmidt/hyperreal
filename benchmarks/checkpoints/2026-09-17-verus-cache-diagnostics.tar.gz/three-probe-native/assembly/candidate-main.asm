
candidate/representation-probe/probe:     file format elf64-x86-64


Disassembly of section .text:

000000000004c7f0 <hyperreal_representation_probe::main>:
   4c7f0:	push   %rbp
   4c7f1:	push   %r15
   4c7f3:	push   %r14
   4c7f5:	push   %r13
   4c7f7:	push   %r12
   4c7f9:	push   %rbx
   4c7fa:	sub    $0x128,%rsp
   4c801:	lea    0x58(%rsp),%rbx
   4c806:	mov    %rbx,%rdi
   4c809:	call   *0x1067a1(%rip)        # 152fb0 <_DYNAMIC+0x3c8>
   4c80f:	movq   $0x0,0x78(%rsp)
   4c818:	lea    0x10(%rsp),%rdi
   4c81d:	mov    %rbx,%rsi
   4c820:	call   *0x106782(%rip)        # 152fa8 <_DYNAMIC+0x3c0>
   4c826:	mov    0x10(%rsp),%rsi
   4c82b:	test   %rsi,%rsi
   4c82e:	je     4c84a <hyperreal_representation_probe::main+0x5a>
   4c830:	cmp    $0xffffffffffffffff,%rsi
   4c834:	je     4d015 <hyperreal_representation_probe::main+0x825>
   4c83a:	mov    0x18(%rsp),%rdi
   4c83f:	mov    $0x1,%edx
   4c844:	call   *0x10665e(%rip)        # 152ea8 <_DYNAMIC+0x2c0>
   4c84a:	lea    0x10(%rsp),%rdi
   4c84f:	lea    0x58(%rsp),%rsi
   4c854:	call   *0x10674e(%rip)        # 152fa8 <_DYNAMIC+0x3c0>
   4c85a:	cmpq   $0xffffffffffffffff,0x10(%rsp)
   4c860:	je     4d015 <hyperreal_representation_probe::main+0x825>
   4c866:	mov    0x20(%rsp),%rax
   4c86b:	mov    %rax,0xc0(%rsp)
   4c873:	movdqu 0x10(%rsp),%xmm0
   4c879:	movdqa %xmm0,0xb0(%rsp)
   4c882:	mov    0x78(%rsp),%rsi
   4c887:	test   %rsi,%rsi
   4c88a:	jne    4d033 <hyperreal_representation_probe::main+0x843>
   4c890:	lea    0x10(%rsp),%rdi
   4c895:	lea    0x58(%rsp),%rsi
   4c89a:	call   *0x106708(%rip)        # 152fa8 <_DYNAMIC+0x3c0>
   4c8a0:	mov    0x10(%rsp),%rsi
   4c8a5:	cmp    $0xffffffffffffffff,%rsi
   4c8a9:	je     4d04f <hyperreal_representation_probe::main+0x85f>
   4c8af:	mov    0x18(%rsp),%rdi
   4c8b4:	mov    0x20(%rsp),%rcx
   4c8b9:	cmp    $0x1,%rcx
   4c8bd:	je     4c8cd <hyperreal_representation_probe::main+0xdd>
   4c8bf:	test   %rcx,%rcx
   4c8c2:	je     4d198 <hyperreal_representation_probe::main+0x9a8>
   4c8c8:	movzbl (%rdi),%edx
   4c8cb:	jmp    4c8e4 <hyperreal_representation_probe::main+0xf4>
   4c8cd:	movzbl (%rdi),%edx
   4c8d0:	mov    $0x1,%al
   4c8d2:	cmp    $0x2b,%edx
   4c8d5:	je     4cfe1 <hyperreal_representation_probe::main+0x7f1>
   4c8db:	cmp    $0x2d,%edx
   4c8de:	je     4cfe1 <hyperreal_representation_probe::main+0x7f1>
   4c8e4:	xor    %r8d,%r8d
   4c8e7:	cmp    $0x2b,%dl
   4c8ea:	sete   %r8b
   4c8ee:	mov    %r8,%rax
   4c8f1:	neg    %rax
   4c8f4:	mov    %rcx,%rdx
   4c8f7:	sub    %r8,%rdx
   4c8fa:	add    %rdi,%r8
   4c8fd:	cmp    $0x11,%rdx
   4c901:	jae    4c948 <hyperreal_representation_probe::main+0x158>
   4c903:	test   %rdx,%rdx
   4c906:	je     4c999 <hyperreal_representation_probe::main+0x1a9>
   4c90c:	add    %rax,%rcx
   4c90f:	neg    %rcx
   4c912:	xor    %ebx,%ebx
   4c914:	xor    %eax,%eax
   4c916:	cs nopw 0x0(%rax,%rax,1)
   4c920:	movzbl (%r8,%rax,1),%edx
   4c925:	add    $0xffffffd0,%edx
   4c928:	cmp    $0x9,%edx
   4c92b:	ja     4d161 <hyperreal_representation_probe::main+0x971>
   4c931:	lea    (%rbx,%rbx,4),%r9
   4c935:	mov    %edx,%edx
   4c937:	lea    (%rdx,%r9,2),%rbx
   4c93b:	inc    %rax
   4c93e:	mov    %rcx,%rdx
   4c941:	add    %rax,%rdx
   4c944:	jne    4c920 <hyperreal_representation_probe::main+0x130>
   4c946:	jmp    4c99b <hyperreal_representation_probe::main+0x1ab>
   4c948:	add    %rax,%rcx
   4c94b:	neg    %rcx
   4c94e:	xor    %ebx,%ebx
   4c950:	mov    $0xa,%r9d
   4c956:	xor    %r10d,%r10d
   4c959:	nopl   0x0(%rax)
   4c960:	mov    %rcx,%rax
   4c963:	add    %r10,%rax
   4c966:	je     4c99b <hyperreal_representation_probe::main+0x1ab>
   4c968:	mov    %rbx,%rax
   4c96b:	mul    %r9
   4c96e:	movzbl (%r8,%r10,1),%edx
   4c973:	jo     4cfd7 <hyperreal_representation_probe::main+0x7e7>
   4c979:	add    $0xffffffd0,%edx
   4c97c:	cmp    $0xa,%edx
   4c97f:	jae    4d161 <hyperreal_representation_probe::main+0x971>
   4c985:	mov    %rax,%rbx
   4c988:	mov    %edx,%eax
   4c98a:	inc    %r10
   4c98d:	add    %rax,%rbx
   4c990:	jae    4c960 <hyperreal_representation_probe::main+0x170>
   4c992:	mov    $0x2,%al
   4c994:	jmp    4cfe1 <hyperreal_representation_probe::main+0x7f1>
   4c999:	xor    %ebx,%ebx
   4c99b:	mov    %rbx,0x110(%rsp)
   4c9a3:	test   %rsi,%rsi
   4c9a6:	je     4c9b3 <hyperreal_representation_probe::main+0x1c3>
   4c9a8:	mov    $0x1,%edx
   4c9ad:	call   *0x1064f5(%rip)        # 152ea8 <_DYNAMIC+0x2c0>
   4c9b3:	mov    0x78(%rsp),%rsi
   4c9b8:	test   %rsi,%rsi
   4c9bb:	jne    4d06d <hyperreal_representation_probe::main+0x87d>
   4c9c1:	lea    0x10(%rsp),%rdi
   4c9c6:	lea    0x58(%rsp),%rsi
   4c9cb:	call   *0x1065d7(%rip)        # 152fa8 <_DYNAMIC+0x3c0>
   4c9d1:	mov    0x10(%rsp),%rsi
   4c9d6:	cmp    $0xffffffffffffffff,%rsi
   4c9da:	jne    4d168 <hyperreal_representation_probe::main+0x978>
   4c9e0:	mov    0xb8(%rsp),%r12
   4c9e8:	mov    0xc0(%rsp),%r13
   4c9f0:	cmp    $0x8,%r13
   4c9f4:	je     4ca4e <hyperreal_representation_probe::main+0x25e>
   4c9f6:	cmp    $0xc,%r13
   4c9fa:	jne    4ca75 <hyperreal_representation_probe::main+0x285>
   4c9fc:	movabs $0x635f776f705f6970,%rax
   4ca06:	xor    (%r12),%rax
   4ca0a:	mov    0x8(%r12),%ecx
   4ca0f:	xor    $0x656e6f6c,%rcx
   4ca16:	or     %rax,%rcx
   4ca19:	jne    4d0fd <hyperreal_representation_probe::main+0x90d>
   4ca1f:	lea    0x10(%rsp),%rdi
   4ca24:	call   *0x10658e(%rip)        # 152fb8 <_DYNAMIC+0x3d0>
   4ca2a:	lea    0xd0(%rsp),%rdi
   4ca32:	lea    0x10(%rsp),%rdx
   4ca37:	mov    %rdx,%rsi
   4ca3a:	call   49c70 <<&hyperreal::real::arithmetic::Real as core::ops::arith::Mul>::mul>
   4ca3f:	lea    0x10(%rsp),%rdi
   4ca44:	call   4c3e0 <core::ptr::drop_glue::<hyperreal::real::arithmetic::Real>>
   4ca49:	jmp    4cb44 <hyperreal_representation_probe::main+0x354>
   4ca4e:	movabs $0x656e6f6c635f6970,%rax
   4ca58:	cmp    %rax,(%r12)
   4ca5c:	jne    4d0fd <hyperreal_representation_probe::main+0x90d>
   4ca62:	lea    0xd0(%rsp),%rdi
   4ca6a:	call   *0x106548(%rip)        # 152fb8 <_DYNAMIC+0x3d0>
   4ca70:	jmp    4cb44 <hyperreal_representation_probe::main+0x354>
   4ca75:	cmp    $0xd,%r13
   4ca79:	jne    4d0fd <hyperreal_representation_probe::main+0x90d>
   4ca7f:	movabs $0x635f69705f6e6174,%rax
   4ca89:	xor    (%r12),%rax
   4ca8d:	movabs $0x6465686361635f69,%rcx
   4ca97:	xor    0x5(%r12),%rcx
   4ca9c:	or     %rax,%rcx
   4ca9f:	jne    4d0fd <hyperreal_representation_probe::main+0x90d>
   4caa5:	lea    0x10(%rsp),%rdi
   4caaa:	mov    $0x1,%esi
   4caaf:	mov    $0x5,%edx
   4cab4:	call   *0x106506(%rip)        # 152fc0 <_DYNAMIC+0x3d8>
   4caba:	cmpb   $0x1,0x10(%rsp)
   4cabf:	je     4d118 <hyperreal_representation_probe::main+0x928>
   4cac5:	mov    0x18(%rsp),%rax
   4caca:	mov    %rax,0x20(%rsp)
   4cacf:	movb   $0x0,0x10(%rsp)
   4cad4:	movq   $0x0,0x28(%rsp)
   4cadd:	movabs $0x7ff8000000000001,%rax
   4cae7:	mov    %rax,0x38(%rsp)
   4caec:	lea    0x80(%rsp),%rdi
   4caf4:	lea    0x10(%rsp),%r14
   4caf9:	mov    %r14,%rsi
   4cafc:	call   *0x1064c6(%rip)        # 152fc8 <_DYNAMIC+0x3e0>
   4cb02:	cmpb   $0xff,0x80(%rsp)
   4cb0a:	je     4d12e <hyperreal_representation_probe::main+0x93e>
   4cb10:	movdqu 0x80(%rsp),%xmm0
   4cb19:	movupd 0x90(%rsp),%xmm1
   4cb22:	movups 0xa0(%rsp),%xmm2
   4cb2a:	movaps %xmm2,0xf0(%rsp)
   4cb32:	movapd %xmm1,0xe0(%rsp)
   4cb3b:	movdqa %xmm0,0xd0(%rsp)
   4cb44:	lea    0xf8(%rsp),%r14
   4cb4c:	mov    %r14,%rdi
   4cb4f:	call   *0x106443(%rip)        # 152f98 <_DYNAMIC+0x3b0>
   4cb55:	movq   %xmm0,0x50(%rsp)
   4cb5b:	mov    %rax,%r15
   4cb5e:	cmp    $0xffffffffffffffff,%rax
   4cb62:	jne    4cb9f <hyperreal_representation_probe::main+0x3af>
   4cb64:	lea    0xd0(%rsp),%rdi
   4cb6c:	call   *0x10645e(%rip)        # 152fd0 <_DYNAMIC+0x3e8>
   4cb72:	movq   %xmm0,0x50(%rsp)
   4cb78:	mov    %rax,%r15
   4cb7b:	lea    0xd0(%rsp),%rdi
   4cb83:	call   *0x10644f(%rip)        # 152fd8 <_DYNAMIC+0x3f0>
   4cb89:	test   %al,%al
   4cb8b:	jne    4cb9f <hyperreal_representation_probe::main+0x3af>
   4cb8d:	mov    %r14,%rdi
   4cb90:	mov    %r15,%rsi
   4cb93:	movq   0x50(%rsp),%xmm0
   4cb99:	call   *0x1063e1(%rip)        # 152f80 <_DYNAMIC+0x398>
   4cb9f:	cmp    $0x1,%r15
   4cba3:	jne    4d08e <hyperreal_representation_probe::main+0x89e>
   4cba9:	movq   0x50(%rsp),%xmm0
   4cbaf:	movq   %xmm0,%rax
   4cbb4:	movabs $0x7fffffffffffffff,%rcx
   4cbbe:	and    %rax,%rcx
   4cbc1:	movabs $0x7fefffffffffffff,%rax
   4cbcb:	cmp    %rax,%rcx
   4cbce:	jg     4d0a0 <hyperreal_representation_probe::main+0x8b0>
   4cbd4:	call   *0x106406(%rip)        # 152fe0 <_DYNAMIC+0x3f8>
   4cbda:	mov    %rax,0x118(%rsp)
   4cbe2:	mov    %edx,0x120(%rsp)
   4cbe9:	cmp    $0xd,%r13
   4cbed:	jne    4cc15 <hyperreal_representation_probe::main+0x425>
   4cbef:	movabs $0x635f69705f6e6174,%rax
   4cbf9:	xor    (%r12),%rax
   4cbfd:	movabs $0x6465686361635f69,%rcx
   4cc07:	xor    0x5(%r12),%rcx
   4cc0c:	or     %rax,%rcx
   4cc0f:	je     4cf43 <hyperreal_representation_probe::main+0x753>
   4cc15:	test   %rbx,%rbx
   4cc18:	je     4cc7a <hyperreal_representation_probe::main+0x48a>
   4cc1a:	lea    0xd0(%rsp),%r14
   4cc22:	lea    0x10(%rsp),%r15
   4cc27:	lea    0x80(%rsp),%r12
   4cc2f:	nop
   4cc30:	mov    %r14,0x10(%rsp)
   4cc35:	mov    0x10(%rsp),%rsi
   4cc3a:	mov    %r15,%rdi
   4cc3d:	call   4eb20 <<hyperreal::real::arithmetic::Real as core::clone::Clone>::clone>
   4cc42:	movdqu 0x10(%rsp),%xmm0
   4cc48:	movupd 0x20(%rsp),%xmm1
   4cc4e:	movups 0x30(%rsp),%xmm2
   4cc53:	movaps %xmm2,0xa0(%rsp)
   4cc5b:	movapd %xmm1,0x90(%rsp)
   4cc64:	movdqa %xmm0,0x80(%rsp)
   4cc6d:	mov    %r12,%rdi
   4cc70:	call   4c3e0 <core::ptr::drop_glue::<hyperreal::real::arithmetic::Real>>
   4cc75:	dec    %rbx
   4cc78:	jne    4cc30 <hyperreal_representation_probe::main+0x440>
   4cc7a:	lea    0x118(%rsp),%rdi
   4cc82:	call   *0x106360(%rip)        # 152fe8 <_DYNAMIC+0x400>
   4cc88:	lea    0xf8(%rsp),%r14
   4cc90:	mov    %rax,%r15
   4cc93:	mov    %edx,%ebx
   4cc95:	mov    %r14,%rdi
   4cc98:	call   *0x1062fa(%rip)        # 152f98 <_DYNAMIC+0x3b0>
   4cc9e:	movq   %xmm0,0x8(%rsp)
   4cca4:	mov    %rax,%r12
   4cca7:	cmp    $0xffffffffffffffff,%rax
   4ccab:	jne    4cce8 <hyperreal_representation_probe::main+0x4f8>
   4ccad:	lea    0xd0(%rsp),%rdi
   4ccb5:	call   *0x106315(%rip)        # 152fd0 <_DYNAMIC+0x3e8>
   4ccbb:	movq   %xmm0,0x8(%rsp)
   4ccc1:	mov    %rax,%r12
   4ccc4:	lea    0xd0(%rsp),%rdi
   4cccc:	call   *0x106306(%rip)        # 152fd8 <_DYNAMIC+0x3f0>
   4ccd2:	test   %al,%al
   4ccd4:	jne    4cce8 <hyperreal_representation_probe::main+0x4f8>
   4ccd6:	mov    %r14,%rdi
   4ccd9:	mov    %r12,%rsi
   4ccdc:	movq   0x8(%rsp),%xmm0
   4cce2:	call   *0x106298(%rip)        # 152f80 <_DYNAMIC+0x398>
   4cce8:	mov    %r12,0x80(%rsp)
   4ccf0:	movsd  0x8(%rsp),%xmm1
   4ccf6:	movsd  %xmm1,0x88(%rsp)
   4ccff:	movq   $0x1,0x10(%rsp)
   4cd08:	movsd  0x50(%rsp),%xmm0
   4cd0e:	movsd  %xmm0,0x18(%rsp)
   4cd14:	cmp    $0x1,%r12
   4cd18:	jne    4d0be <hyperreal_representation_probe::main+0x8ce>
   4cd1e:	ucomisd %xmm0,%xmm1
   4cd22:	jne    4d0be <hyperreal_representation_probe::main+0x8ce>
   4cd28:	jp     4d0be <hyperreal_representation_probe::main+0x8ce>
   4cd2e:	lea    0x10(%rsp),%rdi
   4cd33:	lea    0xd0(%rsp),%rsi
   4cd3b:	call   4eb20 <<hyperreal::real::arithmetic::Real as core::clone::Clone>::clone>
   4cd40:	lea    0x38(%rsp),%r12
   4cd45:	mov    %r12,%rdi
   4cd48:	call   *0x10624a(%rip)        # 152f98 <_DYNAMIC+0x3b0>
   4cd4e:	movsd  %xmm0,0x8(%rsp)
   4cd54:	mov    %rax,%r14
   4cd57:	cmp    $0xffffffffffffffff,%rax
   4cd5b:	jne    4cd92 <hyperreal_representation_probe::main+0x5a2>
   4cd5d:	lea    0x10(%rsp),%rdi
   4cd62:	call   *0x106268(%rip)        # 152fd0 <_DYNAMIC+0x3e8>
   4cd68:	movsd  %xmm0,0x8(%rsp)
   4cd6e:	mov    %rax,%r14
   4cd71:	lea    0x10(%rsp),%rdi
   4cd76:	call   *0x10625c(%rip)        # 152fd8 <_DYNAMIC+0x3f0>
   4cd7c:	test   %al,%al
   4cd7e:	jne    4cd92 <hyperreal_representation_probe::main+0x5a2>
   4cd80:	mov    %r12,%rdi
   4cd83:	mov    %r14,%rsi
   4cd86:	movsd  0x8(%rsp),%xmm0
   4cd8c:	call   *0x1061ee(%rip)        # 152f80 <_DYNAMIC+0x398>
   4cd92:	mov    %r14,0x100(%rsp)
   4cd9a:	movsd  0x8(%rsp),%xmm1
   4cda0:	movsd  %xmm1,0x108(%rsp)
   4cda9:	movq   $0x1,0x80(%rsp)
   4cdb5:	movsd  0x50(%rsp),%xmm0
   4cdbb:	movsd  %xmm0,0x88(%rsp)
   4cdc4:	cmp    $0x1,%r14
   4cdc8:	jne    4d0dc <hyperreal_representation_probe::main+0x8ec>
   4cdce:	ucomisd %xmm0,%xmm1
   4cdd2:	jne    4d0dc <hyperreal_representation_probe::main+0x8ec>
   4cdd8:	jp     4d0dc <hyperreal_representation_probe::main+0x8ec>
   4cdde:	lea    0x10(%rsp),%rdi
   4cde3:	call   4c3e0 <core::ptr::drop_glue::<hyperreal::real::arithmetic::Real>>
   4cde8:	mov    $0x3b9aca00,%ecx
   4cded:	mov    %r15,%rax
   4cdf0:	mul    %rcx
   4cdf3:	mov    %ebx,%ecx
   4cdf5:	add    %rax,%rcx
   4cdf8:	adc    $0x0,%rdx
   4cdfc:	mov    %rcx,0x80(%rsp)
   4ce04:	mov    %rdx,0x88(%rsp)
   4ce0c:	movq   0x50(%rsp),%xmm0
   4ce12:	movq   %xmm0,0x100(%rsp)
   4ce1b:	lea    0xb0(%rsp),%rax
   4ce23:	mov    %rax,0x10(%rsp)
   4ce28:	lea    0x2251(%rip),%rax        # 4f080 <<alloc::string::String as core::fmt::Display>::fmt>
   4ce2f:	mov    %rax,0x18(%rsp)
   4ce34:	lea    0x110(%rsp),%rax
   4ce3c:	mov    %rax,0x20(%rsp)
   4ce41:	mov    0x1061a8(%rip),%rax        # 152ff0 <_DYNAMIC+0x408>
   4ce48:	mov    %rax,0x28(%rsp)
   4ce4d:	lea    0x80(%rsp),%rcx
   4ce55:	mov    %rcx,0x30(%rsp)
   4ce5a:	mov    0x106197(%rip),%rcx        # 152ff8 <_DYNAMIC+0x410>
   4ce61:	mov    %rcx,0x38(%rsp)
   4ce66:	lea    0x100(%rsp),%rcx
   4ce6e:	mov    %rcx,0x40(%rsp)
   4ce73:	mov    %rax,0x48(%rsp)
   4ce78:	lea    -0x2a865(%rip),%rdi        # 2261a <anon.f528f8cddd6ae9d3ee873f0d5154aaae.22.llvm.10676021354292260747+0x110>
   4ce7f:	lea    0x10(%rsp),%rsi
   4ce84:	call   *0x106176(%rip)        # 153000 <_DYNAMIC+0x418>
   4ce8a:	lea    0xd0(%rsp),%rdi
   4ce92:	call   4c3e0 <core::ptr::drop_glue::<hyperreal::real::arithmetic::Real>>
   4ce97:	mov    0xb0(%rsp),%rsi
   4ce9f:	test   %rsi,%rsi
   4cea2:	je     4ceb7 <hyperreal_representation_probe::main+0x6c7>
   4cea4:	mov    0xb8(%rsp),%rdi
   4ceac:	mov    $0x1,%edx
   4ceb1:	call   *0x105ff1(%rip)        # 152ea8 <_DYNAMIC+0x2c0>
   4ceb7:	mov    0x60(%rsp),%r14
   4cebc:	mov    0x70(%rsp),%rcx
   4cec1:	mov    %rcx,%rax
   4cec4:	sub    %r14,%rax
   4cec7:	movabs $0xaaaaaaaaaaaaaaab,%rdx
   4ced1:	mul    %rdx
   4ced4:	cmp    %r14,%rcx
   4ced7:	je     4cf0f <hyperreal_representation_probe::main+0x71f>
   4ced9:	mov    %rdx,%rbx
   4cedc:	shr    $0x4,%rbx
   4cee0:	add    $0x8,%r14
   4cee4:	mov    0x105fbd(%rip),%r15        # 152ea8 <_DYNAMIC+0x2c0>
   4ceeb:	jmp    4cef9 <hyperreal_representation_probe::main+0x709>
   4ceed:	nopl   (%rax)
   4cef0:	add    $0x18,%r14
   4cef4:	dec    %rbx
   4cef7:	je     4cf0f <hyperreal_representation_probe::main+0x71f>
   4cef9:	mov    -0x8(%r14),%rsi
   4cefd:	test   %rsi,%rsi
   4cf00:	je     4cef0 <hyperreal_representation_probe::main+0x700>
   4cf02:	mov    (%r14),%rdi
   4cf05:	mov    $0x1,%edx
   4cf0a:	call   *%r15
   4cf0d:	jmp    4cef0 <hyperreal_representation_probe::main+0x700>
   4cf0f:	mov    0x68(%rsp),%rax
   4cf14:	test   %rax,%rax
   4cf17:	je     4cf31 <hyperreal_representation_probe::main+0x741>
   4cf19:	mov    0x58(%rsp),%rdi
   4cf1e:	shl    $0x3,%rax
   4cf22:	lea    (%rax,%rax,2),%rsi
   4cf26:	mov    $0x8,%edx
   4cf2b:	call   *0x105f77(%rip)        # 152ea8 <_DYNAMIC+0x2c0>
   4cf31:	add    $0x128,%rsp
   4cf38:	pop    %rbx
   4cf39:	pop    %r12
   4cf3b:	pop    %r13
   4cf3d:	pop    %r14
   4cf3f:	pop    %r15
   4cf41:	pop    %rbp
   4cf42:	ret
   4cf43:	test   %rbx,%rbx
   4cf46:	je     4cc7a <hyperreal_representation_probe::main+0x48a>
   4cf4c:	lea    0x10(%rsp),%r14
   4cf51:	mov    0x106040(%rip),%rbp        # 152f98 <_DYNAMIC+0x3b0>
   4cf58:	jmp    4cf7a <hyperreal_representation_probe::main+0x78a>
   4cf5a:	nopw   0x0(%rax,%rax,1)
   4cf60:	mov    %r15,0x10(%rsp)
   4cf65:	movq   0x8(%rsp),%xmm0
   4cf6b:	movq   %xmm0,0x18(%rsp)
   4cf71:	dec    %rbx
   4cf74:	je     4cc7a <hyperreal_representation_probe::main+0x48a>
   4cf7a:	lea    0xd0(%rsp),%rax
   4cf82:	mov    %rax,0x10(%rsp)
   4cf87:	mov    0x10(%rsp),%r13
   4cf8c:	lea    0x28(%r13),%r12
   4cf90:	mov    %r12,%rdi
   4cf93:	call   *%rbp
   4cf95:	movq   %xmm0,0x8(%rsp)
   4cf9b:	mov    %rax,%r15
   4cf9e:	cmp    $0xffffffffffffffff,%rax
   4cfa2:	jne    4cf60 <hyperreal_representation_probe::main+0x770>
   4cfa4:	mov    %r13,%rdi
   4cfa7:	call   *0x106023(%rip)        # 152fd0 <_DYNAMIC+0x3e8>
   4cfad:	movq   %xmm0,0x8(%rsp)
   4cfb3:	mov    %rax,%r15
   4cfb6:	mov    %r13,%rdi
   4cfb9:	call   *0x106019(%rip)        # 152fd8 <_DYNAMIC+0x3f0>
   4cfbf:	test   %al,%al
   4cfc1:	jne    4cf60 <hyperreal_representation_probe::main+0x770>
   4cfc3:	mov    %r12,%rdi
   4cfc6:	mov    %r15,%rsi
   4cfc9:	movq   0x8(%rsp),%xmm0
   4cfcf:	call   *0x105fab(%rip)        # 152f80 <_DYNAMIC+0x398>
   4cfd5:	jmp    4cf60 <hyperreal_representation_probe::main+0x770>
   4cfd7:	add    $0xd0,%dl
   4cfda:	xor    %eax,%eax
   4cfdc:	cmp    $0xa,%dl
   4cfdf:	adc    $0x1,%al
   4cfe1:	mov    %rdi,%r14
   4cfe4:	mov    %rsi,%r15
   4cfe7:	mov    %al,0x10(%rsp)
   4cfeb:	lea    -0x28900(%rip),%rdi        # 246f2 <anon.989e3a3df5a9b0c8132da4bb77c7c33a.35.llvm.7186563581096173296+0x372>
   4cff2:	lea    0x10188f(%rip),%rcx        # 14e888 <__dso_handle+0x288>
   4cff9:	lea    0x101790(%rip),%r8        # 14e790 <__dso_handle+0x190>
   4d000:	lea    0x10(%rsp),%rdx
   4d005:	mov    $0x2b,%esi
   4d00a:	call   *0x105ff8(%rip)        # 153008 <_DYNAMIC+0x420>
   4d010:	jmp    4d196 <hyperreal_representation_probe::main+0x9a6>
   4d015:	lea    -0x28b1c(%rip),%rdi        # 24500 <anon.989e3a3df5a9b0c8132da4bb77c7c33a.35.llvm.7186563581096173296+0x180>
   4d01c:	lea    0x10173d(%rip),%rdx        # 14e760 <__dso_handle+0x160>
   4d023:	mov    $0x4,%esi
   4d028:	call   *0x105fe2(%rip)        # 153010 <_DYNAMIC+0x428>
   4d02e:	jmp    4d196 <hyperreal_representation_probe::main+0x9a6>
   4d033:	movq   $0x0,0x78(%rsp)
   4d03c:	lea    0x58(%rsp),%rdi
   4d041:	call   4c6c0 <<std::env::Args as core::iter::traits::iterator::Iterator>::try_fold::<core::num::nonzero::NonZero<usize>, <std::env::Args as core::iter::traits::iterator::Iterator::advance_by::SpecAdvanceBy>::spec_advance_by::{closure#0}, core::option::Option<core::num::nonzero::NonZero<usize>>>>
   4d046:	test   %rax,%rax
   4d049:	je     4c890 <hyperreal_representation_probe::main+0xa0>
   4d04f:	lea    -0x28b06(%rip),%rdi        # 24550 <anon.989e3a3df5a9b0c8132da4bb77c7c33a.35.llvm.7186563581096173296+0x1d0>
   4d056:	lea    0x10171b(%rip),%rdx        # 14e778 <__dso_handle+0x178>
   4d05d:	mov    $0xa,%esi
   4d062:	call   *0x105fa8(%rip)        # 153010 <_DYNAMIC+0x428>
   4d068:	jmp    4d196 <hyperreal_representation_probe::main+0x9a6>
   4d06d:	movq   $0x0,0x78(%rsp)
   4d076:	lea    0x58(%rsp),%rdi
   4d07b:	call   4c6c0 <<std::env::Args as core::iter::traits::iterator::Iterator>::try_fold::<core::num::nonzero::NonZero<usize>, <std::env::Args as core::iter::traits::iterator::Iterator::advance_by::SpecAdvanceBy>::spec_advance_by::{closure#0}, core::option::Option<core::num::nonzero::NonZero<usize>>>>
   4d080:	test   %rax,%rax
   4d083:	jne    4c9e0 <hyperreal_representation_probe::main+0x1f0>
   4d089:	jmp    4c9c1 <hyperreal_representation_probe::main+0x1d1>
   4d08e:	lea    0x101773(%rip),%rdi        # 14e808 <__dso_handle+0x208>
   4d095:	call   *0x105e1d(%rip)        # 152eb8 <_DYNAMIC+0x2d0>
   4d09b:	jmp    4d196 <hyperreal_representation_probe::main+0x9a6>
   4d0a0:	lea    -0x289db(%rip),%rdi        # 246cc <anon.989e3a3df5a9b0c8132da4bb77c7c33a.35.llvm.7186563581096173296+0x34c>
   4d0a7:	lea    0x101772(%rip),%rdx        # 14e820 <__dso_handle+0x220>
   4d0ae:	mov    $0x26,%esi
   4d0b3:	call   *0x105ecf(%rip)        # 152f88 <_DYNAMIC+0x3a0>
   4d0b9:	jmp    4d196 <hyperreal_representation_probe::main+0x9a6>
   4d0be:	lea    0x101773(%rip),%rdx        # 14e838 <__dso_handle+0x238>
   4d0c5:	lea    0x80(%rsp),%rdi
   4d0cd:	lea    0x10(%rsp),%rsi
   4d0d2:	call   4c671 <core::panicking::assert_failed::<core::option::Option<f64>, core::option::Option<f64>>>
   4d0d7:	jmp    4d196 <hyperreal_representation_probe::main+0x9a6>
   4d0dc:	lea    0x10176d(%rip),%rdx        # 14e850 <__dso_handle+0x250>
   4d0e3:	lea    0x100(%rsp),%rdi
   4d0eb:	lea    0x80(%rsp),%rsi
   4d0f3:	call   4c671 <core::panicking::assert_failed::<core::option::Option<f64>, core::option::Option<f64>>>
   4d0f8:	jmp    4d196 <hyperreal_representation_probe::main+0x9a6>
   4d0fd:	lea    -0x28a44(%rip),%rdi        # 246c0 <anon.989e3a3df5a9b0c8132da4bb77c7c33a.35.llvm.7186563581096173296+0x340>
   4d104:	lea    0x1016b5(%rip),%rdx        # 14e7c0 <__dso_handle+0x1c0>
   4d10b:	mov    $0x19,%esi
   4d110:	call   *0x105d9a(%rip)        # 152eb0 <_DYNAMIC+0x2c8>
   4d116:	jmp    4d196 <hyperreal_representation_probe::main+0x9a6>
   4d118:	lea    0x11(%rsp),%rax
   4d11d:	lea    0x1016b4(%rip),%r8        # 14e7d8 <__dso_handle+0x1d8>
   4d124:	lea    0xd0(%rsp),%r14
   4d12c:	jmp    4d13d <hyperreal_representation_probe::main+0x94d>
   4d12e:	lea    0x81(%rsp),%rax
   4d136:	lea    0x1016b3(%rip),%r8        # 14e7f0 <__dso_handle+0x1f0>
   4d13d:	movzbl (%rax),%eax
   4d140:	mov    %al,(%r14)
   4d143:	lea    -0x28a58(%rip),%rdi        # 246f2 <anon.989e3a3df5a9b0c8132da4bb77c7c33a.35.llvm.7186563581096173296+0x372>
   4d14a:	lea    0x101717(%rip),%rcx        # 14e868 <__dso_handle+0x268>
   4d151:	mov    $0x2b,%esi
   4d156:	mov    %r14,%rdx
   4d159:	call   *0x105ea9(%rip)        # 153008 <_DYNAMIC+0x420>
   4d15f:	jmp    4d196 <hyperreal_representation_probe::main+0x9a6>
   4d161:	mov    $0x1,%al
   4d163:	jmp    4cfe1 <hyperreal_representation_probe::main+0x7f1>
   4d168:	test   %rsi,%rsi
   4d16b:	je     4d17d <hyperreal_representation_probe::main+0x98d>
   4d16d:	mov    0x18(%rsp),%rdi
   4d172:	mov    $0x1,%edx
   4d177:	call   *0x105d2b(%rip)        # 152ea8 <_DYNAMIC+0x2c0>
   4d17d:	lea    -0x28c2a(%rip),%rdi        # 2455a <anon.989e3a3df5a9b0c8132da4bb77c7c33a.35.llvm.7186563581096173296+0x1da>
   4d184:	lea    0x10161d(%rip),%rdx        # 14e7a8 <__dso_handle+0x1a8>
   4d18b:	mov    $0x2c,%esi
   4d190:	call   *0x105df2(%rip)        # 152f88 <_DYNAMIC+0x3a0>
   4d196:	ud2
   4d198:	xor    %eax,%eax
   4d19a:	jmp    4cfe1 <hyperreal_representation_probe::main+0x7f1>
   4d19f:	mov    %rax,%rbx
   4d1a2:	lea    0x10(%rsp),%rdi
   4d1a7:	call   4c3e0 <core::ptr::drop_glue::<hyperreal::real::arithmetic::Real>>
   4d1ac:	jmp    4d20e <hyperreal_representation_probe::main+0xa1e>
   4d1ae:	jmp    4d1c3 <hyperreal_representation_probe::main+0x9d3>
   4d1b0:	jmp    4d1dd <hyperreal_representation_probe::main+0x9ed>
   4d1b2:	jmp    4d1dd <hyperreal_representation_probe::main+0x9ed>
   4d1b4:	mov    %rax,%rbx
   4d1b7:	lea    0x10(%rsp),%rdi
   4d1bc:	call   4c3e0 <core::ptr::drop_glue::<hyperreal::real::arithmetic::Real>>
   4d1c1:	jmp    4d1e0 <hyperreal_representation_probe::main+0x9f0>
   4d1c3:	mov    %rax,%rbx
   4d1c6:	lea    0x58(%rsp),%rdi
   4d1cb:	call   4c340 <core::ptr::drop_glue::<core::iter::adapters::skip::Skip<std::env::Args>>>
   4d1d0:	mov    %rbx,%rdi
   4d1d3:	call   14d440 <_Unwind_Resume@plt>
   4d1d8:	mov    %rax,%rbx
   4d1db:	jmp    4d20e <hyperreal_representation_probe::main+0xa1e>
   4d1dd:	mov    %rax,%rbx
   4d1e0:	lea    0xd0(%rsp),%rdi
   4d1e8:	call   4c3e0 <core::ptr::drop_glue::<hyperreal::real::arithmetic::Real>>
   4d1ed:	jmp    4d20e <hyperreal_representation_probe::main+0xa1e>
   4d1ef:	call   *0x105c9b(%rip)        # 152e90 <_DYNAMIC+0x2a8>
   4d1f5:	mov    %rax,%rbx
   4d1f8:	test   %r15,%r15
   4d1fb:	je     4d20e <hyperreal_representation_probe::main+0xa1e>
   4d1fd:	mov    %r15,%rsi
   4d200:	mov    $0x1,%edx
   4d205:	mov    %r14,%rdi
   4d208:	call   *0x105c9a(%rip)        # 152ea8 <_DYNAMIC+0x2c0>
   4d20e:	mov    0xb0(%rsp),%rsi
   4d216:	test   %rsi,%rsi
   4d219:	je     4d22e <hyperreal_representation_probe::main+0xa3e>
   4d21b:	mov    0xb8(%rsp),%rdi
   4d223:	mov    $0x1,%edx
   4d228:	call   *0x105c7a(%rip)        # 152ea8 <_DYNAMIC+0x2c0>
   4d22e:	lea    0x58(%rsp),%rdi
   4d233:	call   4c340 <core::ptr::drop_glue::<core::iter::adapters::skip::Skip<std::env::Args>>>
   4d238:	mov    %rbx,%rdi
   4d23b:	call   14d440 <_Unwind_Resume@plt>
