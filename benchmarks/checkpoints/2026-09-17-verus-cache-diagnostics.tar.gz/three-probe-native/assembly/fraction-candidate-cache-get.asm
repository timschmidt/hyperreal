
fraction-candidate/representation-probe/probe:     file format elf64-x86-64


Disassembly of section .text:

0000000000075370 <<hyperreal::real::arithmetic::AtomicPrimitiveApproxCache>::get>:
   75370:	48 8b 07             	mov    (%rdi),%rax
   75373:	48 b9 03 00 00 00 00 	movabs $0x7ff8000000000003,%rcx
   7537a:	00 f8 7f 
   7537d:	48 39 c8             	cmp    %rcx,%rax
   75380:	74 17                	je     75399 <<hyperreal::real::arithmetic::AtomicPrimitiveApproxCache>::get+0x29>
   75382:	48 b9 01 00 00 00 00 	movabs $0x7ff8000000000001,%rcx
   75389:	00 f8 7f 
   7538c:	48 39 c8             	cmp    %rcx,%rax
   7538f:	75 0b                	jne    7539c <<hyperreal::real::arithmetic::AtomicPrimitiveApproxCache>::get+0x2c>
   75391:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   75398:	c3                   	ret
   75399:	31 c0                	xor    %eax,%eax
   7539b:	c3                   	ret
   7539c:	66 48 0f 6e c0       	movq   %rax,%xmm0
   753a1:	b8 01 00 00 00       	mov    $0x1,%eax
   753a6:	c3                   	ret
