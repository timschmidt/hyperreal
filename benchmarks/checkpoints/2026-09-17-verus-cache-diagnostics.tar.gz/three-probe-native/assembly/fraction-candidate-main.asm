
fraction-candidate/representation-probe/probe:     file format elf64-x86-64


Disassembly of section .text:

000000000004c820 <hyperreal_representation_probe::main>:
   4c820:	push   %rbp
   4c821:	push   %r15
   4c823:	push   %r14
   4c825:	push   %r13
   4c827:	push   %r12
   4c829:	push   %rbx
   4c82a:	sub    $0x128,%rsp
   4c831:	lea    0x58(%rsp),%rbx
   4c836:	mov    %rbx,%rdi
   4c839:	call   *0x1067a1(%rip)        # 152fe0 <_DYNAMIC+0x3c8>
   4c83f:	movq   $0x0,0x78(%rsp)
   4c848:	lea    0x10(%rsp),%rdi
   4c84d:	mov    %rbx,%rsi
   4c850:	call   *0x106782(%rip)        # 152fd8 <_DYNAMIC+0x3c0>
   4c856:	mov    0x10(%rsp),%rsi
   4c85b:	test   %rsi,%rsi
   4c85e:	je     4c87a <hyperreal_representation_probe::main+0x5a>
   4c860:	cmp    $0xffffffffffffffff,%rsi
   4c864:	je     4d045 <hyperreal_representation_probe::main+0x825>
   4c86a:	mov    0x18(%rsp),%rdi
   4c86f:	mov    $0x1,%edx
   4c874:	call   *0x10665e(%rip)        # 152ed8 <_DYNAMIC+0x2c0>
   4c87a:	lea    0x10(%rsp),%rdi
   4c87f:	lea    0x58(%rsp),%rsi
   4c884:	call   *0x10674e(%rip)        # 152fd8 <_DYNAMIC+0x3c0>
   4c88a:	cmpq   $0xffffffffffffffff,0x10(%rsp)
   4c890:	je     4d045 <hyperreal_representation_probe::main+0x825>
   4c896:	mov    0x20(%rsp),%rax
   4c89b:	mov    %rax,0xc0(%rsp)
   4c8a3:	movdqu 0x10(%rsp),%xmm0
   4c8a9:	movdqa %xmm0,0xb0(%rsp)
   4c8b2:	mov    0x78(%rsp),%rsi
   4c8b7:	test   %rsi,%rsi
   4c8ba:	jne    4d063 <hyperreal_representation_probe::main+0x843>
   4c8c0:	lea    0x10(%rsp),%rdi
   4c8c5:	lea    0x58(%rsp),%rsi
   4c8ca:	call   *0x106708(%rip)        # 152fd8 <_DYNAMIC+0x3c0>
   4c8d0:	mov    0x10(%rsp),%rsi
   4c8d5:	cmp    $0xffffffffffffffff,%rsi
   4c8d9:	je     4d07f <hyperreal_representation_probe::main+0x85f>
   4c8df:	mov    0x18(%rsp),%rdi
   4c8e4:	mov    0x20(%rsp),%rcx
   4c8e9:	cmp    $0x1,%rcx
   4c8ed:	je     4c8fd <hyperreal_representation_probe::main+0xdd>
   4c8ef:	test   %rcx,%rcx
   4c8f2:	je     4d1c8 <hyperreal_representation_probe::main+0x9a8>
   4c8f8:	movzbl (%rdi),%edx
   4c8fb:	jmp    4c914 <hyperreal_representation_probe::main+0xf4>
   4c8fd:	movzbl (%rdi),%edx
   4c900:	mov    $0x1,%al
   4c902:	cmp    $0x2b,%edx
   4c905:	je     4d011 <hyperreal_representation_probe::main+0x7f1>
   4c90b:	cmp    $0x2d,%edx
   4c90e:	je     4d011 <hyperreal_representation_probe::main+0x7f1>
   4c914:	xor    %r8d,%r8d
   4c917:	cmp    $0x2b,%dl
   4c91a:	sete   %r8b
   4c91e:	mov    %r8,%rax
   4c921:	neg    %rax
   4c924:	mov    %rcx,%rdx
   4c927:	sub    %r8,%rdx
   4c92a:	add    %rdi,%r8
   4c92d:	cmp    $0x11,%rdx
   4c931:	jae    4c978 <hyperreal_representation_probe::main+0x158>
   4c933:	test   %rdx,%rdx
   4c936:	je     4c9c9 <hyperreal_representation_probe::main+0x1a9>
   4c93c:	add    %rax,%rcx
   4c93f:	neg    %rcx
   4c942:	xor    %ebx,%ebx
   4c944:	xor    %eax,%eax
   4c946:	cs nopw 0x0(%rax,%rax,1)
   4c950:	movzbl (%r8,%rax,1),%edx
   4c955:	add    $0xffffffd0,%edx
   4c958:	cmp    $0x9,%edx
   4c95b:	ja     4d191 <hyperreal_representation_probe::main+0x971>
   4c961:	lea    (%rbx,%rbx,4),%r9
   4c965:	mov    %edx,%edx
   4c967:	lea    (%rdx,%r9,2),%rbx
   4c96b:	inc    %rax
   4c96e:	mov    %rcx,%rdx
   4c971:	add    %rax,%rdx
   4c974:	jne    4c950 <hyperreal_representation_probe::main+0x130>
   4c976:	jmp    4c9cb <hyperreal_representation_probe::main+0x1ab>
   4c978:	add    %rax,%rcx
   4c97b:	neg    %rcx
   4c97e:	xor    %ebx,%ebx
   4c980:	mov    $0xa,%r9d
   4c986:	xor    %r10d,%r10d
   4c989:	nopl   0x0(%rax)
   4c990:	mov    %rcx,%rax
   4c993:	add    %r10,%rax
   4c996:	je     4c9cb <hyperreal_representation_probe::main+0x1ab>
   4c998:	mov    %rbx,%rax
   4c99b:	mul    %r9
   4c99e:	movzbl (%r8,%r10,1),%edx
   4c9a3:	jo     4d007 <hyperreal_representation_probe::main+0x7e7>
   4c9a9:	add    $0xffffffd0,%edx
   4c9ac:	cmp    $0xa,%edx
   4c9af:	jae    4d191 <hyperreal_representation_probe::main+0x971>
   4c9b5:	mov    %rax,%rbx
   4c9b8:	mov    %edx,%eax
   4c9ba:	inc    %r10
   4c9bd:	add    %rax,%rbx
   4c9c0:	jae    4c990 <hyperreal_representation_probe::main+0x170>
   4c9c2:	mov    $0x2,%al
   4c9c4:	jmp    4d011 <hyperreal_representation_probe::main+0x7f1>
   4c9c9:	xor    %ebx,%ebx
   4c9cb:	mov    %rbx,0x110(%rsp)
   4c9d3:	test   %rsi,%rsi
   4c9d6:	je     4c9e3 <hyperreal_representation_probe::main+0x1c3>
   4c9d8:	mov    $0x1,%edx
   4c9dd:	call   *0x1064f5(%rip)        # 152ed8 <_DYNAMIC+0x2c0>
   4c9e3:	mov    0x78(%rsp),%rsi
   4c9e8:	test   %rsi,%rsi
   4c9eb:	jne    4d09d <hyperreal_representation_probe::main+0x87d>
   4c9f1:	lea    0x10(%rsp),%rdi
   4c9f6:	lea    0x58(%rsp),%rsi
   4c9fb:	call   *0x1065d7(%rip)        # 152fd8 <_DYNAMIC+0x3c0>
   4ca01:	mov    0x10(%rsp),%rsi
   4ca06:	cmp    $0xffffffffffffffff,%rsi
   4ca0a:	jne    4d198 <hyperreal_representation_probe::main+0x978>
   4ca10:	mov    0xb8(%rsp),%r12
   4ca18:	mov    0xc0(%rsp),%r13
   4ca20:	cmp    $0x8,%r13
   4ca24:	je     4ca7e <hyperreal_representation_probe::main+0x25e>
   4ca26:	cmp    $0xc,%r13
   4ca2a:	jne    4caa5 <hyperreal_representation_probe::main+0x285>
   4ca2c:	movabs $0x635f776f705f6970,%rax
   4ca36:	xor    (%r12),%rax
   4ca3a:	mov    0x8(%r12),%ecx
   4ca3f:	xor    $0x656e6f6c,%rcx
   4ca46:	or     %rax,%rcx
   4ca49:	jne    4d12d <hyperreal_representation_probe::main+0x90d>
   4ca4f:	lea    0x10(%rsp),%rdi
   4ca54:	call   *0x10658e(%rip)        # 152fe8 <_DYNAMIC+0x3d0>
   4ca5a:	lea    0xd0(%rsp),%rdi
   4ca62:	lea    0x10(%rsp),%rdx
   4ca67:	mov    %rdx,%rsi
   4ca6a:	call   49ca0 <<&hyperreal::real::arithmetic::Real as core::ops::arith::Mul>::mul>
   4ca6f:	lea    0x10(%rsp),%rdi
   4ca74:	call   4c410 <core::ptr::drop_glue::<hyperreal::real::arithmetic::Real>>
   4ca79:	jmp    4cb74 <hyperreal_representation_probe::main+0x354>
   4ca7e:	movabs $0x656e6f6c635f6970,%rax
   4ca88:	cmp    %rax,(%r12)
   4ca8c:	jne    4d12d <hyperreal_representation_probe::main+0x90d>
   4ca92:	lea    0xd0(%rsp),%rdi
   4ca9a:	call   *0x106548(%rip)        # 152fe8 <_DYNAMIC+0x3d0>
   4caa0:	jmp    4cb74 <hyperreal_representation_probe::main+0x354>
   4caa5:	cmp    $0xd,%r13
   4caa9:	jne    4d12d <hyperreal_representation_probe::main+0x90d>
   4caaf:	movabs $0x635f69705f6e6174,%rax
   4cab9:	xor    (%r12),%rax
   4cabd:	movabs $0x6465686361635f69,%rcx
   4cac7:	xor    0x5(%r12),%rcx
   4cacc:	or     %rax,%rcx
   4cacf:	jne    4d12d <hyperreal_representation_probe::main+0x90d>
   4cad5:	lea    0x10(%rsp),%rdi
   4cada:	mov    $0x1,%esi
   4cadf:	mov    $0x5,%edx
   4cae4:	call   *0x106506(%rip)        # 152ff0 <_DYNAMIC+0x3d8>
   4caea:	cmpb   $0x1,0x10(%rsp)
   4caef:	je     4d148 <hyperreal_representation_probe::main+0x928>
   4caf5:	mov    0x18(%rsp),%rax
   4cafa:	mov    %rax,0x20(%rsp)
   4caff:	movb   $0x0,0x10(%rsp)
   4cb04:	movq   $0x0,0x28(%rsp)
   4cb0d:	movabs $0x7ff8000000000001,%rax
   4cb17:	mov    %rax,0x38(%rsp)
   4cb1c:	lea    0x80(%rsp),%rdi
   4cb24:	lea    0x10(%rsp),%r14
   4cb29:	mov    %r14,%rsi
   4cb2c:	call   *0x1064c6(%rip)        # 152ff8 <_DYNAMIC+0x3e0>
   4cb32:	cmpb   $0xff,0x80(%rsp)
   4cb3a:	je     4d15e <hyperreal_representation_probe::main+0x93e>
   4cb40:	movdqu 0x80(%rsp),%xmm0
   4cb49:	movupd 0x90(%rsp),%xmm1
   4cb52:	movups 0xa0(%rsp),%xmm2
   4cb5a:	movaps %xmm2,0xf0(%rsp)
   4cb62:	movapd %xmm1,0xe0(%rsp)
   4cb6b:	movdqa %xmm0,0xd0(%rsp)
   4cb74:	lea    0xf8(%rsp),%r14
   4cb7c:	mov    %r14,%rdi
   4cb7f:	call   *0x106443(%rip)        # 152fc8 <_DYNAMIC+0x3b0>
   4cb85:	movq   %xmm0,0x50(%rsp)
   4cb8b:	mov    %rax,%r15
   4cb8e:	cmp    $0xffffffffffffffff,%rax
   4cb92:	jne    4cbcf <hyperreal_representation_probe::main+0x3af>
   4cb94:	lea    0xd0(%rsp),%rdi
   4cb9c:	call   *0x10645e(%rip)        # 153000 <_DYNAMIC+0x3e8>
   4cba2:	movq   %xmm0,0x50(%rsp)
   4cba8:	mov    %rax,%r15
   4cbab:	lea    0xd0(%rsp),%rdi
   4cbb3:	call   *0x10644f(%rip)        # 153008 <_DYNAMIC+0x3f0>
   4cbb9:	test   %al,%al
   4cbbb:	jne    4cbcf <hyperreal_representation_probe::main+0x3af>
   4cbbd:	mov    %r14,%rdi
   4cbc0:	mov    %r15,%rsi
   4cbc3:	movq   0x50(%rsp),%xmm0
   4cbc9:	call   *0x1063e1(%rip)        # 152fb0 <_DYNAMIC+0x398>
   4cbcf:	cmp    $0x1,%r15
   4cbd3:	jne    4d0be <hyperreal_representation_probe::main+0x89e>
   4cbd9:	movq   0x50(%rsp),%xmm0
   4cbdf:	movq   %xmm0,%rax
   4cbe4:	movabs $0x7fffffffffffffff,%rcx
   4cbee:	and    %rax,%rcx
   4cbf1:	movabs $0x7fefffffffffffff,%rax
   4cbfb:	cmp    %rax,%rcx
   4cbfe:	jg     4d0d0 <hyperreal_representation_probe::main+0x8b0>
   4cc04:	call   *0x106406(%rip)        # 153010 <_DYNAMIC+0x3f8>
   4cc0a:	mov    %rax,0x118(%rsp)
   4cc12:	mov    %edx,0x120(%rsp)
   4cc19:	cmp    $0xd,%r13
   4cc1d:	jne    4cc45 <hyperreal_representation_probe::main+0x425>
   4cc1f:	movabs $0x635f69705f6e6174,%rax
   4cc29:	xor    (%r12),%rax
   4cc2d:	movabs $0x6465686361635f69,%rcx
   4cc37:	xor    0x5(%r12),%rcx
   4cc3c:	or     %rax,%rcx
   4cc3f:	je     4cf73 <hyperreal_representation_probe::main+0x753>
   4cc45:	test   %rbx,%rbx
   4cc48:	je     4ccaa <hyperreal_representation_probe::main+0x48a>
   4cc4a:	lea    0xd0(%rsp),%r14
   4cc52:	lea    0x10(%rsp),%r15
   4cc57:	lea    0x80(%rsp),%r12
   4cc5f:	nop
   4cc60:	mov    %r14,0x10(%rsp)
   4cc65:	mov    0x10(%rsp),%rsi
   4cc6a:	mov    %r15,%rdi
   4cc6d:	call   4eb50 <<hyperreal::real::arithmetic::Real as core::clone::Clone>::clone>
   4cc72:	movdqu 0x10(%rsp),%xmm0
   4cc78:	movupd 0x20(%rsp),%xmm1
   4cc7e:	movups 0x30(%rsp),%xmm2
   4cc83:	movaps %xmm2,0xa0(%rsp)
   4cc8b:	movapd %xmm1,0x90(%rsp)
   4cc94:	movdqa %xmm0,0x80(%rsp)
   4cc9d:	mov    %r12,%rdi
   4cca0:	call   4c410 <core::ptr::drop_glue::<hyperreal::real::arithmetic::Real>>
   4cca5:	dec    %rbx
   4cca8:	jne    4cc60 <hyperreal_representation_probe::main+0x440>
   4ccaa:	lea    0x118(%rsp),%rdi
   4ccb2:	call   *0x106360(%rip)        # 153018 <_DYNAMIC+0x400>
   4ccb8:	lea    0xf8(%rsp),%r14
   4ccc0:	mov    %rax,%r15
   4ccc3:	mov    %edx,%ebx
   4ccc5:	mov    %r14,%rdi
   4ccc8:	call   *0x1062fa(%rip)        # 152fc8 <_DYNAMIC+0x3b0>
   4ccce:	movq   %xmm0,0x8(%rsp)
   4ccd4:	mov    %rax,%r12
   4ccd7:	cmp    $0xffffffffffffffff,%rax
   4ccdb:	jne    4cd18 <hyperreal_representation_probe::main+0x4f8>
   4ccdd:	lea    0xd0(%rsp),%rdi
   4cce5:	call   *0x106315(%rip)        # 153000 <_DYNAMIC+0x3e8>
   4cceb:	movq   %xmm0,0x8(%rsp)
   4ccf1:	mov    %rax,%r12
   4ccf4:	lea    0xd0(%rsp),%rdi
   4ccfc:	call   *0x106306(%rip)        # 153008 <_DYNAMIC+0x3f0>
   4cd02:	test   %al,%al
   4cd04:	jne    4cd18 <hyperreal_representation_probe::main+0x4f8>
   4cd06:	mov    %r14,%rdi
   4cd09:	mov    %r12,%rsi
   4cd0c:	movq   0x8(%rsp),%xmm0
   4cd12:	call   *0x106298(%rip)        # 152fb0 <_DYNAMIC+0x398>
   4cd18:	mov    %r12,0x80(%rsp)
   4cd20:	movsd  0x8(%rsp),%xmm1
   4cd26:	movsd  %xmm1,0x88(%rsp)
   4cd2f:	movq   $0x1,0x10(%rsp)
   4cd38:	movsd  0x50(%rsp),%xmm0
   4cd3e:	movsd  %xmm0,0x18(%rsp)
   4cd44:	cmp    $0x1,%r12
   4cd48:	jne    4d0ee <hyperreal_representation_probe::main+0x8ce>
   4cd4e:	ucomisd %xmm0,%xmm1
   4cd52:	jne    4d0ee <hyperreal_representation_probe::main+0x8ce>
   4cd58:	jp     4d0ee <hyperreal_representation_probe::main+0x8ce>
   4cd5e:	lea    0x10(%rsp),%rdi
   4cd63:	lea    0xd0(%rsp),%rsi
   4cd6b:	call   4eb50 <<hyperreal::real::arithmetic::Real as core::clone::Clone>::clone>
   4cd70:	lea    0x38(%rsp),%r12
   4cd75:	mov    %r12,%rdi
   4cd78:	call   *0x10624a(%rip)        # 152fc8 <_DYNAMIC+0x3b0>
   4cd7e:	movsd  %xmm0,0x8(%rsp)
   4cd84:	mov    %rax,%r14
   4cd87:	cmp    $0xffffffffffffffff,%rax
   4cd8b:	jne    4cdc2 <hyperreal_representation_probe::main+0x5a2>
   4cd8d:	lea    0x10(%rsp),%rdi
   4cd92:	call   *0x106268(%rip)        # 153000 <_DYNAMIC+0x3e8>
   4cd98:	movsd  %xmm0,0x8(%rsp)
   4cd9e:	mov    %rax,%r14
   4cda1:	lea    0x10(%rsp),%rdi
   4cda6:	call   *0x10625c(%rip)        # 153008 <_DYNAMIC+0x3f0>
   4cdac:	test   %al,%al
   4cdae:	jne    4cdc2 <hyperreal_representation_probe::main+0x5a2>
   4cdb0:	mov    %r12,%rdi
   4cdb3:	mov    %r14,%rsi
   4cdb6:	movsd  0x8(%rsp),%xmm0
   4cdbc:	call   *0x1061ee(%rip)        # 152fb0 <_DYNAMIC+0x398>
   4cdc2:	mov    %r14,0x100(%rsp)
   4cdca:	movsd  0x8(%rsp),%xmm1
   4cdd0:	movsd  %xmm1,0x108(%rsp)
   4cdd9:	movq   $0x1,0x80(%rsp)
   4cde5:	movsd  0x50(%rsp),%xmm0
   4cdeb:	movsd  %xmm0,0x88(%rsp)
   4cdf4:	cmp    $0x1,%r14
   4cdf8:	jne    4d10c <hyperreal_representation_probe::main+0x8ec>
   4cdfe:	ucomisd %xmm0,%xmm1
   4ce02:	jne    4d10c <hyperreal_representation_probe::main+0x8ec>
   4ce08:	jp     4d10c <hyperreal_representation_probe::main+0x8ec>
   4ce0e:	lea    0x10(%rsp),%rdi
   4ce13:	call   4c410 <core::ptr::drop_glue::<hyperreal::real::arithmetic::Real>>
   4ce18:	mov    $0x3b9aca00,%ecx
   4ce1d:	mov    %r15,%rax
   4ce20:	mul    %rcx
   4ce23:	mov    %ebx,%ecx
   4ce25:	add    %rax,%rcx
   4ce28:	adc    $0x0,%rdx
   4ce2c:	mov    %rcx,0x80(%rsp)
   4ce34:	mov    %rdx,0x88(%rsp)
   4ce3c:	movq   0x50(%rsp),%xmm0
   4ce42:	movq   %xmm0,0x100(%rsp)
   4ce4b:	lea    0xb0(%rsp),%rax
   4ce53:	mov    %rax,0x10(%rsp)
   4ce58:	lea    0x2251(%rip),%rax        # 4f0b0 <<alloc::string::String as core::fmt::Display>::fmt>
   4ce5f:	mov    %rax,0x18(%rsp)
   4ce64:	lea    0x110(%rsp),%rax
   4ce6c:	mov    %rax,0x20(%rsp)
   4ce71:	mov    0x1061a8(%rip),%rax        # 153020 <_DYNAMIC+0x408>
   4ce78:	mov    %rax,0x28(%rsp)
   4ce7d:	lea    0x80(%rsp),%rcx
   4ce85:	mov    %rcx,0x30(%rsp)
   4ce8a:	mov    0x106197(%rip),%rcx        # 153028 <_DYNAMIC+0x410>
   4ce91:	mov    %rcx,0x38(%rsp)
   4ce96:	lea    0x100(%rsp),%rcx
   4ce9e:	mov    %rcx,0x40(%rsp)
   4cea3:	mov    %rax,0x48(%rsp)
   4cea8:	lea    -0x2a86e(%rip),%rdi        # 22641 <anon.f528f8cddd6ae9d3ee873f0d5154aaae.22.llvm.10676021354292260747+0x110>
   4ceaf:	lea    0x10(%rsp),%rsi
   4ceb4:	call   *0x106176(%rip)        # 153030 <_DYNAMIC+0x418>
   4ceba:	lea    0xd0(%rsp),%rdi
   4cec2:	call   4c410 <core::ptr::drop_glue::<hyperreal::real::arithmetic::Real>>
   4cec7:	mov    0xb0(%rsp),%rsi
   4cecf:	test   %rsi,%rsi
   4ced2:	je     4cee7 <hyperreal_representation_probe::main+0x6c7>
   4ced4:	mov    0xb8(%rsp),%rdi
   4cedc:	mov    $0x1,%edx
   4cee1:	call   *0x105ff1(%rip)        # 152ed8 <_DYNAMIC+0x2c0>
   4cee7:	mov    0x60(%rsp),%r14
   4ceec:	mov    0x70(%rsp),%rcx
   4cef1:	mov    %rcx,%rax
   4cef4:	sub    %r14,%rax
   4cef7:	movabs $0xaaaaaaaaaaaaaaab,%rdx
   4cf01:	mul    %rdx
   4cf04:	cmp    %r14,%rcx
   4cf07:	je     4cf3f <hyperreal_representation_probe::main+0x71f>
   4cf09:	mov    %rdx,%rbx
   4cf0c:	shr    $0x4,%rbx
   4cf10:	add    $0x8,%r14
   4cf14:	mov    0x105fbd(%rip),%r15        # 152ed8 <_DYNAMIC+0x2c0>
   4cf1b:	jmp    4cf29 <hyperreal_representation_probe::main+0x709>
   4cf1d:	nopl   (%rax)
   4cf20:	add    $0x18,%r14
   4cf24:	dec    %rbx
   4cf27:	je     4cf3f <hyperreal_representation_probe::main+0x71f>
   4cf29:	mov    -0x8(%r14),%rsi
   4cf2d:	test   %rsi,%rsi
   4cf30:	je     4cf20 <hyperreal_representation_probe::main+0x700>
   4cf32:	mov    (%r14),%rdi
   4cf35:	mov    $0x1,%edx
   4cf3a:	call   *%r15
   4cf3d:	jmp    4cf20 <hyperreal_representation_probe::main+0x700>
   4cf3f:	mov    0x68(%rsp),%rax
   4cf44:	test   %rax,%rax
   4cf47:	je     4cf61 <hyperreal_representation_probe::main+0x741>
   4cf49:	mov    0x58(%rsp),%rdi
   4cf4e:	shl    $0x3,%rax
   4cf52:	lea    (%rax,%rax,2),%rsi
   4cf56:	mov    $0x8,%edx
   4cf5b:	call   *0x105f77(%rip)        # 152ed8 <_DYNAMIC+0x2c0>
   4cf61:	add    $0x128,%rsp
   4cf68:	pop    %rbx
   4cf69:	pop    %r12
   4cf6b:	pop    %r13
   4cf6d:	pop    %r14
   4cf6f:	pop    %r15
   4cf71:	pop    %rbp
   4cf72:	ret
   4cf73:	test   %rbx,%rbx
   4cf76:	je     4ccaa <hyperreal_representation_probe::main+0x48a>
   4cf7c:	lea    0x10(%rsp),%r14
   4cf81:	mov    0x106040(%rip),%rbp        # 152fc8 <_DYNAMIC+0x3b0>
   4cf88:	jmp    4cfaa <hyperreal_representation_probe::main+0x78a>
   4cf8a:	nopw   0x0(%rax,%rax,1)
   4cf90:	mov    %r15,0x10(%rsp)
   4cf95:	movq   0x8(%rsp),%xmm0
   4cf9b:	movq   %xmm0,0x18(%rsp)
   4cfa1:	dec    %rbx
   4cfa4:	je     4ccaa <hyperreal_representation_probe::main+0x48a>
   4cfaa:	lea    0xd0(%rsp),%rax
   4cfb2:	mov    %rax,0x10(%rsp)
   4cfb7:	mov    0x10(%rsp),%r13
   4cfbc:	lea    0x28(%r13),%r12
   4cfc0:	mov    %r12,%rdi
   4cfc3:	call   *%rbp
   4cfc5:	movq   %xmm0,0x8(%rsp)
   4cfcb:	mov    %rax,%r15
   4cfce:	cmp    $0xffffffffffffffff,%rax
   4cfd2:	jne    4cf90 <hyperreal_representation_probe::main+0x770>
   4cfd4:	mov    %r13,%rdi
   4cfd7:	call   *0x106023(%rip)        # 153000 <_DYNAMIC+0x3e8>
   4cfdd:	movq   %xmm0,0x8(%rsp)
   4cfe3:	mov    %rax,%r15
   4cfe6:	mov    %r13,%rdi
   4cfe9:	call   *0x106019(%rip)        # 153008 <_DYNAMIC+0x3f0>
   4cfef:	test   %al,%al
   4cff1:	jne    4cf90 <hyperreal_representation_probe::main+0x770>
   4cff3:	mov    %r12,%rdi
   4cff6:	mov    %r15,%rsi
   4cff9:	movq   0x8(%rsp),%xmm0
   4cfff:	call   *0x105fab(%rip)        # 152fb0 <_DYNAMIC+0x398>
   4d005:	jmp    4cf90 <hyperreal_representation_probe::main+0x770>
   4d007:	add    $0xd0,%dl
   4d00a:	xor    %eax,%eax
   4d00c:	cmp    $0xa,%dl
   4d00f:	adc    $0x1,%al
   4d011:	mov    %rdi,%r14
   4d014:	mov    %rsi,%r15
   4d017:	mov    %al,0x10(%rsp)
   4d01b:	lea    -0x28900(%rip),%rdi        # 24722 <anon.989e3a3df5a9b0c8132da4bb77c7c33a.35.llvm.7186563581096173296+0x372>
   4d022:	lea    0x10188f(%rip),%rcx        # 14e8b8 <__dso_handle+0x288>
   4d029:	lea    0x101790(%rip),%r8        # 14e7c0 <__dso_handle+0x190>
   4d030:	lea    0x10(%rsp),%rdx
   4d035:	mov    $0x2b,%esi
   4d03a:	call   *0x105ff8(%rip)        # 153038 <_DYNAMIC+0x420>
   4d040:	jmp    4d1c6 <hyperreal_representation_probe::main+0x9a6>
   4d045:	lea    -0x28b1c(%rip),%rdi        # 24530 <anon.989e3a3df5a9b0c8132da4bb77c7c33a.35.llvm.7186563581096173296+0x180>
   4d04c:	lea    0x10173d(%rip),%rdx        # 14e790 <__dso_handle+0x160>
   4d053:	mov    $0x4,%esi
   4d058:	call   *0x105fe2(%rip)        # 153040 <_DYNAMIC+0x428>
   4d05e:	jmp    4d1c6 <hyperreal_representation_probe::main+0x9a6>
   4d063:	movq   $0x0,0x78(%rsp)
   4d06c:	lea    0x58(%rsp),%rdi
   4d071:	call   4c6f0 <<std::env::Args as core::iter::traits::iterator::Iterator>::try_fold::<core::num::nonzero::NonZero<usize>, <std::env::Args as core::iter::traits::iterator::Iterator::advance_by::SpecAdvanceBy>::spec_advance_by::{closure#0}, core::option::Option<core::num::nonzero::NonZero<usize>>>>
   4d076:	test   %rax,%rax
   4d079:	je     4c8c0 <hyperreal_representation_probe::main+0xa0>
   4d07f:	lea    -0x28b06(%rip),%rdi        # 24580 <anon.989e3a3df5a9b0c8132da4bb77c7c33a.35.llvm.7186563581096173296+0x1d0>
   4d086:	lea    0x10171b(%rip),%rdx        # 14e7a8 <__dso_handle+0x178>
   4d08d:	mov    $0xa,%esi
   4d092:	call   *0x105fa8(%rip)        # 153040 <_DYNAMIC+0x428>
   4d098:	jmp    4d1c6 <hyperreal_representation_probe::main+0x9a6>
   4d09d:	movq   $0x0,0x78(%rsp)
   4d0a6:	lea    0x58(%rsp),%rdi
   4d0ab:	call   4c6f0 <<std::env::Args as core::iter::traits::iterator::Iterator>::try_fold::<core::num::nonzero::NonZero<usize>, <std::env::Args as core::iter::traits::iterator::Iterator::advance_by::SpecAdvanceBy>::spec_advance_by::{closure#0}, core::option::Option<core::num::nonzero::NonZero<usize>>>>
   4d0b0:	test   %rax,%rax
   4d0b3:	jne    4ca10 <hyperreal_representation_probe::main+0x1f0>
   4d0b9:	jmp    4c9f1 <hyperreal_representation_probe::main+0x1d1>
   4d0be:	lea    0x101773(%rip),%rdi        # 14e838 <__dso_handle+0x208>
   4d0c5:	call   *0x105e1d(%rip)        # 152ee8 <_DYNAMIC+0x2d0>
   4d0cb:	jmp    4d1c6 <hyperreal_representation_probe::main+0x9a6>
   4d0d0:	lea    -0x289db(%rip),%rdi        # 246fc <anon.989e3a3df5a9b0c8132da4bb77c7c33a.35.llvm.7186563581096173296+0x34c>
   4d0d7:	lea    0x101772(%rip),%rdx        # 14e850 <__dso_handle+0x220>
   4d0de:	mov    $0x26,%esi
   4d0e3:	call   *0x105ecf(%rip)        # 152fb8 <_DYNAMIC+0x3a0>
   4d0e9:	jmp    4d1c6 <hyperreal_representation_probe::main+0x9a6>
   4d0ee:	lea    0x101773(%rip),%rdx        # 14e868 <__dso_handle+0x238>
   4d0f5:	lea    0x80(%rsp),%rdi
   4d0fd:	lea    0x10(%rsp),%rsi
   4d102:	call   4c6a1 <core::panicking::assert_failed::<core::option::Option<f64>, core::option::Option<f64>>>
   4d107:	jmp    4d1c6 <hyperreal_representation_probe::main+0x9a6>
   4d10c:	lea    0x10176d(%rip),%rdx        # 14e880 <__dso_handle+0x250>
   4d113:	lea    0x100(%rsp),%rdi
   4d11b:	lea    0x80(%rsp),%rsi
   4d123:	call   4c6a1 <core::panicking::assert_failed::<core::option::Option<f64>, core::option::Option<f64>>>
   4d128:	jmp    4d1c6 <hyperreal_representation_probe::main+0x9a6>
   4d12d:	lea    -0x28a44(%rip),%rdi        # 246f0 <anon.989e3a3df5a9b0c8132da4bb77c7c33a.35.llvm.7186563581096173296+0x340>
   4d134:	lea    0x1016b5(%rip),%rdx        # 14e7f0 <__dso_handle+0x1c0>
   4d13b:	mov    $0x19,%esi
   4d140:	call   *0x105d9a(%rip)        # 152ee0 <_DYNAMIC+0x2c8>
   4d146:	jmp    4d1c6 <hyperreal_representation_probe::main+0x9a6>
   4d148:	lea    0x11(%rsp),%rax
   4d14d:	lea    0x1016b4(%rip),%r8        # 14e808 <__dso_handle+0x1d8>
   4d154:	lea    0xd0(%rsp),%r14
   4d15c:	jmp    4d16d <hyperreal_representation_probe::main+0x94d>
   4d15e:	lea    0x81(%rsp),%rax
   4d166:	lea    0x1016b3(%rip),%r8        # 14e820 <__dso_handle+0x1f0>
   4d16d:	movzbl (%rax),%eax
   4d170:	mov    %al,(%r14)
   4d173:	lea    -0x28a58(%rip),%rdi        # 24722 <anon.989e3a3df5a9b0c8132da4bb77c7c33a.35.llvm.7186563581096173296+0x372>
   4d17a:	lea    0x101717(%rip),%rcx        # 14e898 <__dso_handle+0x268>
   4d181:	mov    $0x2b,%esi
   4d186:	mov    %r14,%rdx
   4d189:	call   *0x105ea9(%rip)        # 153038 <_DYNAMIC+0x420>
   4d18f:	jmp    4d1c6 <hyperreal_representation_probe::main+0x9a6>
   4d191:	mov    $0x1,%al
   4d193:	jmp    4d011 <hyperreal_representation_probe::main+0x7f1>
   4d198:	test   %rsi,%rsi
   4d19b:	je     4d1ad <hyperreal_representation_probe::main+0x98d>
   4d19d:	mov    0x18(%rsp),%rdi
   4d1a2:	mov    $0x1,%edx
   4d1a7:	call   *0x105d2b(%rip)        # 152ed8 <_DYNAMIC+0x2c0>
   4d1ad:	lea    -0x28c2a(%rip),%rdi        # 2458a <anon.989e3a3df5a9b0c8132da4bb77c7c33a.35.llvm.7186563581096173296+0x1da>
   4d1b4:	lea    0x10161d(%rip),%rdx        # 14e7d8 <__dso_handle+0x1a8>
   4d1bb:	mov    $0x2c,%esi
   4d1c0:	call   *0x105df2(%rip)        # 152fb8 <_DYNAMIC+0x3a0>
   4d1c6:	ud2
   4d1c8:	xor    %eax,%eax
   4d1ca:	jmp    4d011 <hyperreal_representation_probe::main+0x7f1>
   4d1cf:	mov    %rax,%rbx
   4d1d2:	lea    0x10(%rsp),%rdi
   4d1d7:	call   4c410 <core::ptr::drop_glue::<hyperreal::real::arithmetic::Real>>
   4d1dc:	jmp    4d23e <hyperreal_representation_probe::main+0xa1e>
   4d1de:	jmp    4d1f3 <hyperreal_representation_probe::main+0x9d3>
   4d1e0:	jmp    4d20d <hyperreal_representation_probe::main+0x9ed>
   4d1e2:	jmp    4d20d <hyperreal_representation_probe::main+0x9ed>
   4d1e4:	mov    %rax,%rbx
   4d1e7:	lea    0x10(%rsp),%rdi
   4d1ec:	call   4c410 <core::ptr::drop_glue::<hyperreal::real::arithmetic::Real>>
   4d1f1:	jmp    4d210 <hyperreal_representation_probe::main+0x9f0>
   4d1f3:	mov    %rax,%rbx
   4d1f6:	lea    0x58(%rsp),%rdi
   4d1fb:	call   4c370 <core::ptr::drop_glue::<core::iter::adapters::skip::Skip<std::env::Args>>>
   4d200:	mov    %rbx,%rdi
   4d203:	call   14d470 <_Unwind_Resume@plt>
   4d208:	mov    %rax,%rbx
   4d20b:	jmp    4d23e <hyperreal_representation_probe::main+0xa1e>
   4d20d:	mov    %rax,%rbx
   4d210:	lea    0xd0(%rsp),%rdi
   4d218:	call   4c410 <core::ptr::drop_glue::<hyperreal::real::arithmetic::Real>>
   4d21d:	jmp    4d23e <hyperreal_representation_probe::main+0xa1e>
   4d21f:	call   *0x105c9b(%rip)        # 152ec0 <_DYNAMIC+0x2a8>
   4d225:	mov    %rax,%rbx
   4d228:	test   %r15,%r15
   4d22b:	je     4d23e <hyperreal_representation_probe::main+0xa1e>
   4d22d:	mov    %r15,%rsi
   4d230:	mov    $0x1,%edx
   4d235:	mov    %r14,%rdi
   4d238:	call   *0x105c9a(%rip)        # 152ed8 <_DYNAMIC+0x2c0>
   4d23e:	mov    0xb0(%rsp),%rsi
   4d246:	test   %rsi,%rsi
   4d249:	je     4d25e <hyperreal_representation_probe::main+0xa3e>
   4d24b:	mov    0xb8(%rsp),%rdi
   4d253:	mov    $0x1,%edx
   4d258:	call   *0x105c7a(%rip)        # 152ed8 <_DYNAMIC+0x2c0>
   4d25e:	lea    0x58(%rsp),%rdi
   4d263:	call   4c370 <core::ptr::drop_glue::<core::iter::adapters::skip::Skip<std::env::Args>>>
   4d268:	mov    %rbx,%rdi
   4d26b:	call   14d470 <_Unwind_Resume@plt>
