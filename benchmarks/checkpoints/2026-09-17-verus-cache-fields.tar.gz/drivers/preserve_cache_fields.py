#!/usr/bin/env python3
import gzip,hashlib,io,json,subprocess,tarfile
from pathlib import Path
Q=Path(__file__).resolve().parent;R=Path('/home/tim/Documents/GitHub/workspace/hyperreal');O=Q/'cache-fields-proof';D=R/'benchmarks/checkpoints';REV='9f9324797bc67c42b66782ac96e7e3c1a4f64e80'
e=json.loads((O/'official/evidence.json').read_text());assert e['verification_results']['verified']==583 and e['verification_results']['success']
for name,digest in e['sources'].items():assert hashlib.sha256(subprocess.check_output(['git','show',REV+':'+name],cwd=R)).hexdigest()==digest,name
assert (O/'rejections.log').read_text().count('Rejected incorrect')==19
assert 'Ran 10 tests' in (O/'acceptance-tests.log').read_text() and '\nOK\n' in (O/'acceptance-tests.log').read_text()
identity=json.loads((O/'runtime-identity.json').read_text());assert identity['all_production_and_manifest_bytes_unchanged']
files=[(p,str(p.relative_to(Q))) for p in O.rglob('*') if p.is_file()]
for package in e['dependencies']['packages']:
 source=Path(package['manifest_path']).parent
 for name,digest in e['dependencies']['sources'][package['id']].items():
  p=source/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==digest;files.append((p,'dependency-sources/'+package['name']+'-'+package['version']+'/'+name))
files.append((Q/'preserve_cache_fields.py','drivers/preserve_cache_fields.py'))
archive=D/'2026-09-17-verus-cache-fields.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as tar:
   for p,name in sorted(files,key=lambda pair:pair[1]):
    data=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
report={'schema':1,'status':'cache_word_model_milestone_not_atomic_implementation_verification','baseline':'a2da8e2b5de9a1a4653d3662f2f05cb6533fd7ef','proof_revision':REV,'runtime_reference':identity['runtime_reference'],'verification':{'units':583,'production_contracts':94,'model_theorems':112,'source_hashes':len(e['sources']),'all_match_commit':True,'no_cheating':True,'entire_target':True,'open_obligation_groups':13},'new_models':['Actual cache masks select disjoint fields.','Bound decoding ignores fields outside its mask.','The bound-update expression installs the checked encoding and preserves every retained field and exact-sign tag.','The exact-sign update expression installs a valid encoded tag and preserves the bound and other fields.','The initial packing expression preserves bounds, exact signs, both inverse-trig flags and every signed16-bit demand.'],'guards':{'fresh_cache_mutations_rejected':19,'new_cases':6,'acceptance_tests':10,'prior_unchanged_bound_mutations':54,'prior_unchanged_kernel_public_mutations':106,'prior_artifacts':['benchmarks/checkpoints/2026-09-17-verus-bound-composition.json','benchmarks/checkpoints/2026-09-17-verus-certified-planning.json'],'note':'No fresh combined179-case run is claimed.'},'runtime':{'all_production_manifest_lock_bytes_unchanged':True,'proof_only_change':True},'limits':['The word expressions match the currently inspected constructor and update loops, but these new lemmas do not verify those production bodies, atomic memory orderings, compare-exchange retries, publication invariants or caller preconditions.','The pure decoder model is not a proof of the still-unverified production bound decoder.','Cache payloads must still be shown to denote their graph values; bit preservation alone supplies no mathematical fact.','The cache obligation group is partial because pure production codecs and these word-level models are checked; all thirteen groups remain open.','Baseline acceptance remains pending.'],'artifact':{'path':str(archive.relative_to(R)),'bytes':archive.stat().st_size,'files':len(files),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}}
(D/'2026-09-17-verus-cache-fields.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report['artifact']))
