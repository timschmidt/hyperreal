#!/usr/bin/env python3
"""Reject loss of strict cache refinement and loss of initial zero separation."""
import sys
sys.dont_write_bytecode=True
sys.path.insert(0,'/home/tim/Documents/GitHub/workspace/hyperreal/verification')
import test_rejections as t
t.MUTATIONS=t.MUTATIONS[-2:]
assert len(t.MUTATIONS)==2 and all(r[0]=='real_approximation_model.rs' for r in t.MUTATIONS)
t.reject_bound_mutations=lambda:None
t.reject_cache_mutations=lambda:None
t.reject_structural_mutations=lambda:None
t.main()
