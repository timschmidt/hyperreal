#!/usr/bin/env python3
"""Check normal Rust erasure of the next cancellation proof at the matched path."""
import hashlib,json,os,subprocess,time
from pathlib import Path
Q=Path(__file__).resolve().parent;SOURCE=Q/'source';REPO=Path('/home/tim/Documents/GitHub/workspace/hyperreal');OUT=Q/'cancel-pair-proof'
CONFIG=json.loads((Q/'run.json').read_text());ENV=CONFIG['environment'] | {'CARGO_BUILD_JOBS':'4','CCACHE_DISABLE':'1','CARGO_NET_OFFLINE':'true','CARGO_TARGET_DIR':str(Q/'expansion-target')}
reference=Q/'shared-clone-candidate/expanded-runtime.rs';assert reference.is_file()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=SOURCE,text=True)
source=SOURCE/'src/verified/fraction.rs';original=source.read_bytes()
command=['cargo','+nightly','rustc','--locked','--lib','--no-default-features','--','-Zunpretty=expanded']
try:
 source.write_bytes((REPO/'src/verified/fraction.rs').read_bytes());start=time.time()
 with (OUT/'expanded-runtime.rs').open('w') as out,(OUT/'expanded-runtime.log').open('w') as err:
  r=subprocess.run(command,cwd=SOURCE,env=os.environ | ENV,stdout=out,stderr=err)
 report={'proof_commit':subprocess.check_output(['git','rev-parse','f128342'],cwd=REPO,text=True).strip(),
  'runtime_reference':subprocess.check_output(['git','rev-parse','561e36a'],cwd=REPO,text=True).strip(),
  'command':command,'environment':ENV,'cwd':str(SOURCE),'exit_code':r.returncode,'seconds':time.time()-start,
  'reference_sha256':hashlib.sha256(reference.read_bytes()).hexdigest(),
  'expanded_sha256':hashlib.sha256((OUT/'expanded-runtime.rs').read_bytes()).hexdigest(),
  'byte_identical_expanded_rust':r.returncode==0 and reference.read_bytes()==(OUT/'expanded-runtime.rs').read_bytes()}
 (OUT/'erasure.json').write_text(json.dumps(report,indent=2)+'\n');print(report)
 assert report['byte_identical_expanded_rust']
finally:
 source.write_bytes(original)
 status=subprocess.check_output(['git','status','--porcelain'],cwd=SOURCE,text=True);(OUT/'restored-status.txt').write_text(status);assert not status,status
