#!/usr/bin/env python3
"""Preserve the cross-cancellation induction step and ordinary Rust erasure."""
import gzip,hashlib,io,json,subprocess,tarfile
from pathlib import Path
Q=Path(__file__).resolve().parent;REPO=Path('/home/tim/Documents/GitHub/workspace/hyperreal');OUT=Q/'cancel-pair-proof';DEST=REPO/'benchmarks/checkpoints'
revision=subprocess.check_output(['git','rev-parse','f128342'],cwd=REPO,text=True).strip()
evidence=json.loads((OUT/'evidence.json').read_text());erasure=json.loads((OUT/'erasure.json').read_text())
assert erasure['exit_code']==0 and erasure['byte_identical_expanded_rust']
for p,h in evidence['sources'].items():assert hashlib.sha256(subprocess.check_output(['git','show',revision+':'+p],cwd=REPO)).hexdigest()==h,p
files=[(p,p.name) for p in OUT.iterdir() if p.is_file()]
files.extend((Q/name,'drivers/'+name) for name in ['erase_cancel_pair_proof.py','preserve_cancel_pair_proof.py'])
archive=DEST/'2026-09-17-verus-cancel-pair-proof.tar.gz'
with archive.open('wb') as output:
 with gzip.GzipFile(fileobj=output,mode='wb',filename='',mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as tar:
   for p,name in sorted(files,key=lambda x:x[1]):
    data=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
report={'schema':1,'status':'proof_milestone_not_acceptance','proof_commit':revision,'runtime_reference':erasure['runtime_reference'],
 'baseline':'a2da8e2b5de9a1a4653d3662f2f05cb6533fd7ef','verification_units':364,'production_contracts':52,'model_theorems':66,
 'source_hashes_checked':len(evidence['sources']),'open_obligation_groups':13,'no_cheating':True,
 'new_theorem':'Reducing the next numerator/denominator pair preserves positivity and coprimality of every already processed pair, including zero numerators.',
 'erasure':erasure,'limits':['The production cross-cancellation traversal and caller preconditions still require refinement proofs.','Full implementation/dependency verification and empirical baseline acceptance remain incomplete.'],
 'artifact':{'path':str(archive.relative_to(REPO)),'bytes':archive.stat().st_size,'files':len(files),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}}
(DEST/'2026-09-17-verus-cancel-pair-proof.json').write_text(json.dumps(report,indent=2)+'\n');print(report['artifact'])
