#!/usr/bin/env python3
"""Preserve certified-precision repairs, counterexamples and intermediate qualification."""
import gzip,hashlib,io,json,re,subprocess,tarfile
from pathlib import Path
Q=Path(__file__).resolve().parent;R=Path('/home/tim/Documents/GitHub/workspace/hyperreal');D=R/'benchmarks/checkpoints'
REV='89c89e278671719e568ce3acbea686821f91b8a2'
E=json.loads((Q/'certified-planning-proof/official/evidence.json').read_text())
assert E['verification_results']['success'] and E['verification_results']['verified']==548
for name,expected in E['sources'].items():assert hashlib.sha256(subprocess.check_output(['git','show',REV+':'+name],cwd=R)).hexdigest()==expected,name
validation=json.loads((Q/'certified-planning-validation/runs.json').read_text())
builds=json.loads((Q/'certified-planning-complete/validation-results.json').read_text())
fuzz=json.loads((Q/'certified-planning-fuzz/runs.json').read_text())
assert len(validation)==6 and len(builds)==9 and all(row['exit_code']==0 for row in validation+builds)
assert len(fuzz)==6 and all(row['exit_code']==0 for row in fuzz) and sum(row['corpus_files'] for row in fuzz)==6492
for name,expected in json.loads((Q/'certified-planning-validation/inputs.json').read_text())['overlays'].items():
 assert hashlib.sha256(subprocess.check_output(['git','show',REV+':'+name],cwd=R)).hexdigest()==expected,name
negative=(Q/'certified-planning-proof/rejections.log').read_text()
assert negative.count('Rejected incorrect')==157 and 'Rejected attempted assumption bypass' in negative
assert 'Ran 10 tests' in (Q/'certified-planning-proof/acceptance-tests.log').read_text()
assert '\nOK\n' in (Q/'certified-planning-proof/acceptance-tests.log').read_text()
counts={}
for label in ['default','all-feature']:
 text=(Q/'certified-planning-validation'/('candidate-'+label+'-all-targets.log')).read_text()
 counts[label]={'passed_tests':sum(map(int,re.findall(r'test result: ok\. (\d+) passed;',text))),'successful_benchmark_fixtures':text.count('\nSuccess\n')}
coverage=(Q/'certified-planning-complete/validation/coverage-matrix.stdout').read_text().split('Production executable lines (test-only source excluded):',1)[1]
rows={m[1]:{'lines':int(m[2]),'hit':int(m[3]),'missed':int(m[4])} for m in re.finditer(r'^(src/\S+)\s+(\d+)\s+(\d+)\s+(\d+)\s+[\d.]+%$',coverage,re.M)}
removed={name:row for name,row in rows.items() if name.endswith('_tests.rs') or name=='src/computable/approximation.rs'}
# These excluded files contain tests only. approximation.rs has imports/includes
# before its trailing named test module; all its executable lines are test code.
corrected={key:sum(row[key] for name,row in rows.items() if name not in removed) for key in ['lines','hit','missed']}
corrected['percent']=100*corrected['hit']/corrected['lines']
(Q/'certified-planning-complete/coverage-accounting-correction.json').write_text(json.dumps({'revision':REV,'excluded_test_only_rows':removed,'corrected':corrected,'original_report_retained':True,'reason':'The legacy parser recognized only modules named tests and missed *_tests.rs files and the trailing chudnovsky_pi_tests module.'},indent=2)+'\n')
files=[]
folders=['certified-planning-proof','certified-planning-validation','certified-planning-complete','certified-planning-fuzz','sum-planning-probe','inverse-planning-probe','tolerance-planning-probe','tolerance-planning-probe-invalid-license-path','tolerance-planning-probe-missing-examples']
for folder in folders:
 for p in (Q/folder).rglob('*'):
  if not p.is_file():continue
  parts=p.relative_to(Q/folder).parts
  if parts[0]=='bin' or 'corpus' in parts:continue
  files.append((p,str(p.relative_to(Q))))
for package in E['dependencies']['packages']:
 source=Path(package['manifest_path']).parent
 for name,expected in E['dependencies']['sources'][package['id']].items():
  p=source/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==expected
  files.append((p,'dependency-sources/'+package['name']+'-'+package['version']+'/'+name))
for name in ['preserve_certified_planning.py','qualify_certified_planning.py','qualify_certified_planning_builds.py','replay_certified_planning_corpora.py','probe_sum_planning.py','probe_sum_planning.rs','probe_inverse_planning.py','probe_inverse_planning.rs','probe_tolerance_planning.py','probe_tolerance_planning.rs','saved-corpora.json']:
 files.append((Q/name,'drivers/'+name))
archive=D/'2026-09-17-verus-certified-planning.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as tar:
   for p,name in sorted(files,key=lambda pair:pair[1]):
    data=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
report={
 'schema':1,'status':'correctness_repair_and_intermediate_qualification_not_acceptance','baseline':'a2da8e2b5de9a1a4653d3662f2f05cb6533fd7ef','candidate':REV,
 'counterexamples':{
  'chained_sum':{'expression':'(16 + n*pi)*pi at approximation precision0','affected':'Both pre-Verus baseline and cdc6d3a','n512':{'actual':5102,'mpfr_interval_contains':'5103.502935815188'},'n1024':{'actual':10154,'mpfr_interval_contains':'10156.74038917294'},'contract':'Returned integer must differ by at most one from the exact value.'},
  'reciprocal':{'expression':'1 / ((2-sqrt(4-2^-16))*pi) at approximation precision0','baseline_actual':83443,'cdc6d3a_actual':98304,'mpfr_interval_contains':'83442.947226216','affected':'Regression exposed by the earlier square-root metadata repair.'},
  'tolerance':{'expression':'Compare sqrt(pi) + (16 + 512*pi) to sqrt(pi) at absolute tolerance2^5','baseline_and_89c89e2':'Equal','independent_gap_lower_bound':1552,'followup_fix':'b3a23a4','exact_comparison':'Remains correctly ordered on both variants.','note':'The later tolerance repair requires its own affected qualification.'}},
 'repair':'Reciprocal, addition, multiplication and square-root precision kernels consume certified magnitudes or refine by approximation. Heuristic construction retains inexact hints.',
 'verification':{'units':548,'production_contracts':91,'model_theorems':103,'source_hashes':len(E['sources']),'all_hashes_match_candidate':True,'entire_target':True,'no_cheating':True,'open_obligation_groups':13,'mutation_guards_rejected':157,'assumption_bypass_rejected':True,'acceptance_tests_passed':10},
 'ordinary_checks':{'all_passed':True,'runs':validation,'counts':counts,'directed_mpfr_regressions':3},
 'remaining_build_checks':{'all_passed':True,'runs':builds},
 'frozen_fuzz':{'targets':6,'inputs':6492,'all_passed':True,'sanitizer':'address','leak_checker':'Disabled for the previously observed ptrace limitation.','corpus_artifact':'benchmarks/checkpoints/2026-09-17-verus-corpora.tar.gz','corpus_sha256':hashlib.sha256((D/'2026-09-17-verus-corpora.tar.gz').read_bytes()).hexdigest()},
 'coverage':{'legacy_report':{'lines':28753,'hit':26221,'missed':2532,'percent':91.19},'corrected_production_only':corrected,'removed_test_only_rows':removed,'note':'Raw reports are preserved. The legacy named-test-module accounting defect is repaired separately, and neither metric is a formal proof percentage.'},
 'failed_probe_preparation':['A guessed license filename failed git archive before the tolerance probe ran.','A partial diagnostic snapshot omitted an explicitly named Cargo example; both manifests failed to parse. The corrected complete target inputs permit both probes to run.'],
 'limits':['The 548-unit proof establishes the certificate query conditional on valid incoming bounds; graph, caller, cache and approximation-kernel proofs remain open.',
 'This revision remains affected by the separately discovered tolerance-comparison defect, repaired in b3a23a4.',
 'No native timing, resource-profile parity or downstream acceptance is claimed for this intermediate revision.',
 'Probe processes return success to record results; reported numerical counterexamples are failures, not passing arithmetic checks.',
 'Source/corpus hashes and raw evidence are preserved. Frozen executable bytes remain in temporary storage; build metadata and binary hashes are archived.',
 'All thirteen whole-implementation proof groups and final baseline acceptance remain incomplete.'],
 'artifact':{'path':str(archive.relative_to(R)),'bytes':archive.stat().st_size,'files':len(files),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}}
(D/'2026-09-17-verus-certified-planning.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'artifact':report['artifact'],'counts':counts,'corrected_coverage':corrected}))
