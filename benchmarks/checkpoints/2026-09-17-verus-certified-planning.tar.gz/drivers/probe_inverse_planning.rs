use hyperreal::{Computable, Rational};
use rug::{Float, Integer, float::{Constant, Round}, ops::{AddAssignRound, DivAssignRound, MulAssignRound}};

fn main() {
    for bits in [8_u32, 16, 24] {
        let denominator = 1_u64 << bits;
        let radicand = Rational::fraction((4 * denominator - 1) as i64, denominator).unwrap();
        let difference = Computable::rational(Rational::new(2))
            .add(Computable::rational(radicand).sqrt().negate());
        let difference_magnitude = difference.structural_facts().magnitude;
        let inverse = difference.inverse();
        let inverse_magnitude = inverse.structural_facts().magnitude;
        let actual = inverse.multiply(Computable::pi().inverse()).approx(0);
        // Rationalize the reference: 1 / ((2 - sqrt(4-epsilon))*pi)
        // == (2 + sqrt(4-epsilon)) / (epsilon*pi).
        let mut lower = Float::with_val(256, 4 * denominator - 1);
        lower.div_assign_round(denominator, Round::Down);
        let mut upper = lower.clone(); // The dyadic radicand is exactly representable.
        lower.sqrt_round(Round::Down);
        upper.sqrt_round(Round::Up);
        lower.add_assign_round(2, Round::Down);
        upper.add_assign_round(2, Round::Up);
        lower.mul_assign_round(denominator, Round::Down);
        upper.mul_assign_round(denominator, Round::Up);
        let pi_lower = Float::with_val_round(256, Constant::Pi, Round::Down).0;
        let pi_upper = Float::with_val_round(256, Constant::Pi, Round::Up).0;
        lower.div_assign_round(pi_upper, Round::Down);
        upper.div_assign_round(pi_lower, Round::Up);
        let answer = Float::with_val(256, Integer::from_str_radix(&actual.to_string(), 10).unwrap());
        let admitted_lower = Float::with_val_round(256, &lower - 1, Round::Down).0;
        let admitted_upper = Float::with_val_round(256, &upper + 1, Round::Up).0;
        let outside = answer < admitted_lower || answer > admitted_upper;
        println!("bits={bits}, difference={difference_magnitude:?}, inverse={inverse_magnitude:?}, actual={actual}, oracle=[{lower},{upper}], outside_one_unit={outside}");
    }
}
