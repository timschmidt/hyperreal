#!/usr/bin/env python3
"""Observe public chained-sum approximation against a directed MPFR interval."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

Q = Path(__file__).resolve().parent
S = Q / 'source'
O = Q / 'sum-planning-probe'
C = json.loads((Q / 'run.json').read_text())
C['candidate'] = 'cdc6d3a74fd2240f8037efe218c9ea424fd4e501'
E = C['environment'] | {'CARGO_TARGET_DIR':str(Q/'target'),'CARGO_BUILD_JOBS':'4',
    'CARGO_NET_OFFLINE':'true','CCACHE_DISABLE':'1'}
def git(*args): return subprocess.check_output(['git',*args],cwd=S,text=True).strip()
assert not git('status','--porcelain')
original = git('rev-parse','HEAD')
O.mkdir()
code = (Q / 'probe_sum_planning.rs').read_bytes()
(O / 'probe.rs').write_bytes(code)
records=[]
try:
    for label in ['baseline','candidate']:
        subprocess.run(['git','checkout','--detach',C[label]],cwd=S,check=True)
        path=S/'examples/sum_planning_probe.rs'
        assert not path.exists()
        path.write_bytes(code)
        command=['timeout','--signal=TERM','--kill-after=10s','180s','cargo','run','--locked','--example','sum_planning_probe']
        start=time.time()
        with (O/(label+'.log')).open('w') as log:
            result=subprocess.run(command,cwd=S,env=os.environ|E,stdout=log,stderr=subprocess.STDOUT)
        path.unlink()
        records.append({'label':label,'revision':C[label],'command':command,'cwd':str(S),'environment':E,
            'exit_code':result.returncode,'seconds':time.time()-start,'probe_sha256':hashlib.sha256(code).hexdigest()})
        (O/'runs.json').write_text(json.dumps(records,indent=2)+'\n')
        print(label,result.returncode,round(time.time()-start,1),flush=True)
finally:
    path=S/'examples/sum_planning_probe.rs'
    if path.exists():path.unlink()
    subprocess.run(['git','checkout','--detach',original],cwd=S,check=True)
    assert not git('status','--porcelain')
    (O/'restoration.json').write_text(json.dumps({'revision':original,'clean':True},indent=2)+'\n')
raise SystemExit(any(r['exit_code'] for r in records))
