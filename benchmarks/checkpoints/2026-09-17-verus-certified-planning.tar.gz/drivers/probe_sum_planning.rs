use hyperreal::{Computable, Rational};
use rug::{Float, Integer, float::{Constant, Round}, ops::{AddAssignRound, MulAssignRound}};

fn main() {
    for n in [32_i64, 128, 512, 1024] {
        let mut sum = Computable::rational(Rational::new(16));
        for _ in 0..n { sum = sum.add(Computable::pi()); }
        let magnitude = sum.structural_facts().magnitude;
        let actual = sum.multiply(Computable::pi()).approx(0);
        let mut lower = Float::with_val_round(256, Constant::Pi, Round::Down).0;
        let mut upper = Float::with_val_round(256, Constant::Pi, Round::Up).0;
        let pi_lower = lower.clone();
        let pi_upper = upper.clone();
        lower.mul_assign_round(n, Round::Down);
        upper.mul_assign_round(n, Round::Up);
        lower.add_assign_round(16, Round::Down);
        upper.add_assign_round(16, Round::Up);
        lower.mul_assign_round(&pi_lower, Round::Down);
        upper.mul_assign_round(&pi_upper, Round::Up);
        let answer = Float::with_val(256, Integer::from_str_radix(&actual.to_string(), 10).unwrap());
        let admitted_lower = Float::with_val(256, &lower - 1);
        let admitted_upper = Float::with_val(256, &upper + 1);
        let outside = answer < admitted_lower || answer > admitted_upper;
        println!("n={n}, magnitude={magnitude:?}, actual={actual}, oracle=[{lower},{upper}], outside_one_unit={outside}");
    }
}
