use hyperreal::{Computable, Rational};
fn main() {
    for n in [0_i64, 32, 128, 512] {
        for negative in [false, true] {
            let mut perturbation = Computable::rational(Rational::new(16));
            for _ in 0..n { perturbation = perturbation.add(Computable::pi()); }
            if negative { perturbation = perturbation.negate(); }
            let magnitude = perturbation.structural_facts().magnitude;
            let base = Computable::pi().sqrt();
            let value = base.clone().add(perturbation);
            println!("n={n}, negative={negative}, magnitude={magnitude:?}, absolute={:?}, reverse={:?}, exact={:?}, independent_gap_lower_bound={}",
                value.compare_absolute(&base, 5), base.compare_absolute(&value, 5), value.try_compare_to_until(&base, 5), 16+3*n);
        }
    }
}
