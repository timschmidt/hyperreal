#!/usr/bin/env python3
"""Replay all frozen baseline corpora with ASan on the committed certified-precision repair."""
import hashlib,json,os,subprocess,tarfile,time,sys
from pathlib import Path
Q=Path(__file__).resolve().parent;REPO=Path('/home/tim/Documents/GitHub/workspace/hyperreal');SOURCE=Q/'fuzz-source';OUT=Q/'certified-planning-fuzz'
CONFIG=json.loads((Q/'run.json').read_text());INVENTORY=json.loads((Q/'saved-corpora.json').read_text())
ENV=CONFIG['environment'] | {'CCACHE_DISABLE':'1','CARGO_BUILD_JOBS':'2','ASAN_OPTIONS':'detect_leaks=0'}
assert not subprocess.check_output(['git','status','--porcelain'],cwd=SOURCE,text=True)
original=subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip()
revision=subprocess.check_output(['git','rev-parse',sys.argv[1]],cwd=SOURCE,text=True).strip()
subprocess.run(['git','checkout','--detach',revision],cwd=SOURCE,check=True)
OUT.mkdir();records=[]
try:
 inputs=subprocess.check_output(['git','ls-files','-z','src','Cargo.toml','Cargo.lock','fuzz'],cwd=SOURCE).decode().split('\0')
 for name in inputs:
  if name and (REPO/name).is_file():assert (REPO/name).read_bytes()==(SOURCE/name).read_bytes(),name
 (OUT/'inputs.json').write_text(json.dumps({name:hashlib.sha256((SOURCE/name).read_bytes()).hexdigest() for name in inputs if name},indent=2)+'\n')
 hashes={name:hashlib.sha256((SOURCE/name).read_bytes()).hexdigest() for name in inputs if name}
 (OUT/'revision.json').write_text(json.dumps({'revision':revision,'baseline':CONFIG['baseline']},indent=2)+'\n')
 for target,files in INVENTORY.items():
  folder=OUT/target;(folder/'corpus').mkdir(parents=True);(folder/'artifacts').mkdir()
  with tarfile.open(REPO/'benchmarks/checkpoints/2026-09-17-verus-corpora.tar.gz') as archive:
   for name,digest in files.items():
    data=archive.extractfile(target+'/'+name).read();assert hashlib.sha256(data).hexdigest()==digest
    (folder/'corpus'/name).write_bytes(data)
  command=['cargo','+nightly','fuzz','run',target,str(folder/'corpus'),'--fuzz-dir','fuzz','--target-dir',str(Q/'fuzz-target'),'--','-runs=0','-timeout=10','-seed=93537','-artifact_prefix='+str(folder/'artifacts')+'/']
  start=time.time()
  with (folder/'run.log').open('w') as log:r=subprocess.run(command,cwd=SOURCE,env=os.environ | ENV,stdout=log,stderr=subprocess.STDOUT)
  records.append({'target':target,'command':command,'cwd':str(SOURCE),'environment':ENV,'source_sha256':hashes,'corpus_files':len(files),
    'exit_code':r.returncode,'seconds':time.time()-start,'sanitizer':'address','leak_checker_note':'LSan disabled for the previously observed ptrace limitation; ASan remains enabled.'})
  pending=OUT/'runs.next.json';pending.write_text(json.dumps(records,indent=2)+'\n');pending.replace(OUT/'runs.json');print(target,r.returncode,round(time.time()-start,1),flush=True)
  if r.returncode:raise RuntimeError('Frozen corpus replay failed: '+target)
finally:
 status=subprocess.check_output(['git','status','--porcelain'],cwd=SOURCE,text=True);(OUT/'restored-status.txt').write_text(status);assert not status,status
 subprocess.run(['git','checkout','--detach',original],cwd=SOURCE,check=True)
raise SystemExit(any(r['exit_code'] for r in records))
