#!/usr/bin/env python3
"""Observe absolute-tolerance ordering for perturbations larger than 2^5."""
import hashlib,io,json,os,shutil,subprocess,tarfile,time
from pathlib import Path
Q=Path(__file__).resolve().parent;R=Path('/home/tim/Documents/GitHub/workspace/hyperreal');S=Q/'consumer-diagnostics/hyperreal';O=Q/'tolerance-planning-probe'
C=json.loads((Q/'run.json').read_text());C['candidate']='89c89e278671719e568ce3acbea686821f91b8a2'
E=C['environment']|{'CARGO_TARGET_DIR':str(R/'target/consumer-diagnostics-scmfudw9'),'CARGO_BUILD_JOBS':'4','CARGO_NET_OFFLINE':'true','CCACHE_DISABLE':'1'}
original={str(p.relative_to(S)):p.read_bytes() for p in S.rglob('*') if p.is_file()}
for name,data in original.items():assert data==subprocess.check_output(['git','show','cdc6d3a:'+name],cwd=R),name
O.mkdir();code=(Q/'probe_tolerance_planning.rs').read_bytes();(O/'probe.rs').write_bytes(code);records=[]
try:
 for label in ['baseline','candidate']:
  rev=C[label]; data=subprocess.check_output(['git','archive',rev,'Cargo.toml','Cargo.lock','src','README.md','LICENSE-APACHE','LICENSE-MIT'],cwd=R)
  shutil.rmtree(S);S.mkdir()
  with tarfile.open(fileobj=io.BytesIO(data)) as tar:tar.extractall(S,filter='data')
  hashes={str(p.relative_to(S)):hashlib.sha256(p.read_bytes()).hexdigest() for p in S.rglob('*') if p.is_file()}
  (S/'examples').mkdir();(S/'examples/tolerance_planning_probe.rs').write_bytes(code)
  command=['timeout','--signal=TERM','--kill-after=10s','180s','cargo','run','--locked','--example','tolerance_planning_probe']
  start=time.time()
  with (O/(label+'.log')).open('w') as out:result=subprocess.run(command,cwd=S,env=os.environ|E,stdout=out,stderr=subprocess.STDOUT)
  records.append({'label':label,'revision':rev,'command':command,'cwd':str(S),'environment':E,'exit_code':result.returncode,'seconds':time.time()-start,'files':hashes,'probe_sha256':hashlib.sha256(code).hexdigest()})
  (O/'runs.json').write_text(json.dumps(records,indent=2)+'\n');print(label,result.returncode,flush=True)
finally:
 shutil.rmtree(S);S.mkdir()
 for name,data in original.items():p=S/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 assert original=={str(p.relative_to(S)):p.read_bytes() for p in S.rglob('*') if p.is_file()}
 (O/'restoration.json').write_text(json.dumps({'revision':'cdc6d3a','all_files_match_original':True},indent=2)+'\n')
raise SystemExit(any(r['exit_code'] for r in records))
