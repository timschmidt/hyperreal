#!/usr/bin/env python3
"""Archive the unadopted cache-copy experiment and original clone profiles."""
import gzip,hashlib,io,json,tarfile
from pathlib import Path
Q=Path(__file__).resolve().parent;REPO=Path('/home/tim/Documents/GitHub/workspace/hyperreal');DEST=REPO/'benchmarks/checkpoints'
for name,count in [('cache-snapshot-native',54),('cache-snapshot-criterion',12),('clone-criterion-profiles',4)]:
 runs=json.loads((Q/name/'runs.json').read_text())
 assert len(runs)==count and all(r['exit_code']==0 for r in runs)
 if name=='clone-criterion-profiles':assert all(r['report_exit_code']==r['annotate_exit_code']==0 for r in runs)
files={Q/name for name in ['run.json','build_cache_snapshot.py','time_cache_snapshot_probes.py','time_cache_snapshot_criterion.py',
 'summarize_native_probes.py','summarize_cache_criterion.py','profile_clone_criterion.py','preserve_snapshot_diagnostics.py']}
for name in ['cache-snapshot-native','cache-snapshot-criterion','clone-criterion-profiles']:
 files.update(p for p in (Q/name).rglob('*') if p.is_file())
files.update(p for p in (Q/'cache-snapshot-fix').iterdir() if p.is_file() and p.name!='probe')
archive=DEST/'2026-09-17-verus-clone-profiles.tar.gz'
with archive.open('wb') as output:
 with gzip.GzipFile(fileobj=output,mode='wb',filename='',mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as tar:
   for p in sorted(files):
    data=p.read_bytes();info=tarfile.TarInfo(str(p.relative_to(Q)));info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
native=json.loads((Q/'cache-snapshot-native/comparison.json').read_text())['comparisons']
criterion=json.loads((Q/'cache-snapshot-criterion/comparison.json').read_text())['comparisons']
report={'schema':1,'status':'experiment_not_adopted_not_acceptance','baseline':'a2da8e2b5de9a1a4653d3662f2f05cb6533fd7ef',
 'runtime_base':'8c7484915da3f39d6a6754c7411277b2809cb467','overlay_patch_sha256':hashlib.sha256((Q/'cache-snapshot-fix/change.patch').read_bytes()).hexdigest(),
 'native':[{'case':r['case'],'label':r['label'],'median_paired_change_percent':r['median_paired_change_percent'],
  'paired_cycles_change_percent':[p['change_percent']['cycles:u'] for p in r['pairs']]} for r in native],
 'criterion':[{'case':r['case'],'label':r['label'],'median_paired_mean_change_percent':r['median_paired_mean_change_percent'],
  'paired_mean_change_percent':[p['mean_change_percent'] for p in r['pairs']]} for r in criterion],
 'profiles':json.loads((Q/'clone-criterion-profiles/runs.json').read_text()),
 'findings':['The direct atomic cache-copy variant has essentially the same measured instructions per iteration as the inline-accessor-only experiment; it has not justified another production change.',
  'Criterion clone and unchanged MPFR export samples show substantial between-run variation, including one MPFR pair near +77%. The negative median clone ratio is not accepted as resolution of the existing regression.',
  'Sampled original pi_pow clone profiles locate substantial work in Node construction, shared-constant wrappers, multiplication and node dropping. Computable already stores its immutable node in Arc; Real cloning currently reconstructs many symbolic payloads.',
  'These sampled profiles ran separately from native timing. Profile elapsed times and raw event totals are not benchmark comparisons.',
  'Full verification and fixed-baseline acceptance remain pending. The next shared-computable-clone experiment is separate and is not qualified by this checkpoint.'],
 'artifact':{'path':str(archive.relative_to(REPO)),'bytes':archive.stat().st_size,'files':len(files),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}}
(DEST/'2026-09-17-verus-clone-profiles.json').write_text(json.dumps(report,indent=2)+'\n')
print(report['artifact'])
