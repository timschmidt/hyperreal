#!/usr/bin/env python3
"""Locate original Criterion clone costs; sampled profiles are not native timings."""
import hashlib,json,os,shutil,subprocess,time
from pathlib import Path
Q=Path(__file__).resolve().parent;CONFIG=json.loads((Q/'run.json').read_text());OUT=Q/'clone-criterion-profiles';OUT.mkdir()
RUNTIME=Q/'clone-profile-runtime';RUNTIME.mkdir();binary=RUNTIME/'real_representations'
ENV=CONFIG['environment'] | {'CRITERION_HOME':str(RUNTIME/'criterion'),'PERF_BUILDID_DIR':str(OUT/'buildid-cache'),'LC_ALL':'C'}
VARIANTS={'baseline':Q/'baseline/bin/real_representations','fraction':Q/'fraction-candidate/bin/real_representations',
 'inline':Q/'cache-inline-fix/bin/real_representations','snapshot':Q/'cache-snapshot-fix/bin/real_representations'}
records=[]
for label,source in VARIANTS.items():
 folder=OUT/label;folder.mkdir();shutil.copy2(source,binary)
 checksum=hashlib.sha256(binary.read_bytes()).hexdigest()
 command=['perf','record','--no-buildid-cache','-e','cycles:u','-c','100003','-o',str(folder/'perf.data'),'--',
  'taskset','-c','2',str(binary),'--bench','^real_representation_prepared/hyperreal_clone/pi_pow$','--profile-time','5']
 start=time.time()
 with (folder/'record.log').open('w') as log:result=subprocess.run(command,cwd=Q/'source',env=os.environ | ENV,stdout=log,stderr=subprocess.STDOUT)
 record={'label':label,'command':command,'cwd':str(Q/'source'),'environment':ENV,'binary_sha256':checksum,'exit_code':result.returncode,'seconds':time.time()-start,'native_timing':False}
 if result.returncode==0:
  for name,cmd in [
    ('report',['perf','report','--stdio','--no-children','--percent-limit','0.5','-i',str(folder/'perf.data')]),
    ('annotate',['perf','annotate','--stdio','--percent-limit','1','-i',str(folder/'perf.data')]),
  ]:
   with (folder/(name+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=Q/'source',env=os.environ | ENV,stdout=log,stderr=subprocess.STDOUT)
   record[name+'_exit_code']=r.returncode
 records.append(record);(OUT/'runs.json').write_text(json.dumps(records,indent=2)+'\n')
 print(label,result.returncode,round(time.time()-start,1),flush=True)
 if result.returncode:raise SystemExit(result.returncode)
