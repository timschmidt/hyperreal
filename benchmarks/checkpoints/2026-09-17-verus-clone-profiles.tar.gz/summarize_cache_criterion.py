#!/usr/bin/env python3
"""Summarize matched Criterion means without pooling cases or excluding runs."""
import json,statistics,sys
from pathlib import Path
folder=Path(sys.argv[1]);config=json.loads((folder/'config.json').read_text());runs=json.loads((folder/'runs.json').read_text())
assert len(runs)==len(config['orders'])*len(config['revisions'])
assert all(r['exit_code']==0 for r in runs)
measurements={}
for run in runs:
    cases={}
    for path in Path(run['directory']).rglob('new/benchmark.json'):
        identity=json.loads(path.read_text())['full_id']
        assert identity not in cases
        cases[identity]=json.loads((path.parent/'estimates.json').read_text())
    assert len(cases)==5,(run,len(cases))
    measurements[(run['round'],run['label'])]=cases
ids=set(next(iter(measurements.values())))
assert all(set(cases)==ids for cases in measurements.values())
rows=[]
for case in sorted(ids):
    for label in config['revisions']:
        if label=='baseline':continue
        pairs=[]
        for number in range(1,len(config['orders'])+1):
            b=measurements[(number,'baseline')][case];v=measurements[(number,label)][case]
            pairs.append({'round':number,'baseline_estimates':b,'variant_estimates':v,
                'mean_change_percent':100*(v['mean']['point_estimate']/b['mean']['point_estimate']-1),
                'mean_intervals_overlap':not(v['mean']['confidence_interval']['lower_bound']>b['mean']['confidence_interval']['upper_bound'] or
                    b['mean']['confidence_interval']['lower_bound']>v['mean']['confidence_interval']['upper_bound'])})
        row={'case':case,'label':label,'median_paired_mean_change_percent':statistics.median(p['mean_change_percent'] for p in pairs),'pairs':pairs}
        rows.append(row);print(case,label,round(row['median_paired_mean_change_percent'],3),[round(p['mean_change_percent'],2) for p in pairs])
(folder/'comparison.json').write_text(json.dumps({'method':'Median of within-round Criterion mean ratios; all runs retained. Per-run estimate intervals are not a paired-ratio confidence interval.',
    'limits':config['limits'],'comparisons':rows},indent=2)+'\n')
