#!/usr/bin/env python3
"""Summarize balanced native counter runs; retain every paired observation."""
import json, statistics, sys
from pathlib import Path
folder=Path(sys.argv[1])
runs=json.loads((folder/'runs.json').read_text())
config=json.loads((folder/'config.json').read_text())
assert len(runs)==len(config['orders'])*len(config['cases'])*len(config['revisions'])
assert all(r['exit_code']==0 and r['all_counters_numeric'] for r in runs)
def counters(row):
    return {('task-clock' if c['event']=='task-clock:u' else c['event']):c['value'] for c in row['counters']}
comparisons=[]
for case in config['cases']:
    for label in config['revisions']:
        if label=='baseline': continue
        pairs=[]
        for round_number in range(1,len(config['orders'])+1):
            base=next(r for r in runs if r['case']==case and r['round']==round_number and r['label']=='baseline')
            variant=next(r for r in runs if r['case']==case and r['round']==round_number and r['label']==label)
            b,v=counters(base),counters(variant)
            pairs.append({'round':round_number,'baseline':b,'variant':v,
                'change_percent':{e:100*(v[e]/b[e]-1) for e in b if b[e]}})
        summary={'case':case,'label':label,'revision':config['revisions'][label],
            'median_paired_change_percent':{e:statistics.median(p['change_percent'][e] for p in pairs) for e in pairs[0]['change_percent']},'pairs':pairs}
        comparisons.append(summary)
        print(case,label,summary['median_paired_change_percent'])
(folder/'comparison.json').write_text(json.dumps({'method':'Median of within-round ratios against fixed baseline. No outliers removed.',
    'limits':config['limits'],'comparisons':comparisons},indent=2)+'\n')
