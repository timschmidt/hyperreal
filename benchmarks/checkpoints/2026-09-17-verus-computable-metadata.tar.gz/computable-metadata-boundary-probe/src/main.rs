use hyperreal::{Computable, MagnitudeBits, Rational, ZeroKnowledge};
use num::{BigInt, BigUint};
fn main() {
    let case=std::env::args().nth(1).expect("case");
    let (exponent, negative) = match case.as_str() {
        "zero" | "one" => (0_i64, false),
        "integer-max" => (i32::MAX as i64, false),
        "integer-above" => (i32::MAX as i64 + 1, false),
        "ratio-min" => (i32::MIN as i64, false),
        "ratio-below" => (i32::MIN as i64 - 1, false),
        "negative-ratio-below" => (i32::MIN as i64 - 1, true),
        _ => panic!("unknown case"),
    };
    let rational=if case=="zero" { Rational::new(0) }
        else if exponent>=0 { Rational::from_bigint(BigInt::from(1) << exponent as u64) }
        else { Rational::from_bigint_fraction(BigInt::from(if negative {-1} else {1}), BigUint::from(1_u8) << exponent.unsigned_abs()).unwrap() };
    let value=Computable::rational(rational);
    let zero=value.zero_status();
    let magnitude=value.structural_facts().magnitude;
    println!("case={case}, exponent={exponent}, zero={zero:?}, magnitude={magnitude:?}");
    assert_eq!(zero, if case=="zero" {ZeroKnowledge::Zero} else {ZeroKnowledge::NonZero});
    let expected=if case=="zero" {None} else {i32::try_from(exponent).ok().map(|msd|MagnitudeBits{msd,exact_msd:true})};
    assert_eq!(magnitude,expected);
}
