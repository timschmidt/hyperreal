pub type Precision = i32;
const ATAN2_SIGN_REFINEMENT_FLOOR: Precision = -4096;
const DEFAULT_COMPARE_REFINEMENT_FLOOR: Precision = -4096;

#[derive(Clone, Copy, Debug, PartialEq, Default)]
pub(crate) enum BoundCache {
    #[default]
    Invalid,
    Valid(BoundInfo),
}

#[derive(Clone, Copy, Debug, PartialEq, Default)]
pub(crate) enum ExactSignCache {
    #[default]
    Invalid,
    Unknown,
    Valid(Sign),
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum BoundInfo {
    // Unknown means the expression may still be zero or either sign; callers
    // must not use it to short-circuit exact predicates.
    Unknown,
    // Exact structural zero, usually from rational leaves or annihilating
    // products.
    Zero,
    // NonZero may have an unknown sign or inexact MSD. That is still enough for
    // zero-status fast paths and precision planning.
    NonZero {
        sign: Option<Sign>,
        msd: Option<Precision>,
        exact_msd: bool,
    },
}

impl BoundInfo {
    fn with_sign(sign: Sign, msd: Option<Precision>) -> Self {
        Self::with_sign_msd(sign, msd, true)
    }

    fn with_sign_msd(sign: Sign, msd: Option<Precision>, exact_msd: bool) -> Self {
        match sign {
            Sign::NoSign => Self::Zero,
            _ => Self::NonZero {
                sign: Some(sign),
                msd,
                exact_msd,
            },
        }
    }

    fn from_rational(r: &Rational) -> Self {
        Self::with_sign(r.sign(), r.msd_exact())
    }

    fn map_msd(self, f: impl FnOnce(Precision) -> Option<Precision>) -> Self {
        match self {
            Self::NonZero {
                sign,
                msd,
                exact_msd,
            } => Self::NonZero {
                sign,
                msd: msd.and_then(f),
                exact_msd,
            },
            other => other,
        }
    }

    fn negate(self) -> Self {
        match self {
            Self::NonZero {
                sign: Some(Sign::Plus),
                msd,
                exact_msd,
            } => Self::NonZero {
                sign: Some(Sign::Minus),
                msd,
                exact_msd,
            },
            Self::NonZero {
                sign: Some(Sign::Minus),
                msd,
                exact_msd,
            } => Self::NonZero {
                sign: Some(Sign::Plus),
                msd,
                exact_msd,
            },
            other => other,
        }
    }

    fn inverse(self) -> Self {
        match self {
            Self::NonZero { sign, msd, .. } => Self::NonZero {
                sign,
                msd: msd.and_then(|value| 1_i32.checked_sub(value)),
                exact_msd: false,
            },
            other => other,
        }
    }

    fn square(self) -> Self {
        match self {
            Self::Zero => Self::Zero,
            Self::NonZero {
                msd, exact_msd, ..
            } => Self::NonZero {
                sign: Some(Sign::Plus),
                // One square can estimate the result within one binade from an
                // exact child MSD. Do not recursively double an already
                // inexact estimate: the error would grow exponentially through
                // a power tree.
                msd: exact_msd.then(|| msd.and_then(|value| value.checked_mul(2))).flatten(),
                exact_msd: false,
            },
            Self::Unknown => Self::Unknown,
        }
    }

    fn sqrt(self) -> Self {
        match self {
            Self::Zero => Self::Zero,
            Self::NonZero {
                sign: Some(Sign::Plus),
                msd,
                exact_msd,
            } => Self::NonZero {
                sign: Some(Sign::Plus),
                // 2^k <= x < 2^(k+1) implies that sqrt(x)'s binade is
                // floor(k / 2), including negative odd exponents.
                msd: msd.map(crate::verified::word::floor_half),
                exact_msd,
            },
            _ => Self::Unknown,
        }
    }

    fn multiply(self, other: Self) -> Self {
        match (self, other) {
            (Self::Zero, _) | (_, Self::Zero) => Self::Zero,
            (
                Self::NonZero {
                    sign: left_sign,
                    msd: left_msd,
                    exact_msd: left_exact_msd,
                },
                Self::NonZero {
                    sign: right_sign,
                    msd: right_msd,
                    exact_msd: right_exact_msd,
                },
            ) => {
                let sign = match (left_sign, right_sign) {
                    (Some(Sign::Plus), Some(Sign::Plus))
                    | (Some(Sign::Minus), Some(Sign::Minus)) => Some(Sign::Plus),
                    (Some(Sign::Plus), Some(Sign::Minus))
                    | (Some(Sign::Minus), Some(Sign::Plus)) => Some(Sign::Minus),
                    _ => None,
                };
                let msd = match (
                    left_exact_msd.then_some(left_msd).flatten(),
                    right_exact_msd.then_some(right_msd).flatten(),
                ) {
                    (Some(left), Some(right)) => left.checked_add(right),
                    _ => None,
                };
                Self::NonZero {
                    sign,
                    msd,
                    exact_msd: false,
                }
            }
            _ => Self::Unknown,
        }
    }

    fn add(self, other: Self) -> Self {
        // Addition can certify sign when operands share a sign or one MSD
        // dominates an opposite-signed operand. Near-cancellation deliberately
        // returns Unknown so callers fall back to refinement.
        match (self, other) {
            (Self::Zero, other) | (other, Self::Zero) => other,
            (
                Self::NonZero {
                    sign: left_sign,
                    msd: left_msd,
                    exact_msd: left_exact_msd,
                },
                Self::NonZero {
                    sign: right_sign,
                    msd: right_msd,
                    exact_msd: right_exact_msd,
                },
            ) => {
                let sign = match (left_sign, right_sign) {
                    (Some(left), Some(right)) if left == right => Some(left),
                    (Some(Sign::Plus), Some(Sign::Minus))
                    | (Some(Sign::Minus), Some(Sign::Plus))
                        if left_exact_msd && right_exact_msd =>
                    {
                        match (left_msd, right_msd) {
                            (Some(left), Some(right)) if left > right => left_sign,
                            (Some(left), Some(right)) if right > left => right_sign,
                            _ => None,
                        }
                    }
                    _ => None,
                };
                let msd = match (left_msd, right_msd) {
                    (Some(left), Some(right)) if left > right => Some(left),
                    (Some(left), Some(right)) if right > left => Some(right),
                    _ => None,
                };
                match sign {
                    Some(sign) => Self::NonZero {
                        sign: Some(sign),
                        msd,
                        exact_msd: false,
                    },
                    None => Self::Unknown,
                }
            }
            _ => Self::Unknown,
        }
    }

    fn known_msd(&self) -> Option<Option<Precision>> {
        // Some(None) certifies zero. A nonzero value without a representable
        // exponent must remain an unresolved magnitude query.
        match self {
            Self::Unknown => None,
            Self::Zero => Some(None),
            Self::NonZero {
                msd: Some(msd),
                exact_msd: true,
                ..
            } => Some(Some(*msd)),
            Self::NonZero { .. } => None,
        }
    }

    fn planning_msd(&self) -> Option<Option<Precision>> {
        match self {
            Self::Unknown => None,
            Self::Zero => Some(None),
            Self::NonZero { msd: Some(msd), .. } => Some(Some(*msd)),
            Self::NonZero { msd: None, .. } => None,
        }
    }

    fn known_sign(&self) -> Option<Sign> {
        match self {
            Self::Zero => Some(Sign::NoSign),
            Self::NonZero { sign, .. } => *sign,
            Self::Unknown => None,
        }
    }

    fn magnitude_bits(&self) -> Option<MagnitudeBits> {
        match self {
            Self::NonZero {
                msd: Some(msd),
                exact_msd,
                ..
            } => Some(MagnitudeBits {
                msd: *msd,
                exact_msd: *exact_msd,
            }),
            _ => None,
        }
    }
}

impl SharedConstant {
    fn bound_info(self) -> BoundInfo {
        // Coarse but exact-enough MSD facts for shared constants. These feed
        // structural queries and trig/ln reduction planning without forcing a
        // cached approximation.
        let msd = match self {
            SharedConstant::E | SharedConstant::Pi | SharedConstant::Ln10 => Some(1),
            SharedConstant::InvPi => Some(-2),
            SharedConstant::AtanInv2 => Some(-2),
            SharedConstant::AtanInv5 => Some(-3),
            SharedConstant::Tau => Some(2),
            SharedConstant::Ln2 => Some(-1),
            SharedConstant::Asinh1 => Some(-1),
            SharedConstant::AtanThreeHalves => Some(-1),
            SharedConstant::Ln3
            | SharedConstant::Ln5
            | SharedConstant::Ln6
            | SharedConstant::Ln7
            | SharedConstant::Sqrt2
            | SharedConstant::Sqrt3
            | SharedConstant::Acosh2
            | SharedConstant::Atan2 => Some(0),
        };
        BoundInfo::with_sign(Sign::Plus, msd)
    }

    fn interval(self) -> (Rational, Rational) {
        // Narrow rational intervals used only for constant+rational sign
        // certificates. They are intentionally cheap and hand-picked, not a
        // replacement for high-precision approximation.
        match self {
            Self::E => (
                Rational::fraction(271_828, 100_000).unwrap(),
                Rational::fraction(271_829, 100_000).unwrap(),
            ),
            Self::Pi => (
                Rational::fraction(333, 106).unwrap(),
                Rational::fraction(355, 113).unwrap(),
            ),
            Self::InvPi => (
                Rational::fraction(113, 355).unwrap(),
                Rational::fraction(106, 333).unwrap(),
            ),
            Self::Tau => (
                Rational::fraction(333, 53).unwrap(),
                Rational::fraction(710, 113).unwrap(),
            ),
            Self::AtanInv5 => (
                Rational::fraction(19, 100).unwrap(),
                Rational::fraction(1, 5).unwrap(),
            ),
            Self::AtanInv2 => (
                Rational::fraction(46, 100).unwrap(),
                Rational::fraction(47, 100).unwrap(),
            ),
            Self::Atan2 => (
                Rational::fraction(110, 100).unwrap(),
                Rational::fraction(111, 100).unwrap(),
            ),
            Self::AtanThreeHalves => (
                Rational::fraction(98, 100).unwrap(),
                Rational::fraction(99, 100).unwrap(),
            ),
            Self::Ln2 => (
                Rational::fraction(69, 100).unwrap(),
                Rational::fraction(7, 10).unwrap(),
            ),
            Self::Ln3 => (
                Rational::fraction(109, 100).unwrap(),
                Rational::fraction(11, 10).unwrap(),
            ),
            Self::Ln5 => (
                Rational::fraction(160, 100).unwrap(),
                Rational::fraction(161, 100).unwrap(),
            ),
            Self::Ln6 => (
                Rational::fraction(179, 100).unwrap(),
                Rational::fraction(18, 10).unwrap(),
            ),
            Self::Ln7 => (
                Rational::fraction(194, 100).unwrap(),
                Rational::fraction(195, 100).unwrap(),
            ),
            Self::Ln10 => (
                Rational::fraction(230, 100).unwrap(),
                Rational::fraction(231, 100).unwrap(),
            ),
            Self::Sqrt2 => (
                Rational::fraction(141, 100).unwrap(),
                Rational::fraction(142, 100).unwrap(),
            ),
            Self::Sqrt3 => (
                Rational::fraction(173, 100).unwrap(),
                Rational::fraction(174, 100).unwrap(),
            ),
            Self::Acosh2 => (
                Rational::fraction(131, 100).unwrap(),
                Rational::fraction(132, 100).unwrap(),
            ),
            Self::Asinh1 => (
                Rational::fraction(88, 100).unwrap(),
                Rational::fraction(89, 100).unwrap(),
            ),
        }
    }
}

fn negate_sign(sign: Sign) -> Sign {
    match sign {
        Sign::Plus => Sign::Minus,
        Sign::Minus => Sign::Plus,
        Sign::NoSign => Sign::NoSign,
    }
}

fn public_sign(sign: Sign) -> RealSign {
    match sign {
        Sign::Minus => RealSign::Negative,
        Sign::NoSign => RealSign::Zero,
        Sign::Plus => RealSign::Positive,
    }
}

fn private_sign(sign: RealSign) -> Sign {
    match sign {
        RealSign::Negative => Sign::Minus,
        RealSign::Zero => Sign::NoSign,
        RealSign::Positive => Sign::Plus,
    }
}

use std::sync::atomic::AtomicBool;

pub type Signal = Arc<AtomicBool>;

pub(crate) fn should_stop(signal: &Option<Signal>) -> bool {
    use std::sync::atomic::Ordering::*;
    signal.as_ref().is_some_and(|s| s.load(Relaxed))
}

// Constants are value objects, so separate `Computable::pi()` calls are common.
// A process-wide lock-free cache lets every worker reuse the finest certified
// approximation instead of recomputing constants once per thread.
static SHARED_CONSTANT_CACHES: LazyLock<[ApproximationCache; SharedConstant::COUNT]> =
    LazyLock::new(|| std::array::from_fn(|_| ApproximationCache::default()));
