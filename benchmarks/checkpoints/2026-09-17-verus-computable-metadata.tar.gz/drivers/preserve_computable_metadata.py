#!/usr/bin/env python3
"""Preserve metadata counterexamples and the committed repair's exact inputs."""
import difflib, gzip, hashlib, io, json, re, subprocess, tarfile
from pathlib import Path

Q = Path(__file__).resolve().parent
R = Path('/home/tim/Documents/GitHub/workspace/hyperreal')
D = R / 'benchmarks/checkpoints'
revision = subprocess.check_output(['git', 'rev-parse', 'cdc6d3a'], cwd=R, text=True).strip()
def committed(name):
    return subprocess.check_output(['git', 'show', revision + ':' + name], cwd=R)
def digest(data):
    return hashlib.sha256(data).hexdigest()
def read(path):
    return json.loads(path.read_text())

e = read(R / 'target/verification/evidence.json')
assert e['verification_results']['verified'] == 431 and e['verification_results']['success']
assert all(digest(committed(n)) == h for n, h in e['sources'].items())
root = Q / 'computable-metadata-repair-root'
runs = read(root / 'runs.json')
assert len(runs) == 7 and all(r['exit_code'] == 0 for r in runs)
counts = {}
for step, expected in [('default-all-targets', (798, 1271)), ('all-features-all-targets', (901, 1447))]:
    s = (root / ('candidate-' + step + '.log')).read_text()
    counts[step] = {'passed_test_executions_including_children': sum(map(int, re.findall(r'test result: ok\. (\d+) passed', s))),
                    'benchmark_fixture_replays': len(re.findall(r'^Success$', s, re.M))}
    assert tuple(counts[step].values()) == expected
assert all(digest(committed(n)) == h for n, h in read(root / 'inputs.json')['overlays'].items())
fixed = Q / 'computable-metadata-repair-probe'
fixed_inputs = read(fixed / 'observations/inputs.json')
assert all(digest(committed(n)) == h for n, h in fixed_inputs['candidate_overlays'].items())
fixed_runs = read(fixed / 'observations/runs.json')
assert len(fixed_runs) == 16 and all(r['exit_code'] == 0 for r in fixed_runs)

names = ['computable-metadata-boundary-probe', 'computable-product-boundary-probe',
         'metadata-invariant-probe', 'computable-metadata-repair-probe',
         'computable-metadata-repair-focused', 'computable-metadata-repair-root']
files = []
for name in names:
    folder = Q / name
    files += [(p, str(p.relative_to(Q))) for p in folder.rglob('*') if p.is_file()]
    restoration = folder / 'restoration.json'
    if not restoration.exists():
        restoration = folder / 'observations/restoration.json'
    assert read(restoration)['clean']
for name in ['computable-metadata-boundary-probe', 'computable-product-boundary-probe', 'computable-metadata-repair-probe']:
    folder = Q / name
    assert all(digest((folder / n).read_bytes()) == h for n, h in read(folder / 'observations/inputs.json')['files'].items())
previous = read(Q / 'computable-metadata-boundary-probe/observations/runs.json')
assert len(previous) == 32
assert sum(r['exit_code'] != 0 for r in previous if r['label'] == 'baseline') == 8
assert sum(r['exit_code'] != 0 for r in previous if r['label'] == 'candidate') == 3
product = read(Q / 'computable-product-boundary-probe/observations/runs.json')
assert len(product) == 12 and all(r['exit_code'] == 0 for r in product)
internal = read(Q / 'metadata-invariant-probe/runs.json')
assert [r['exit_code'] for r in internal] == [101, 101, 101, 101, 0, 0]

comment_differences = []
for folder in [Q / 'metadata-invariant-probe', Q / 'computable-metadata-repair-focused']:
    for name, h in read(folder / 'inputs.json')['overlays'].items():
        if digest(committed(name)) == h:
            continue
        before = (folder / 'overlay' / name).read_text()
        after = committed(name).decode()
        # The only differences are complete comment lines; do not normalize code.
        strip = lambda s: '\n'.join(line for line in s.splitlines() if not line.lstrip().startswith('//'))
        assert strip(before) == strip(after), (folder, name)
        comment_differences.append({'folder': folder.name, 'source': name, 'original_sha256': h,
            'committed_sha256': digest(committed(name)),
            'diff': ''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True)))})
assert len(comment_differences) == 4

for name in ['evidence.json', 'verus.json', 'verus.stderr']:
    files.append((R / 'target/verification' / name, 'official/' + name))
files.append((Q / 'computable-metadata-proof.log', 'official/driver.log'))
drivers = ['preserve_computable_metadata.py', 'qualify_computable_metadata_root.py',
           'qualify_computable_metadata_patch.py', 'probe_computable_metadata.py',
           'probe_computable_product.py', 'probe_metadata_invariant.py', 'probe_repaired_computable_metadata.py']
files += [(Q / n, 'drivers/' + n) for n in drivers]
for name in read(root / 'inputs.json')['overlays']:
    files.append((R / name, 'committed/' + name))
archive = D / '2026-09-17-verus-computable-metadata.tar.gz'
with archive.open('wb') as raw:
    with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w') as tar:
            for p, name in sorted(files, key=lambda x: x[1]):
                data = p.read_bytes(); info = tarfile.TarInfo(name)
                info.size = len(data); info.mode = 0o644
                tar.addfile(info, io.BytesIO(data))
report = {
    'schema': 1, 'status': 'metadata_exactness_repair_qualification_in_progress',
    'baseline': 'a2da8e2b5de9a1a4653d3662f2f05cb6533fd7ef', 'candidate': revision,
    'verification': {'units': 431, 'executable_contracts': 56, 'model_theorems': 87,
        'source_hashes': len(e['sources']), 'source_hashes_match_commit': True,
        'entire_proof_target': True, 'no_cheating': True, 'open_obligation_groups': 13},
    'negative_guards': {'status': 'unchanged kernels and model inputs; no fresh mutation replay',
        'evidence': 'benchmarks/checkpoints/2026-09-17-verus-real-approximation-model.json'},
    'counterexamples': {
        'public_original': previous,
        'private_bound_constructor': internal,
        'public_product_zero_status_control': product,
        'public_repaired': fixed_runs,
        'findings': [
            'Both the fixed baseline and previous runtime panic in debug for integer 2^i32::MAX metadata. Both falsely certify exact i32::MIN for 2^(i32::MAX+1).',
            'For the actual private rational-bound constructor with 1/2^(i32::MAX+2), the baseline reports a wrong exact positive exponent, and the previous runtime returns Zero. The repair preserves nonzero sign with an unavailable exponent.',
            'Public direct rational and rational-times-pi zero-status queries did not reproduce the private false-zero bug. The product control checks zero status only, not approximation or inexact magnitude accuracy.',
            'All seven public cases pass in debug and release on the exact committed repair.'
        ]},
    'root_correctness': counts, 'root_validation': runs,
    'focused_validation': read(Q / 'computable-metadata-repair-focused/runs.json'),
    'preliminary_comment_only_differences': comment_differences,
    'binding_notes': [
        'Full root, public repair probe and official proof hashes match the committed runtime.',
        'Private diagnostic and focused checks used an earlier overlay with identical code and two different comments. Exact differences and original hashes are retained.',
        'Historical failures and unsuccessful zero-status hypotheses remain in the archive; they are not passes or omitted results.'
    ],
    'limits': [
        'The existing checked bit-length helper is verified. BoundInfo and production callers are not yet formally covered; 13 complete-implementation groups remain open.',
        'Unrepresentable cached magnitudes now fail explicitly rather than wrap. This does not establish support for every precision in every approximation kernel.',
        'Remaining build, coverage, fuzz, resource, timing and pinned-consumer qualification for this runtime is pending. No final baseline acceptance is claimed.'
    ],
    'artifact': {'path': str(archive.relative_to(R)), 'bytes': archive.stat().st_size,
        'files': len(files), 'sha256': digest(archive.read_bytes())}
}
(D / '2026-09-17-verus-computable-metadata.json').write_text(json.dumps(report, indent=2) + '\n')
print(report['artifact'])
print(counts)
