#!/usr/bin/env python3
"""Exercise the actual private bound constructor; preserve baseline and candidate defects."""
import hashlib,json,os,subprocess,time
from pathlib import Path
Q=Path(__file__).resolve().parent;R=Path('/home/tim/Documents/GitHub/workspace/hyperreal');S=Q/'fuzz-source';O=Q/'metadata-invariant-probe';O.mkdir()
C=json.loads((Q/'run.json').read_text());base='7b95cac24091482cc3c01355fcc3de6cfa8a13a3'
E=C['environment']|{'CARGO_TARGET_DIR':str(Q/'kernel-target'),'CARGO_NET_OFFLINE':'true','CARGO_BUILD_JOBS':'2','CCACHE_DISABLE':'1'}
assert not subprocess.check_output(['git','status','--porcelain'],cwd=S,text=True);original=subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()
files=sorted(set(subprocess.check_output(['git','diff','--name-only',base,'--','src'],cwd=R,text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard','src'],cwd=R,text=True).splitlines()))
patch={n:(R/n).read_bytes() for n in files};records=[]
harness='''
#[cfg(test)]
mod metadata_bound_invariant_probe {
    use super::*;
    #[test]
    fn nonzero_rational_bound_keeps_its_sign_outside_the_exponent_range() {
        let denominator = BigUint::from(1_u8) << (i32::MAX as u64 + 2);
        let value = Rational::from_bigint_fraction(BigInt::from(1), denominator).unwrap();
        let bound = BoundInfo::from_rational(&value);
        println!("bound={bound:?}");
        assert_eq!(bound.known_sign(), Some(Sign::Plus));
        assert_eq!(bound.magnitude_bits(), None);
        assert_eq!(bound.known_msd(), None);
        assert_eq!(bound.planning_msd(), None);
    }
}
'''
(O/'harness.rs').write_text(harness)
(O/'inputs.json').write_text(json.dumps({'baseline':C['baseline'],'previous_candidate':base,'patched_parent':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'overlays':{n:hashlib.sha256(b).hexdigest() for n,b in patch.items()},'harness_sha256':hashlib.sha256(harness.encode()).hexdigest(),'environment':E,'native_timing':False,'status':'diagnostic_not_qualification'},indent=2)+'\n')
for n,b in patch.items():p=O/'overlay'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
def restore():
 for n in set(files)|{'src/computable/node.rs'}:
  tracked=subprocess.run(['git','ls-files','--error-unmatch',n],cwd=S,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0
  if tracked:subprocess.run(['git','restore','--',n],cwd=S,check=True)
  elif (S/n).exists():(S/n).unlink()
try:
 for label,revision in [('baseline',C['baseline']),('previous_candidate',base),('patched_candidate',base)]:
  subprocess.run(['git','checkout','--detach',revision],cwd=S,check=True)
  if label=='patched_candidate':
   for n,b in patch.items():(S/n).write_bytes(b)
  p=S/'src/computable/node.rs';p.write_text(p.read_text()+harness)
  for profile,args in [('debug',[]),('release',['--release'])]:
   command=['timeout','--signal=TERM','--kill-after=10s','180s','cargo','test','--locked','--lib',*args,'metadata_bound_invariant_probe','--','--nocapture'];started=time.time()
   with (O/(label+'-'+profile+'.log')).open('w') as log:r=subprocess.run(command,cwd=S,env=os.environ|E,stdout=log,stderr=subprocess.STDOUT)
   records.append({'label':label,'revision':revision,'profile':profile,'command':command,'cwd':str(S),'exit_code':r.returncode,'seconds':time.time()-started});(O/'runs.json').write_text(json.dumps(records,indent=2)+'\n');print(label,profile,r.returncode,round(time.time()-started,1),flush=True)
  restore()
finally:
 restore();subprocess.run(['git','checkout','--detach',original],cwd=S,check=True);assert not subprocess.check_output(['git','status','--porcelain'],cwd=S,text=True);(O/'restoration.json').write_text(json.dumps({'clean':True,'revision':original},indent=2)+'\n')
