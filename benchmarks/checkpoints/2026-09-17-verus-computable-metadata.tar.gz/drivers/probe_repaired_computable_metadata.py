#!/usr/bin/env python3
"""Observe cold-process precision boundaries; failures remain counterexamples."""
import hashlib,json,os,subprocess,time
from pathlib import Path
Q=Path(__file__).resolve().parent;SOURCE=Q/'fuzz-source';PROBE=Q/'computable-metadata-repair-probe';OUT=PROBE/'observations'
CONFIG=json.loads((Q/'run.json').read_text());REVISIONS={'candidate':'7b95cac24091482cc3c01355fcc3de6cfa8a13a3'}
ENV=CONFIG['environment']|{'CARGO_TARGET_DIR':str(Q/'boundary-target'),'CARGO_NET_OFFLINE':'true','CARGO_BUILD_JOBS':'2','CCACHE_DISABLE':'1'}
ROOT=Path('/home/tim/Documents/GitHub/workspace/hyperreal')
files=subprocess.check_output(['git','diff','--name-only',REVISIONS['candidate'],'--','src'],cwd=ROOT,text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard','src'],cwd=ROOT,text=True).splitlines()
overlays={n:(ROOT/n).read_bytes() for n in files}
original=subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip();assert not subprocess.check_output(['git','status','--porcelain'],cwd=SOURCE,text=True)
OUT.mkdir();records=[]
inputs={p:hashlib.sha256((PROBE/p).read_bytes()).hexdigest() for p in ['Cargo.toml','Cargo.lock','src/main.rs']}
(OUT/'inputs.json').write_text(json.dumps({'revisions':REVISIONS,'files':inputs,'candidate_overlays':{n:hashlib.sha256(b).hexdigest() for n,b in overlays.items()},'compiler':CONFIG['compiler'],'environment':ENV,'status':'diagnostic_not_qualification','native_timing':False},indent=2)+'\n')
try:
 for label,revision in REVISIONS.items():
  subprocess.run(['git','checkout','--detach',revision],cwd=SOURCE,check=True)
  if label=='candidate':
   for n,b in overlays.items():
    (SOURCE/n).parent.mkdir(parents=True,exist_ok=True);(SOURCE/n).write_bytes(b)
    path=OUT/'overlay'/n;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(b)
  for profile in ['debug','release']:
   folder=OUT/label/profile;folder.mkdir(parents=True)
   command=['cargo','build','--locked','--offline']+(['--release'] if profile=='release' else [])
   started=time.time()
   with (folder/'build.log').open('w') as log:r=subprocess.run(command,cwd=PROBE,env=os.environ|ENV,stdout=log,stderr=subprocess.STDOUT)
   records.append({'label':label,'revision':revision,'profile':profile,'case':'build','command':command,'cwd':str(PROBE),'exit_code':r.returncode,'seconds':time.time()-started});(OUT/'runs.json').write_text(json.dumps(records,indent=2)+'\n');print(label,profile,'build',r.returncode,flush=True)
   if r.returncode:continue
   binary=Q/'boundary-target'/profile/'hyperreal-computable-metadata-repair-probe';checksum=hashlib.sha256(binary.read_bytes()).hexdigest()
   for case in ['zero','one','integer-max','integer-above','ratio-min','ratio-below','negative-ratio-below']:
    command=['timeout','--signal=TERM','--kill-after=10s','60s',str(binary),case];started=time.time()
    with (folder/(case+'.stdout')).open('w') as stdout,(folder/(case+'.stderr')).open('w') as stderr:r=subprocess.run(command,cwd=PROBE,env=os.environ|ENV,stdout=stdout,stderr=stderr)
    records.append({'label':label,'revision':revision,'profile':profile,'case':case,'command':command,'cwd':str(PROBE),'exit_code':r.returncode,'seconds':time.time()-started,'binary_sha256':checksum,'native_timing':False});(OUT/'runs.json').write_text(json.dumps(records,indent=2)+'\n');print(label,profile,case,r.returncode,flush=True)
finally:
 for n in overlays:
  tracked=subprocess.run(['git','ls-files','--error-unmatch',n],cwd=SOURCE,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0
  if tracked:subprocess.run(['git','restore','--',n],cwd=SOURCE,check=True)
  elif (SOURCE/n).exists():(SOURCE/n).unlink()
 subprocess.run(['git','checkout','--detach',original],cwd=SOURCE,check=True)
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=SOURCE,text=True)
 assert all(hashlib.sha256((PROBE/p).read_bytes()).hexdigest()==h for p,h in inputs.items())
 (OUT/'restoration.json').write_text(json.dumps({'revision':original,'clean':True},indent=2)+'\n')
print('Diagnostic observations complete; inspect failures. This is not qualification.',flush=True)
