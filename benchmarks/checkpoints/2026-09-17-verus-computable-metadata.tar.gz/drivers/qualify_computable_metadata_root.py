#!/usr/bin/env python3
"""Run baseline regression probes and the repair's root correctness matrix."""
import hashlib,json,os,subprocess,time
from pathlib import Path
Q=Path(__file__).resolve().parent;R=Path('/home/tim/Documents/GitHub/workspace/hyperreal');S=Q/'source';O=Q/'computable-metadata-repair-root';O.mkdir()
C=json.loads((Q/'run.json').read_text());E=C['environment']|{'CARGO_TARGET_DIR':str(Q/'target'),'CARGO_BUILD_JOBS':'4','CARGO_NET_OFFLINE':'true','CCACHE_DISABLE':'1'}
original=subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip();assert not subprocess.check_output(['git','status','--porcelain'],cwd=S,text=True)
base='7b95cac24091482cc3c01355fcc3de6cfa8a13a3'
files=sorted(set(subprocess.check_output(['git','diff','--name-only',base,'--','src','tests'],cwd=R,text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard','src','tests'],cwd=R,text=True).splitlines()))
contents={n:(R/n).read_bytes() for n in files};records=[]
(O/'inputs.json').write_text(json.dumps({'baseline':C['baseline'],'candidate_parent':base,'root_parent':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'overlays':{n:hashlib.sha256(b).hexdigest() for n,b in contents.items()},'compiler':C['compiler'],'environment':E},indent=2)+'\n')
for n,b in contents.items():
 p=O/'overlay'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
def run(label,step,command):
 start=time.time()
 with (O/(label+'-'+step+'.log')).open('w') as log:r=subprocess.run(command,cwd=S,env=os.environ|E,stdout=log,stderr=subprocess.STDOUT)
 records.append({'label':label,'step':step,'command':command,'cwd':str(S),'exit_code':r.returncode,'seconds':time.time()-start})
 (O/'runs.json').write_text(json.dumps(records,indent=2)+'\n');print(label,step,r.returncode,round(time.time()-start,1),flush=True)
 return r.returncode
def restore_files():
 for n in contents:
  tracked=subprocess.run(['git','ls-files','--error-unmatch',n],cwd=S,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0
  if tracked:subprocess.run(['git','restore','--',n],cwd=S,check=True)
  elif (S/n).exists():(S/n).unlink()
try:
 subprocess.run(['git','checkout','--detach',base],cwd=S,check=True)
 for n,b in contents.items():(S/n).write_bytes(b)
 for path in list((R/'src').rglob('*.rs'))+list((R/'tests').rglob('*.rs')):assert path.read_bytes()==(S/path.relative_to(R)).read_bytes(),path
 for step,command in [
  ('default-all-targets',['cargo','test','--locked','--all-targets','--no-fail-fast']),
  ('all-features-all-targets',['cargo','test','--locked','--all-features','--all-targets','--no-fail-fast']),
  ('representations',['bash','scripts/representation_coverage.sh']),
  ('clippy-default',['cargo','clippy','--locked','--all-targets','--','-D','warnings']),
  ('clippy-all',['cargo','clippy','--locked','--all-features','--all-targets','--','-D','warnings']),
  ('doc-default',['cargo','test','--locked','--doc']),
  ('doc-all',['cargo','test','--locked','--all-features','--doc']),
 ]:
  if run('candidate',step,command):raise RuntimeError('Candidate correctness step failed')
finally:
 restore_files();subprocess.run(['git','checkout','--detach',original],cwd=S,check=True)
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=S,text=True)
 (O/'restoration.json').write_text(json.dumps({'clean':True,'revision':original},indent=2)+'\n')
