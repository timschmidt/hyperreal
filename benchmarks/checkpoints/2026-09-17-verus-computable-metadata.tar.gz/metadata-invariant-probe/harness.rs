
#[cfg(test)]
mod metadata_bound_invariant_probe {
    use super::*;
    #[test]
    fn nonzero_rational_bound_keeps_its_sign_outside_the_exponent_range() {
        let denominator = BigUint::from(1_u8) << (i32::MAX as u64 + 2);
        let value = Rational::from_bigint_fraction(BigInt::from(1), denominator).unwrap();
        let bound = BoundInfo::from_rational(&value);
        println!("bound={bound:?}");
        assert_eq!(bound.known_sign(), Some(Sign::Plus));
        assert_eq!(bound.magnitude_bits(), None);
        assert_eq!(bound.known_msd(), None);
        assert_eq!(bound.planning_msd(), None);
    }
}
