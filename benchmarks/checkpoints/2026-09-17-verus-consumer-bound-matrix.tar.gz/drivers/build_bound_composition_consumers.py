#!/usr/bin/env python3
"""Qualify current native consumer builds and bounded complete release suites.

Only pinned temporary worktrees are used. Hypercurve's full release suite and
its known long-running cases are explicitly pending separate qualification.
Every non-tracing benchmark target is built; no timings are performed here.
"""
import hashlib,json,os,shutil,subprocess,time
from pathlib import Path
Q=Path(__file__).resolve().parent
CONFIG=json.loads((Q/'run.json').read_text());PINS=json.loads((Q/'consumers.json').read_text())
REVISION=subprocess.check_output(['git','rev-parse','c61d6d876d30be92faa038d1ad9fe657e241fe0c'],cwd=Q/'consumer-source',text=True).strip();SOURCE=Q/'consumer-source';OUT=Q/'bound-composition-consumers'
FEATURES={'hyperlattice':[], 'hyperlimit':[], 'hypertri':['all-algorithms,runtime-select,f64-interop'], 'hypersolve':[], 'hypercurve':['triangulation,svg,hershey,comparative-benchmarks'], 'hypermesh':[]}
ENV=CONFIG['environment']|{'CARGO_TARGET_DIR':str(Q/'consumer-target'),'CARGO_NET_OFFLINE':'true','CARGO_BUILD_JOBS':'4','CCACHE_DISABLE':'1',**{name.upper()+'_SKIP_BENCHMARK_REPORTS':'1' for name in FEATURES}}

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def inventory(root):
 paths=[p for p in subprocess.check_output(['git','ls-files','-z'],cwd=root).decode().split('\0') if p and not p.startswith('benchmarks/checkpoints/')]
 for extra in ['fuzz/Cargo.lock']:
  if (root/extra).is_file() and extra not in paths:paths.append(extra)
 return {p:digest(root/p) for p in paths if (root/p).is_file()}
def main():
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=SOURCE,text=True)
 original=subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip();OUT.mkdir()
 inputs={'runtime_revision':REVISION,'baseline':CONFIG['baseline'],'compiler':CONFIG['compiler'],'environment':ENV,'consumers':{}}
 for name,meta in PINS.items():
  root=Q/name
  assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==meta['revision']
  assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)
  inputs['consumers'][name]={'revision':meta['revision'],'files':inventory(root)}
 records=[]
 try:
  subprocess.run(['git','checkout','--detach',REVISION],cwd=SOURCE,check=True)
  inputs['hyperreal_files']=inventory(SOURCE);(OUT/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
  jobs=[]
  for name,features in FEATURES.items():
   command=['cargo','bench','--locked','--benches','--no-run','--message-format=json']
   if features:command+=['--features',features[0]]
   jobs.append((name,'bench-build',command,900))
  for name in FEATURES:
   if name!='hypercurve':
    jobs.append((name,'tests-all',['cargo','test','--locked','--release','--all-features','--no-fail-fast','--','--test-threads=2'],900))
  for name,step,command,timeout in jobs:
   folder=OUT/'candidate'/name;folder.mkdir(parents=True,exist_ok=True)
   actual=['timeout','--signal=TERM','--kill-after=10s',str(timeout)+'s',*command]
   started=time.time()
   with (folder/(step+'.stdout')).open('w') as stdout,(folder/(step+'.stderr')).open('w') as stderr:
    r=subprocess.run(actual,cwd=Q/name,env=os.environ|ENV,stdout=stdout,stderr=stderr)
   record={'consumer':name,'consumer_revision':PINS[name]['revision'],'hyperreal_revision':REVISION,'step':step,'command':actual,'cwd':str(Q/name),'environment':ENV,'exit_code':r.returncode,'seconds':time.time()-started,'native_timing':False}
   if step=='bench-build' and r.returncode==0:
    binaries={};(folder/'bin').mkdir()
    for a in map(json.loads,(folder/(step+'.stdout')).read_text().splitlines()):
     if a.get('reason')!='compiler-artifact' or not a.get('executable') or a['target']['kind']!=['bench']:continue
     source=Path(a['executable']);target=folder/'bin'/a['target']['name'];shutil.copy2(source,target)
     binaries[target.name]={'sha256':digest(target),'bytes':target.stat().st_size,'features':a['features'],'target':a['target']}
    baseline=json.loads((Q/'baseline/consumers'/name/'binaries.json').read_text())
    assert binaries.keys()==baseline.keys(),(name,list(binaries),list(baseline))
    assert all(sorted(meta['features'])==sorted(baseline[suite]['features']) for suite,meta in binaries.items())
    (folder/'binaries.json').write_text(json.dumps(binaries,indent=2)+'\n');record['benchmark_targets']=len(binaries)
   records.append(record);(OUT/'runs.json').write_text(json.dumps(records,indent=2)+'\n');print(name,step,r.returncode,round(record['seconds'],1),flush=True)
  (OUT/'pending.json').write_text(json.dumps({'not_acceptance':True,'pending':['Hypercurve complete release suite and known long-running cases','Consumer core feature/UI/fuzz/Clippy/documentation/representation/allocation checks forcurrentruntime','Deep consumer coverage and powerset matrices','Original andfixed-inputnativeconsumerbenchmarks']},indent=2)+'\n')
 finally:
  for name,meta in inputs['consumers'].items():
   assert all(digest(Q/name/p)==h for p,h in meta['files'].items()),name
   assert not subprocess.check_output(['git','status','--porcelain'],cwd=Q/name,text=True)
  subprocess.run(['git','checkout','--detach',original],cwd=SOURCE,check=True)
  assert not subprocess.check_output(['git','status','--porcelain'],cwd=SOURCE,text=True)
  (OUT/'restoration.json').write_text(json.dumps({'hyperreal_revision':original,'all_pinned_consumers_clean':True},indent=2)+'\n')
 raise SystemExit(any(r['exit_code'] for r in records))
if __name__=='__main__':main()
