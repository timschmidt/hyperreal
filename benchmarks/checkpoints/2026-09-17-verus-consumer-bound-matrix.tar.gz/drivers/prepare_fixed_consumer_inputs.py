#!/usr/bin/env python3
"""Prepare, without applying, matched benchmark-only consumer overlays.

The original adaptive benchmarks remain available. The comparison branch
replays exactly the checked-in 100 cases, in their stored order, on both builds.
No production source or live consumer checkout is changed by this script.
"""
import difflib
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tomllib

Q = Path(__file__).resolve().parent
OUT = Q / 'consumer-fixed-inputs'
OUT.mkdir(exist_ok=True)
ENVIRONMENT = 'HYPERREAL_BASELINE_FREEZE_PROMOTED'
BEFORE = '''    let current = retained_fuzz::collect_cases(CONFIG, &targets, run_case);
    let refresh = retained_fuzz::refresh(CONFIG, &targets, &current, run_case);'''
AFTER = '''    let refresh = if std::env::var_os("HYPERREAL_BASELINE_FREEZE_PROMOTED").is_some() {
        retained_fuzz::frozen_promoted(&targets)
    } else {
        let current = retained_fuzz::collect_cases(CONFIG, &targets, run_case);
        retained_fuzz::refresh(CONFIG, &targets, &current, run_case)
    };'''
HELPER = '''
// Benchmark-only fixed-input supplement for paired baseline qualification.
// The normal adaptive benchmark remains reachable with the switch unset.
pub fn frozen_promoted(targets: &[String]) -> Refresh {
    let path = PathBuf::from(env!("CARGO_MANIFEST_DIR")).join(PROMOTED_NAME);
    let bytes = fs::read(&path).expect("frozen promoted cases must be present");
    assert_eq!(&bytes[..], &include_bytes!("../../promoted_slow_offenders.txt")[..]);
    let promoted = read_promoted_cases(&path, targets);
    assert_eq!(promoted.len(), PROMOTED_TARGET, "every frozen row must parse");
    let unique: BTreeSet<_> = promoted.iter().map(|case| (&case.target, case.seed)).collect();
    assert_eq!(unique.len(), PROMOTED_TARGET, "frozen cases must be unique");
    Refresh { promoted }
}
'''
manifest = {'status': 'prepared_unbuilt_unrun', 'switch': {ENVIRONMENT: '1'},
            'purpose': 'Same retained inputs and ordering on both builds; no timing-based promotion or rotation.',
            'limits': ['Benchmark-only supplement; original adaptive results do not establish matched-input parity.',
                       'Build and replay this overlay on both revisions before treating it as evidence.'],
            'consumers': {}}
for name in ['hyperlattice', 'hyperlimit', 'hypertri', 'hypersolve']:
    root = Q / name
    paths = ['benches/retained_fuzz.rs', 'benches/support/retained_fuzz.rs']
    originals = {path: (root / path).read_text() for path in paths}
    assert originals[paths[0]].count(BEFORE) == 1
    assert 'frozen_promoted' not in originals[paths[1]]
    snapshot = (root / 'promoted_slow_offenders.txt').read_bytes()
    target_names = {entry['name'] for entry in tomllib.loads((root / 'fuzz/Cargo.toml').read_text())['bin']}
    rows = []
    for line in snapshot.decode().splitlines():
        if not line.strip() or line.lstrip().startswith('#'):
            continue
        target, seed, nanos, criterion_name = line.split('\t')
        assert target in target_names
        match = re.fullmatch(r'seed\[(\d+)\]', seed)
        assert match, line
        seed = int(match[1]); nanos = int(nanos)
        assert 0 <= seed <= 2**64 - 1 and 0 <= nanos <= 2**128 - 1
        assert criterion_name == re.sub(r'[^A-Za-z0-9_]', '_', target) + '_seed_' + str(seed)
        rows.append({'target': target, 'seed': seed, 'stored_nanos': nanos, 'criterion_name': criterion_name})
    assert len(rows) == 100 and len({(r['target'], r['seed']) for r in rows}) == 100
    metadata_guard = 'if retained_fuzz::metadata_only_invocation() {'
    assert originals[paths[0]].count(metadata_guard) == 1
    # Fixed fixtures must also execute in Criterion test/list mode; normal
    # metadata behavior is unchanged when the explicit freeze switch is absent.
    fixed_guard = ('if retained_fuzz::metadata_only_invocation()\n'
                   '        && std::env::var_os("HYPERREAL_BASELINE_FREEZE_PROMOTED").is_none()\n'
                   '    {')
    updated = {paths[0]: originals[paths[0]].replace(BEFORE, AFTER).replace(metadata_guard, fixed_guard),
               paths[1]: originals[paths[1]] + HELPER}
    patch = ''.join(''.join(difflib.unified_diff(originals[path].splitlines(True), updated[path].splitlines(True),
                                             fromfile='a/' + path, tofile='b/' + path)) for path in paths)
    folder = OUT / name
    folder.mkdir(exist_ok=True)
    (folder / 'change.patch').write_text(patch)
    (folder / 'promoted_slow_offenders.txt').write_bytes(snapshot)
    (folder / 'cases.json').write_text(json.dumps(rows, indent=2) + '\n')
    files = paths + ['promoted_slow_offenders.txt', 'fuzz/Cargo.toml', 'Cargo.toml', 'Cargo.lock']
    manifest['consumers'][name] = {
        'revision': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
        'source_hashes': {path: hashlib.sha256((root / path).read_bytes()).hexdigest() for path in files},
        'overlay_hashes': {path: hashlib.sha256(updated[path].encode()).hexdigest() for path in paths},
        'patch_sha256': hashlib.sha256(patch.encode()).hexdigest(),
        'ordered_cases_sha256': hashlib.sha256((folder / 'cases.json').read_bytes()).hexdigest(),
        'cases': len(rows), 'criterion_rows': len(rows) + 1,
    }
(OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(manifest, indent=2))
