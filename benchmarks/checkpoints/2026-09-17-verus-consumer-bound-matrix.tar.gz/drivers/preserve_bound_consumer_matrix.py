#!/usr/bin/env python3
"""Preserve all completed current consumer matrices, including failures."""
import gzip,hashlib,io,json,re,tarfile
from pathlib import Path
Q=Path(__file__).resolve().parent;R=Path('/home/tim/Documents/GitHub/workspace/hyperreal');D=R/'benchmarks/checkpoints';O=Q/'bound-composition-consumers';F=Q/'bound-composition-consumer-fixed-builds'
def read(p):return json.loads(p.read_text())
inputs=read(O/'inputs.json');builds=read(O/'runs.json');core=read(O/'core-validation.json');deep=read(O/'deep-validation.json');traces=read(O/'traces-validation.json');fixed=read(F/'runs.json')
assert len(builds)==11 and all(r['exit_code']==0 for r in builds)
assert len(core)==51 and len(deep)==6 and len(traces)==5 and all(r['exit_code']==0 for r in traces)
assert len(fixed)==8 and all(r['exit_code']==0 and not r.get('validation_error') for r in fixed)
assert sum(r.get('benchmark_targets',0) for r in builds)==41
assert all(r['testing_rows']==101 for r in fixed if r['step']=='fixtures')
fixed_inputs=read(F/'inputs.json');fixed_baseline=read(Q/'magnitude-consumer-fixed-builds/inputs.json');assert fixed_inputs['overlay_manifest']==fixed_baseline['overlay_manifest'] and fixed_inputs['compiler']==fixed_baseline['compiler']
release=[]
for r in builds:
 if r['step']=='tests-all':
  matches=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', (O/'candidate'/r['consumer']/'tests-all.stdout').read_text());assert matches
  release.append({'consumer':r['consumer'],**{key:sum(int(m[i]) for m in matches) for key,i in [('passed',0),('failed',1),('ignored',2),('filtered_out',4)]}})
for step in ['powerset-check','powerset-test']:
 r=next(r for r in deep if r['step']==step);assert r['exit_code']==0 and '(256/256)' in Path(r['log']).read_text()
baseline_core=[r for r in read(Q/'metadata-consumers/core-validation.json') if r['label']=='baseline'];assert len(baseline_core)==51
baseline_deep={ (r['consumer'],r['step']):r for r in read(Q/'metadata-consumers/deep-validation.json') if r['label']=='baseline'};assert len(baseline_deep)==6
outcomes=[]
for phase,current,old in [('core',core,{(r['consumer'],r['step']):r for r in baseline_core}),('deep',deep,baseline_deep)]:
 for r in current:
  b=old[(r['consumer'],r['step'])]
  assert r['command']==b['command'] and r['consumer_revision']==b['consumer_revision']
  outcomes.append({'phase':phase,'consumer':r['consumer'],'step':r['step'],'baseline_exit':b['exit_code'],'candidate_exit':r['exit_code']})
coverage={}
for r in deep:
 if r['step']!='coverage':continue
 text=Path(r['log']).read_text();matches=re.findall(r'^TOTAL\s+(\d+)\s+(\d+)\s+(\d+)\s+([\d.]+)%$',text,re.M)
 coverage[r['consumer']]={'exit_code':r['exit_code'],'completed_production_report':bool(matches)}
 if matches:
  a=matches[-1];coverage[r['consumer']].update(lines=int(a[0]),hits=int(a[1]),misses=int(a[2]),percent=float(a[3]))
trace_rows=[]
for consumer in ['hypertri','hypersolve','hypercurve','hypermesh']:
 variants={}
 for label,root in [('baseline',Q/'metadata-consumers'),('candidate',O)]:
  text=(root/label/consumer/'traces/dispatch-trace.log').read_text();rows={}
  for m in re.finditer(r'^([^:\n]+):.*?TraceCorrelationSummary \{ ([^}]+) \}',text,re.M):rows[m[1]]={k:int(v) for k,v in re.findall(r'(\w+): (\d+)',m[2])}
  assert rows;variants[label]=rows
 assert variants['baseline'].keys()==variants['candidate'].keys()
 for case,b in variants['baseline'].items():
  c=variants['candidate'][case];assert b.keys()==c.keys();trace_rows.append({'consumer':consumer,'case':case,'baseline':b,'candidate':c,'deltas':{k:c[k]-b[k] for k in b}})
(O/'comparison.json').write_text(json.dumps({'command_outcomes':outcomes,'coverage':coverage,'trace_rows':trace_rows},indent=2)+'\n')
files=[];excluded=[]
for root in [O,F,Q/'consumer-fixed-inputs']:
 for p in root.rglob('*'):
  if not p.is_file():continue
  with p.open('rb') as f:magic=f.read(4)
  if magic in [b'\x7fELF',b'\x00asm']:excluded.append({'path':str(p.relative_to(Q)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
  else:files.append((p,str(p.relative_to(Q))))
p=Q/'bound-consumer-executables.json';p.write_text(json.dumps(excluded,indent=2)+'\n');files.append((p,p.name))
for n in ['preserve_bound_consumer_matrix.py','build_bound_composition_consumers.py','build_bound_composition_fixed_consumer_inputs.py','validate_bound_composition_consumers.py','prepare_fixed_consumer_inputs.py']:files.append((Q/n,'drivers/'+n))
archive=D/'2026-09-17-verus-consumer-bound-matrix.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as tar:
   for p,n in sorted(files,key=lambda x:x[1]):
    data=p.read_bytes();info=tarfile.TarInfo(n);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
report={'schema':1,'status':'consumer_matrix_milestone_not_acceptance','baseline':inputs['baseline'],'candidate':inputs['runtime_revision'],'pins':{n:m['revision'] for n,m in inputs['consumers'].items()},'builds':{'commands':11,'ordinary_benchmark_targets':41,'release_suites':release},'fixed_inputs':{'builds_passed':4,'replays_passed':4,'ordered_inputs':400,'criterion_rows':404,'overlay_equal_to_baseline':True},
 'core':{'commands':51,'passed':sum(r['exit_code']==0 for r in core),'failed':sum(r['exit_code']!=0 for r in core)},'deep':{'commands':deep,'powerset_checks':256,'powerset_tests':256,'coverage':coverage},'matched_outcomes':outcomes,'traces':{'commands_passed':5,'paired_rows':trace_rows,'hyperlattice_supplement':'benchmarks/checkpoints/2026-09-17-verus-consumer-bound-supplements.json'},
 'baseline_evidence':['benchmarks/checkpoints/2026-09-17-verus-consumer-metadata-core.json','benchmarks/checkpoints/2026-09-17-verus-consumer-metadata-deep.json','benchmarks/checkpoints/2026-09-17-verus-consumer-fixed-inputs.json'],
 'limits':['Original formatting, Clippy, docs, UI and coverage failures remain failures, including unlicensed Symbolica contention; no unrelated process or license file was modified.','Hypertri original coverage remains below its95percent gate; the isolated supplemental unknown-edge test is recorded separately. Hypersolve original fixture assertion still fails; its independently justified fixture supplement does not replace that record.','Hypercurve full and isolated long-case partition is still running and is not included here. Only pinned8228394 is used; live Hypercurve remains untouched.','Native performance, full implementation proof and final baseline acceptance remain pending.','Ignored and filtered release tests are not passes. Trace counts and fixture durations are not performance evidence.','Coverage report directories can contain incidental earlier consumer reports; only completed command-specific production totals support coverage counts.','Executable bytes are retained in temporary storage; hashes and build records are archived.'],
 'artifact':{'path':str(archive.relative_to(R)),'files':len(files),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}}
(D/'2026-09-17-verus-consumer-bound-matrix.json').write_text(json.dumps(report,indent=2)+'\n');print(report['artifact']);print(report['core']);print(coverage)
