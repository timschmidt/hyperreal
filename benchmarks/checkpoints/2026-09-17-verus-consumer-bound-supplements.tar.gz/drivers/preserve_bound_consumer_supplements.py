#!/usr/bin/env python3
"""Preserve completed current-source supplemental coverage and dispatch controls."""
import gzip,hashlib,io,json,re,tarfile
from pathlib import Path
Q=Path(__file__).resolve().parent;R=Path('/home/tim/Documents/GitHub/workspace/hyperreal');D=R/'benchmarks/checkpoints'
folders=['bound-composition-consumer-supplements','bound-composition-lattice-traces'];inputs=json.loads((Q/folders[0]/'inputs.json').read_text())
runs=json.loads((Q/folders[0]/'runs.json').read_text());traces=json.loads((Q/folders[1]/'runs.json').read_text())
assert len(runs)==6 and all(r['exit_code']==0 for r in runs)
assert len(traces)==4 and all(r['exit_code']==0 for r in traces)
coverage={};trace_rows={}
for label in ['baseline','candidate']:
 coverage[label]={}
 for consumer in ['hypertri','hypersolve']:
  s=(Q/folders[0]/label/consumer/'coverage.log').read_text();m=re.search(r'^TOTAL\s+(\d+)\s+(\d+)\s+(\d+)\s+([\d.]+)%$',s,re.M);assert m
  coverage[label][consumer]={'lines':int(m[1]),'hits':int(m[2]),'misses':int(m[3]),'percent':float(m[4])}
 text=(Q/folders[1]/label/'api_dispatch_trace.md').read_text()
 trace_rows[label]={m[1]:[int(x) for x in m.groups()[1:]] for m in re.finditer(r'^\| `([^`]+)` \| (\d+) \| (\d+) \| (\d+) \| (\d+) \| (\d+) \| (\d+) \| (\d+) \|$',text,re.M)}
 assert len(trace_rows[label])==4
files=[];excluded=[]
for folder in folders:
 for p in (Q/folder).rglob('*'):
  if not p.is_file():continue
  with p.open('rb') as f:magic=f.read(4)
  if magic in [b'\x7fELF',b'\x00asm']:
   excluded.append({'path':str(p.relative_to(Q)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
  else:files.append((p,str(p.relative_to(Q))))
p=Q/folders[0]/'excluded-executable-bytes.json';p.write_text(json.dumps(excluded,indent=2)+'\n');files.append((p,str(p.relative_to(Q))))
for n in ['preserve_bound_consumer_supplements.py','qualify_bound_composition_consumer_supplements.py','capture_bound_composition_lattice_traces.py','screen_bound_fixture_supplement.py']:files.append((Q/n,'drivers/'+n))
archive=D/'2026-09-17-verus-consumer-bound-supplements.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as tar:
   for p,n in sorted(files,key=lambda r:r[1]):
    data=p.read_bytes();info=tarfile.TarInfo(n);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
report={'schema':1,'status':'supplemental_qualification_not_acceptance','baseline':inputs['baseline'],'candidate':inputs['candidate'],'consumer_pins':inputs['consumer_pins'],'coverage':coverage,
 'fixture_context':'Frozen isolated diagnostics retain the sine-coordinate unknown-edge test for Hypertri and algebraically equivalent canonical-field expected payload for Hypersolve. Original sources and their failures remain recorded separately; no live consumer was changed.',
 'previous_fixture_evidence':'benchmarks/checkpoints/2026-09-17-verus-consumer-metadata-supplements.json',
 'commands':runs,'corrected_certification_benchmark':{'matched_builds_passed':2,'native_timings_pending':True},
 'lattice_trace':{'commands':traces,'rows':trace_rows,'identical_summary_counts':trace_rows['baseline']==trace_rows['candidate'],'columns':['dependency_dispatch','linear_algebra','exact_reducers','approximation','rational_temporaries','rational_reductions','rational_gcds']},
 'limits':['Full proof, native benchmarks and baseline acceptance remain incomplete.','The original unmodified consumer outcomes are not relabeled by supplemental tests.','Baseline Hypersolve hit count differs from the prior baseline invocation; no deterministic coverage improvement or regression is inferred from these single counts.','Trace counts are diagnostics, not native timings. Executables remain frozen in temporary storage with hashes archived.','Live Hypercurve remains untouched.'],
 'artifact':{'path':str(archive.relative_to(R)),'files':len(files),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}}
(D/'2026-09-17-verus-consumer-bound-supplements.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report['artifact']));print(coverage)
