#!/usr/bin/env python3
"""Retain matched supplemental fixture corrections without overwriting controls."""
import difflib
import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import tarfile
import time

Q = Path(__file__).resolve().parent
D = Q / 'consumer-diagnostics'
O = Q / 'bound-composition-consumer-supplements'
O.mkdir()
R = Path('/home/tim/Documents/GitHub/workspace/hyperreal')
C = json.loads((Q / 'run.json').read_text())
C['candidate'] = 'c61d6d876d30be92faa038d1ad9fe657e241fe0c'
E = C['environment'] | {
    'CARGO_TARGET_DIR': str(R / 'target/consumer-diagnostic-coverage-scmfudw9'),
    'CARGO_INCREMENTAL': '0', 'CARGO_PROFILE_DEV_DEBUG': '0', 'CARGO_PROFILE_TEST_DEBUG': '0',
    'CARGO_BUILD_JOBS': '4', 'CARGO_NET_OFFLINE': 'true', 'CCACHE_DISABLE': '1', 'RUST_TEST_THREADS': '2',
    **{name + '_SKIP_BENCHMARK_REPORTS': '1' for name in ['HYPERREAL','HYPERLATTICE','HYPERLIMIT','HYPERTRI','HYPERSOLVE']},
}
prior = json.loads((Q/'consumer-fixture-supplements/inputs.json').read_text())
inputs = prior['consumer_files']
for name, files in inputs.items():
    assert all(hashlib.sha256((D/name/path).read_bytes()).hexdigest()==digest for path,digest in files.items()), name
for name in ['hypersolve-fixture.patch','hypertri-uncertainty-test.patch']:
    shutil.copy2(Q/'consumer-fixture-supplements'/name, O/name)
metadata = prior | {'candidate': C['candidate'], 'environment': E}
(O/'inputs.json').write_text(json.dumps(metadata,indent=2)+'\n')
source = D/'hyperreal'
original_sources = {str(p.relative_to(source)):p.read_bytes() for p in source.rglob('*') if p.is_file()}
records = []
try:
    for label in ['baseline', 'candidate']:
        revision = C[label]
        source = D / 'hyperreal'
        shutil.rmtree(source)
        source.mkdir()
        names = subprocess.check_output(['git', 'ls-tree', '--name-only', revision], cwd=R, text=True).splitlines()
        chosen = [n for n in names if n in ['Cargo.toml','Cargo.lock','src','README.md','build.rs'] or n.startswith('LICENSE')]
        data = subprocess.check_output(['git','archive',revision,*chosen], cwd=R)
        with tarfile.open(fileobj=io.BytesIO(data)) as tar: tar.extractall(source, filter='data')
        for name in ['hypertri', 'hypersolve']:
            folder = O / label / name
            folder.mkdir(parents=True)
            command = ['timeout','--signal=TERM','--kill-after=10s','1800s','bash','scripts/coverage.sh']
            start = time.time()
            with (folder / 'coverage.log').open('w') as log:
                env = os.environ | E
                env.pop('NO_COLOR', None)
                result = subprocess.run(command,cwd=D/name,env=env,stdout=log,stderr=subprocess.STDOUT)
            records.append({'label':label,'revision':revision,'consumer':name,'step':'coverage',
                'command':command,'cwd':str(D/name),'environment':E,'exit_code':result.returncode,
                'seconds':time.time()-start})
            reports = folder / 'reports'
            reports.mkdir()
            target = Path(E['CARGO_TARGET_DIR'])
            for p in target.iterdir():
                if p.is_file() and p.suffix in ['.txt','.json','.profdata']:
                    shutil.copy2(p,reports/p.name)
            if (target/'html').exists(): shutil.copytree(target/'html',reports/'html')
            (O/'runs.json').write_text(json.dumps(records,indent=2)+'\n')
            print(label,name,'coverage',result.returncode,round(time.time()-start,1),flush=True)
        # Freeze corrected certification binaries for a separate paired native screen.
        folder = O / label / 'hypersolve'
        command = ['cargo','bench','--locked','--all-features','--bench','certification','--no-run','--message-format=json']
        build_env = os.environ | E | {'CARGO_TARGET_DIR':str(R/'target/consumer-diagnostics-scmfudw9')}
        start = time.time()
        with (folder/'build.jsonl').open('w') as output,(folder/'build.stderr').open('w') as errors:
            result = subprocess.run(command,cwd=D/'hypersolve',env=build_env,stdout=output,stderr=errors)
        records.append({'label':label,'revision':revision,'consumer':'hypersolve','step':'corrected-bench-build',
            'command':command,'cwd':str(D/'hypersolve'),'environment':E|{'CARGO_TARGET_DIR':build_env['CARGO_TARGET_DIR']},
            'exit_code':result.returncode,'seconds':time.time()-start})
        if result.returncode == 0:
            artifacts = [json.loads(line) for line in (folder/'build.jsonl').read_text().splitlines() if line.startswith('{')]
            executables = [a['executable'] for a in artifacts if a.get('reason')=='compiler-artifact'
                and a['target']['name']=='certification' and a.get('executable')]
            assert len(executables)==1
            binary=folder/'certification';shutil.copy2(executables[0],binary)
            (folder/'binary.json').write_text(json.dumps({'sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),
                'bytes':binary.stat().st_size,'source_binary':executables[0]},indent=2)+'\n')
        (O/'runs.json').write_text(json.dumps(records,indent=2)+'\n')
        print(label,'hypersolve','corrected-bench-build',result.returncode,round(time.time()-start,1),flush=True)
        for name, files in inputs.items():
            assert all(hashlib.sha256((D/name/p).read_bytes()).hexdigest()==h for p,h in files.items())
finally:
    shutil.rmtree(source); source.mkdir()
    for name,data in original_sources.items():
        p=source/name; p.parent.mkdir(parents=True,exist_ok=True); p.write_bytes(data)
    assert original_sources == {str(p.relative_to(source)):p.read_bytes() for p in source.rglob('*') if p.is_file()}
    (O/'restoration.json').write_text(json.dumps({'original_hyperreal_files_restored':True},indent=2)+'\n')
raise SystemExit(any(r['exit_code'] for r in records))
