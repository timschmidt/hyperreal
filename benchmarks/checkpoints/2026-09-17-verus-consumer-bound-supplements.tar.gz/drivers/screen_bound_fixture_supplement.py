#!/usr/bin/env python3
"""A separate paired screen of the corrected certification fixture, after builds."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

Q = Path(__file__).resolve().parent
B = Q / 'bound-composition-consumer-supplements'
O = Q / 'bound-fixture-screen'
C = json.loads((B / 'inputs.json').read_text())
runs = json.loads((B / 'runs.json').read_text())
assert len(runs) == 6 and all(r['exit_code'] == 0 for r in runs)
runtime = Q / 'bound-fixture-screen-runtime'
output = runtime / 'criterion'
E = C['environment'] | {'CRITERION_HOME': str(output), 'LC_ALL': 'C'}
O.mkdir()
runtime.mkdir()
(O / 'config.json').write_text(json.dumps({'baseline': C['baseline'], 'candidate': C['candidate'],
    'compiler': C['compiler'], 'environment': E,
    'inputs_sha256': hashlib.sha256((B / 'inputs.json').read_bytes()).hexdigest(),
    'fixture_patch_sha256': hashlib.sha256((B / 'hypersolve-fixture.patch').read_bytes()).hexdigest(),
    'limits': ['This supplements the original certification screen; it does not replace the original failed assertion.',
        'A short screen does not establish acceptance. Host frequency, temperature, ASLR and unrelated user activity are uncontrolled.',
        'Run only when all owned build, test, profiling and verification processes are idle.']}, indent=2) + '\n')
records = []
for label in ['candidate', 'baseline']:
    folder = O / label
    folder.mkdir()
    binary = B / label / 'hypersolve/certification'
    metadata = json.loads((binary.parent / 'binary.json').read_text())
    assert hashlib.sha256(binary.read_bytes()).hexdigest() == metadata['sha256']
    executable = runtime / 'certification'
    shutil.copy2(binary, executable)
    assert not output.exists()
    command = ['timeout', '--signal=TERM', '--kill-after=10s', '900s', 'taskset', '-c', '2', str(executable),
        '--bench', '--warm-up-time', '0.1', '--measurement-time', '0.2', '--sample-size', '10', '--nresamples', '10000', '--noplot']
    start = time.time()
    load = os.getloadavg()
    with (folder / 'run.log').open('w') as log:
        result = subprocess.run(command, cwd=Q / 'consumer-diagnostics/hypersolve', env=os.environ | E,
            stdout=log, stderr=subprocess.STDOUT)
    if output.exists(): output.rename(folder / 'criterion')
    records.append({'label': label, 'revision': C[label], 'command': command,
        'cwd': str(Q / 'consumer-diagnostics/hypersolve'), 'exit_code': result.returncode,
        'seconds': time.time() - start, 'start_unix': start, 'binary_sha256': metadata['sha256'],
        'load_before': load, 'load_after': os.getloadavg()})
    (O / 'runs.json').write_text(json.dumps(records, indent=2) + '\n')
    print(label, 'corrected certification screen', result.returncode, round(time.time() - start, 1), flush=True)
raise SystemExit(any(r['exit_code'] for r in records))
