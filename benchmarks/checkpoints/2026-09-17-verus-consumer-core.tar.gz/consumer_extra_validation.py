#!/usr/bin/env python3
"""Additional pinned consumer CI, representation, allocation and UI checks.

Run only after resume_consumers.py has finished. These are not native timings.
The deep phase runs the available powerset and coverage infrastructure.
"""
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

ROOT = Path(__file__).resolve().parent
CONFIG = json.loads((ROOT / 'run.json').read_text())
NAMES = ['hyperlattice', 'hyperlimit', 'hypertri', 'hypersolve', 'hypercurve', 'hypermesh']
CONTROLLED = CONFIG['environment'] | {
    'CARGO_TARGET_DIR': str(ROOT / 'consumer-target'), 'CCACHE_DISABLE': '1', 'CARGO_BUILD_JOBS': '4',
    'RUST_TEST_THREADS': '2', 'HYPERLATTICE_ALLOCATION_ITERATIONS': '16',
    'HYPERTRI_ALLOCATION_ITERATIONS': '16', 'HYPERSOLVE_ALLOCATION_ITERATIONS': '16',
    **{name.upper() + '_SKIP_BENCHMARK_REPORTS': '1' for name in NAMES},
}
parser = argparse.ArgumentParser()
parser.add_argument('phase', choices=['core', 'deep'])
parser.add_argument('--label', action='append', choices=['baseline', 'candidate'])
parser.add_argument('--target-dir', type=Path)
parser.add_argument('--no-checkout', action='store_true')
ARGS = parser.parse_args()
if ARGS.target_dir:
    CONTROLLED['CARGO_TARGET_DIR'] = str(ARGS.target_dir.resolve())
MANIFEST = ROOT / ('consumer-' + ARGS.phase + '-validation.json')
RESULTS = json.loads(MANIFEST.read_text()) if MANIFEST.exists() else []


def run(label, name, step, command, *, directory=None, environment=None, timeout=1200):
    if any(r['label'] == label and r['consumer'] == name and r['step'] == step and r['exit_code'] == 0 for r in RESULTS):
        return
    folder = ROOT / label / 'consumers' / name / ARGS.phase
    folder.mkdir(parents=True, exist_ok=True)
    controlled = CONTROLLED | (environment or {})
    cwd = ROOT / name / directory if directory else ROOT / name
    actual = ['timeout', '--signal=TERM', '--kill-after=10s', str(timeout) + 's', *command]
    started = time.time()
    with (folder / (step + '.log')).open('w') as output:
        result = subprocess.run(actual, cwd=cwd, env=os.environ | controlled, stdout=output, stderr=subprocess.STDOUT)
    RESULTS.append({'label': label, 'revision': CONFIG[label], 'consumer': name, 'step': step,
                    'command': actual, 'cwd': str(cwd), 'environment': controlled, 'exit_code': result.returncode,
                    'seconds': time.time() - started, 'log': str(folder / (step + '.log'))})
    if step == 'coverage':
        target = Path(controlled['CARGO_TARGET_DIR'])
        reports = folder / 'coverage-reports'
        reports.mkdir(exist_ok=True)
        for file in target.iterdir():
            if file.is_file() and file.suffix in ['.txt', '.json', '.profdata']:
                shutil.copy2(file, reports / file.name)
        if (target / 'html').exists():
            shutil.copytree(target / 'html', reports / 'html', dirs_exist_ok=True)
    MANIFEST.write_text(json.dumps(RESULTS, indent=2) + '\n')
    print(label, name, step, result.returncode, round(time.time() - started, 1), flush=True)


for label in ARGS.label or ['baseline', 'candidate']:
    if ARGS.no_checkout:
        current = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT / 'consumer-source', text=True).strip()
        assert current == CONFIG[label], (current, CONFIG[label])
    else:
        subprocess.run(['git', 'checkout', '--detach', CONFIG[label]], cwd=ROOT / 'consumer-source', check=True)
    if ARGS.phase == 'deep':
        for operation in ['check', 'test']:
            run(label, 'hypertri', 'powerset-' + operation,
                ['cargo', 'hack', operation, '--feature-powerset', '--exclude-features', 'all-algorithms']
                + (['--all-targets'] if operation == 'check' else []), timeout=3600)
        for name in NAMES[:4]:
            run(label, name, 'coverage', ['bash', 'scripts/coverage.sh'],
                environment={'CARGO_TARGET_DIR': str(ROOT / ('coverage-' + name))}, timeout=1800)
        continue
    for name in NAMES:
        run(label, name, 'fmt', ['cargo', 'fmt', '--all', '--', '--check'])
        run(label, name, 'clippy-all', ['cargo', 'clippy', '--locked', '--all-targets', '--all-features', '--', '-D', 'warnings'])
        run(label, name, 'docs-all', ['cargo', 'doc', '--locked', '--no-deps', '--all-features'], environment={'RUSTDOCFLAGS': '-D warnings'})
        run(label, name, 'fuzz-build', ['cargo', 'check', '--locked', '--manifest-path', 'fuzz/Cargo.toml', '--bins'])
        if name in NAMES[:4]:
            run(label, name, 'representations', ['bash', 'scripts/representation_coverage.sh'])
            if name == 'hyperlimit':
                run(label, name, 'allocation-profile', ['cargo', 'run', '--locked', '--release', '--all-features', '--example', 'allocation_profile', '--', '16'])
            else:
                run(label, name, 'allocation-profile', ['bash', 'scripts/allocation_profile.sh'])
        if name == 'hyperlattice':
            run(label, name, 'default-all-targets', ['cargo', 'test', '--locked', '--all-targets'])
            run(label, name, 'clippy-default', ['cargo', 'clippy', '--locked', '--all-targets', '--', '-D', 'warnings'])
        elif name == 'hypersolve':
            run(label, name, 'minimal-tests', ['cargo', 'test', '--locked', '--no-default-features'])
            run(label, name, 'fuzz-clippy', ['cargo', 'clippy', '--locked', '--manifest-path', 'fuzz/Cargo.toml', '--bin', 'hyperreal_representations', '--', '-D', 'warnings'])
        elif name == 'hypertri':
            run(label, name, 'algorithm-alias-tests', ['cargo', 'test', '--locked', '--no-default-features', '--features', 'all-algorithms'])
        elif name == 'hypermesh':
            run(label, name, 'default-tests', ['cargo', 'test', '--locked'])
            run(label, name, 'minimal-check', ['cargo', 'check', '--locked', '--no-default-features'])
            for target in ['native', 'wasm']:
                command = ['cargo', 'build', '--locked', '--manifest-path', 'benchmarks/size-harness/Cargo.toml', '--profile', 'size']
                if target == 'wasm':
                    command += ['--target', 'wasm32-unknown-unknown']
                run(label, name, 'size-' + target, command)
        if name in ['hypertri', 'hypercurve', 'hypermesh']:
            directory = 'examples/' + name + '_ui'
            if name == 'hypercurve':
                run(label, name, 'ui-tests', ['cargo', 'test', '--locked', '--no-fail-fast'], directory=directory)
                run(label, name, 'ui-clippy', ['cargo', 'clippy', '--locked', '--all-targets', '--', '-D', 'warnings'], directory=directory)
            else:
                run(label, name, 'ui-check', ['cargo', 'check', '--locked'], directory=directory)
            run(label, name, 'ui-wasm-build', ['cargo', 'build', '--locked', '--release', '--target', 'wasm32-unknown-unknown'], directory=directory)
            run(label, name, 'ui-trunk-build', ['trunk', 'build', '--release', '--locked'], directory=directory)

raise SystemExit(any(r['exit_code'] for r in RESULTS))
