#!/usr/bin/env python3
"""Preserve candidate sizes, retry Trunk's environment, then compare baseline CI."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

ROOT = Path(__file__).resolve().parent
CONFIG = json.loads((ROOT / 'run.json').read_text())
TARGET = ROOT / 'consumer-core-target'
MANIFEST = ROOT / 'consumer-core-supplement.json'
RECORDS = []
ENV = os.environ | CONFIG['environment'] | {
    'CARGO_TARGET_DIR': str(TARGET), 'CCACHE_DISABLE': '1', 'CARGO_BUILD_JOBS': '4',
    **{name.upper() + '_SKIP_BENCHMARK_REPORTS': '1' for name in
       ['hyperlattice', 'hyperlimit', 'hypertri', 'hypersolve', 'hypercurve', 'hypermesh']}}
ENV.pop('NO_COLOR', None)


def persist():
    MANIFEST.write_text(json.dumps(RECORDS, indent=2) + '\n')


def archive(label, phase):
    files = list((TARGET / 'wasm32-unknown-unknown/release').glob('*_ui.wasm'))
    files += list((TARGET / 'wasm32-unknown-unknown/size').glob('*.wasm'))
    files += [p for p in (TARGET / 'size').iterdir()
              if p.is_file() and not p.suffix and os.access(p, os.X_OK)]
    result = []
    for source in files:
        relative = source.relative_to(TARGET)
        destination = ROOT / label / 'consumer-size-artifacts' / phase / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
        result.append({'source': str(relative), 'artifact': str(destination),
                       'bytes': source.stat().st_size,
                       'sha256': hashlib.sha256(source.read_bytes()).hexdigest()})
    RECORDS.append({'label': label, 'revision': CONFIG[label], 'step': 'archive-' + phase,
                    'files': result})
    persist()
    print(label, 'archive-' + phase, len(result), flush=True)


def trunk(label):
    for name in ['hypertri', 'hypercurve', 'hypermesh']:
        cwd = ROOT / name / ('examples/' + name + '_ui')
        folder = ROOT / label / 'consumers' / name / 'core'
        folder.mkdir(parents=True, exist_ok=True)
        log = folder / 'ui-trunk-without-no-color.log'
        command = ['timeout', '--signal=TERM', '--kill-after=10s', '600s',
                   'trunk', 'build', '--release', '--locked']
        start = time.time()
        with log.open('w') as output:
            result = subprocess.run(command, cwd=cwd, env=ENV, stdout=output, stderr=subprocess.STDOUT)
        record = {'label': label, 'revision': CONFIG[label], 'consumer': name,
                  'step': 'ui-trunk-without-no-color', 'command': command,
                  'removed_environment_variables': ['NO_COLOR'], 'exit_code': result.returncode,
                  'seconds': time.time() - start, 'log': str(log), 'dist_files': []}
        if result.returncode == 0:
            for source in (cwd / 'dist').rglob('*'):
                if not source.is_file():
                    continue
                dest = folder / 'trunk-dist' / source.relative_to(cwd / 'dist')
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source, dest)
                record['dist_files'].append({'artifact': str(dest), 'bytes': source.stat().st_size,
                                             'sha256': hashlib.sha256(source.read_bytes()).hexdigest()})
        RECORDS.append(record)
        persist()
        print(label, name, 'ui-trunk-without-no-color', result.returncode, round(record['seconds'], 1), flush=True)


current = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT / 'consumer-source', text=True).strip()
assert current == CONFIG['candidate']
archive('candidate', 'before-trunk-retry')
trunk('candidate')
archive('candidate', 'after-trunk-retry')
command = ['python3', str(ROOT / 'consumer_extra_validation.py'), 'core', '--label', 'baseline',
           '--target-dir', str(TARGET)]
result = subprocess.run(command, cwd=ROOT)
RECORDS.append({'label': 'baseline', 'step': 'core-driver', 'command': command, 'exit_code': result.returncode})
persist()
archive('baseline', 'before-trunk-retry')
trunk('baseline')
archive('baseline', 'after-trunk-retry')
subprocess.run(['git', 'checkout', '--detach', CONFIG['candidate']], cwd=ROOT / 'consumer-source', check=True)
raise SystemExit(any(r.get('exit_code', 0) for r in RECORDS))
