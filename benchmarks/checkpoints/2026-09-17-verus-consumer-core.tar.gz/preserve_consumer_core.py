#!/usr/bin/env python3
"""Archive completed pinned consumer qualification, without asserting acceptance."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import tarfile

ROOT = Path(__file__).resolve().parent
REPO = Path('/home/tim/Documents/GitHub/workspace/hyperreal')
DEST = REPO / 'benchmarks/checkpoints'
CHECKPOINT = DEST / '2026-09-17-verus-baseline.json'
SUPPLEMENT = json.loads((ROOT / 'consumer-core-supplement.json').read_text())
assert any(r['label'] == 'baseline' and r['step'] == 'archive-after-trunk-retry' for r in SUPPLEMENT)
CORE = json.loads((ROOT / 'consumer-core-validation.json').read_text())
RELEASE = json.loads((ROOT / 'consumer-results.json').read_text()) + json.loads((ROOT / 'consumer-resumed-results.json').read_text())

# Compare artifacts built in the same paths before the auxiliary Trunk retry.
artifacts = {}
for label in ['baseline', 'candidate']:
    stage = next(r for r in SUPPLEMENT if r['label'] == label and r['step'] == 'archive-before-trunk-retry')
    artifacts[label] = {r['source']: r for r in stage['files']}
assert artifacts['baseline'].keys() == artifacts['candidate'].keys()
sizes = [{'artifact':name, 'baseline_bytes':a['bytes'], 'candidate_bytes':artifacts['candidate'][name]['bytes'],
          'delta_bytes':artifacts['candidate'][name]['bytes']-a['bytes'],
          'baseline_sha256':a['sha256'], 'candidate_sha256':artifacts['candidate'][name]['sha256']}
         for name,a in sorted(artifacts['baseline'].items())]
(ROOT / 'consumer-size-comparison.json').write_text(json.dumps(sizes,indent=2)+'\n')

files = {ROOT / name for name in [
    'run.json','consumers.json','consumer-results.json','consumer-resumed-results.json',
    'consumer-core-validation.json','consumer-core-supplement.json','consumer-allocation-comparison.json',
    'consumer-size-comparison.json','consumer-fuzz-environment-repair.json','consumer_extra_validation.py',
    'consumer_finish_core.py','resume_consumers.py','resume_consumers_v2.py','preserve_consumer_core.py']}
files.add(ROOT / 'generated-fuzz-locks/hyperlattice-Cargo.lock')
for label in ['baseline','candidate']:
    for p in (ROOT / label / 'consumers').rglob('*'):
        if p.is_file() and p.suffix in ['.log','.stdout','.stderr','.json']:
            files.add(p)
# Binary bytes remain in the temporary audit directory. Hashes, sizes, exact
# build commands and source revisions are retained here; include no stale dist.
archive = DEST / '2026-09-17-verus-consumer-core.tar.gz'
with archive.open('wb') as output:
    with gzip.GzipFile(fileobj=output,mode='wb',filename='',mtime=0) as compressed:
        with tarfile.open(fileobj=compressed,mode='w') as tar:
            for p in sorted(files):
                data = p.read_bytes()
                info = tarfile.TarInfo(str(p.relative_to(ROOT)))
                info.size = len(data); info.mode = 0o644
                tar.addfile(info,io.BytesIO(data))
artifact = {'path':str(archive.relative_to(REPO)), 'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
            'bytes':archive.stat().st_size, 'files':len(files),
            'contents':'Complete core/release logs, commands, pinned revisions, size hashes, allocation comparison, generated fuzz lock and audit drivers. Native/WASM binary payloads remain in the temporary audit directory.'}
report=json.loads(CHECKPOINT.read_text())
report['consumer_validation_in_progress']['records']=RELEASE
report['consumer_validation_in_progress']['explicit_failures_and_timeouts']=[r for r in RELEASE if r['exit_code']]
report['consumer_build_environment_repair']['baseline_retry']='Hyperlattice release benchmark build and all-feature tests passed with the isolated cache setting.'
counts=[]
for r in RELEASE:
    if r['exit_code'] or not r['step'].startswith('tests-'): continue
    matches=re.findall(r'test result: ok\. (\d+) passed; 0 failed; (\d+) ignored; \d+ measured; (\d+) filtered out;',Path(r['stdout']).read_text())
    counts.append({'label':r['label'],'consumer':r['consumer'],'step':r['step'],
                   'passed':sum(int(a) for a,b,c in matches),'ignored':sum(int(b) for a,b,c in matches),
                   'filtered_out':sum(int(c) for a,b,c in matches)})
report['completed_consumer_test_counts']=counts
report['consumer_core_validation']={
    'status':'completed_with_failures_not_acceptance', 'records':CORE, 'supplement':SUPPLEMENT,
    'artifact':artifact, 'allocation_comparison':json.loads((ROOT/'consumer-allocation-comparison.json').read_text()),
    'size_comparison':sizes,
    'findings':[
        'All six consumer release benchmark inventories built against both pinned Hyperreal revisions. Hyperlattice, Hyperlimit, Hypertri, Hypersolve and Hypermesh all-feature release tests passed on both; Hypermesh retains seven ignored cases.',
        'Pinned Hypercurve remaining-four commands timed out after 900 seconds on both variants. All four isolated unit cases timed out after 120 seconds on both. An analytic-parallel integration case failed and another stalled. This is incomplete validation, not a passing suite.',
        'Hypercurve UI tests reproduce the same two unsupported boolean-fragment failures on both revisions, with 35 passes and two failures.',
        'Hyperlattice, Hyperlimit, Hypertri and Hypersolve representation matrices pass on both. All six fuzz manifests build; the candidate Hyperlattice missing-lock/DNS failure was repaired with a frozen offline-generated lock also used for baseline.',
        'Pinned Hyperlimit formatting propagates to consumers. Hypersolve has two Clippy redundant closures and a rustdoc bare URL; Hypercurve has existing Clippy findings. The same pinned-source checks fail on both revisions.',
        'Hyperlattice default all-targets runs pass ordinary tests then abort because another unlicensed Symbolica instance is already active on the machine. No license locks or unrelated processes were modified.',
        'The inherited NO_COLOR=1 setting is invalid for Trunk. Removing only that setting makes all three consumer release web builds pass on both variants; original failures remain recorded.',
        'Allocation rows match across all 88 Hyperlattice and 11 Hyperlimit cases. Of 110 Hypertri rows, only Pow10/N-D Delaunay differs in deallocation, peak and retained counts. Hypersolve reaches 53 matching case IDs then both runs fail its retained-bytes assertion on Pow10/dense Bareiss + proof: baseline 432, candidate 288 bytes. Remaining rows were not executed. These single-run differences remain unresolved.',
        'This evidence qualifies runtime candidate 598f059 only. The later fraction-reduction runtime change in 8c74849 requires its own source-bound qualification.',
    ],
    'not_run':['Consumer feature powerset checks/tests','Consumer coverage scripts','Consumer benchmark timings and focused resource repeats']}
CHECKPOINT.write_text(json.dumps(report,indent=2)+'\n')
print('Preserved consumer core:',artifact)
for row in sizes: print(row['artifact'],row['baseline_bytes'],row['candidate_bytes'],row['delta_bytes'])
