#!/usr/bin/env python3
"""Resume incomplete consumer checks, retaining explicit long-test outcomes."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

ROOT = Path(__file__).resolve().parent
CONFIG = json.loads((ROOT / "run.json").read_text())
ENV = os.environ | CONFIG["environment"] | {
    "CARGO_TARGET_DIR": str(ROOT / "consumer-target"), "CCACHE_DISABLE": "1", "CARGO_BUILD_JOBS": "4"}
FEATURES = {"hyperlattice": [], "hyperlimit": [], "hypertri": ["all-algorithms,runtime-select,f64-interop"],
            "hypersolve": [], "hypercurve": ["triangulation,svg,hershey,comparative-benchmarks"], "hypermesh": []}
SLOW = ["bezier_offset::conversion_tests::selected_parallel_normal_circle_intersects_genuinely_analytic_parallel_in_one_fiber",
        "bezier_region::tests::independent_oblique_chord_pair_fillets_extend_on_infinite_supports",
        "bezier_region::tests::pair_native_boolean_algebraic_chord_corner_publishes_a_third_generation_fillet",
        "bezier_region::tests::selected_circle_and_analytic_parallel_extend_on_full_supports"]
MANIFEST = ROOT / "consumer-resumed-results.json"
RESULTS = json.loads(MANIFEST.read_text()) if MANIFEST.exists() else []


def run(label, name, step, command, timeout=900):
    if any(r["label"] == label and r["consumer"] == name and r["step"] == step and r["exit_code"] == 0 for r in RESULTS):
        return
    folder = ROOT / label / "consumers" / name
    folder.mkdir(parents=True, exist_ok=True)
    started = time.time()
    actual = ["timeout", "--signal=TERM", "--kill-after=10s", str(timeout) + "s", *command]
    with (folder / (step + ".stdout")).open("w") as output, (folder / (step + ".stderr")).open("w") as error:
        result = subprocess.run(actual, cwd=ROOT / name, env=ENV, stdout=output, stderr=error)
    RESULTS.append({"label": label, "hyperreal_revision": CONFIG[label], "consumer": name,
        "step": step, "command": actual, "exit_code": result.returncode,
        "seconds": time.time() - started, "stdout": str(folder / (step + ".stdout")),
        "stderr": str(folder / (step + ".stderr")), "timeout_seconds": timeout})
    (ROOT / "consumer-resumed-results.json").write_text(json.dumps(RESULTS, indent=2) + "\n")
    print(label, name, step, result.returncode, round(time.time() - started, 1), flush=True)
    if step == "bench-build-retry" and result.returncode == 0:
        (folder / "bin").mkdir(exist_ok=True)
        binaries = {}
        for line in (folder / (step + ".stdout")).read_text().splitlines():
            a = json.loads(line)
            if a.get("reason") != "compiler-artifact" or not a.get("executable") or a["target"]["kind"] != ["bench"]:
                continue
            destination = folder / "bin" / a["target"]["name"]
            shutil.copy2(a["executable"], destination)
            binaries[destination.name] = {"sha256": hashlib.sha256(destination.read_bytes()).hexdigest(),
                "features": a["features"], "target": a["target"], "bytes": destination.stat().st_size}
        (folder / "binaries.json").write_text(json.dumps(binaries, indent=2) + "\n")


for label in ["baseline", "candidate"]:
    subprocess.run(["git", "checkout", "--detach", CONFIG[label]], cwd=ROOT / "consumer-source", check=True)
    for name, features in FEATURES.items():
        if label == "baseline" and name in ["hyperlimit", "hypertri", "hypersolve"]:
            continue  # These builds and complete suites have already passed.
        if not (label == "baseline" and name == "hypercurve"):
            command = ["cargo", "bench", "--locked", "--benches", "--no-run", "--message-format=json"]
            if features:
                command += ["--features", features[0]]
            run(label, name, "bench-build-retry", command)
        command = ["cargo", "test", "--locked", "--release", "--all-features", "--no-fail-fast", "--", "--test-threads=2"]
        if name == "hypercurve":
            for case in SLOW:
                command += ["--skip", case]
        run(label, name, "tests-all-remaining-4" if name == "hypercurve" else "tests-all-retry", command)
        if name == "hypercurve":
            for index, case in enumerate(SLOW):
                command = ["cargo", "test", "--locked", "--release", "--all-features", "--lib", case,
                           "--", "--exact", "--nocapture", "--test-threads=1"]
                run(label, name, "isolated-slow-" + str(index + 1), command, timeout=120)

raise SystemExit(any(r["exit_code"] for r in RESULTS))
