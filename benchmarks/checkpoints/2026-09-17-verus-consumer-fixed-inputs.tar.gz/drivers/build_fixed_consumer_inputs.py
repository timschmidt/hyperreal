#!/usr/bin/env python3
"""Build and replay the prepared fixed-input supplement at identical source paths.

Uses only pinned temporary consumers. Restores their original files and the
consumer Hyperreal checkout even on failure. Fixture durations are not timing
comparisons. Native measurements must run later without compilation/profiling.
"""
import hashlib,json,os,shutil,subprocess,time
from pathlib import Path

Q=Path(__file__).resolve().parent
CONFIG=json.loads((Q/'run.json').read_text())
REVISIONS={'baseline':CONFIG['baseline'],'candidate':'ee773bbf4a158bbf4b09134f99dff3a3e45421d8'}
MANIFEST=json.loads((Q/'consumer-fixed-inputs/manifest.json').read_text())
OUT=Q/'magnitude-consumer-fixed-builds'
ENV=CONFIG['environment']|{'CARGO_TARGET_DIR':str(Q/'consumer-target'),'CARGO_NET_OFFLINE':'true','CARGO_BUILD_JOBS':'4','CCACHE_DISABLE':'1',**MANIFEST['switch'],**{n.upper()+'_SKIP_BENCHMARK_REPORTS':'1' for n in ['hyperlattice','hyperlimit','hypertri','hypersolve','hypercurve','hypermesh']}}
SOURCE=Q/'consumer-source'
FEATURES={'hyperlattice':[],'hyperlimit':[],'hypertri':['--features','all-algorithms,runtime-select,f64-interop'],'hypersolve':[]}

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=SOURCE,text=True)
 original_revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip()
 originals={};records=[]
 for name,meta in MANIFEST['consumers'].items():
  root=Q/name
  assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==meta['revision']
  assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)
  assert all(digest(root/p)==h for p,h in meta['source_hashes'].items())
  patch=Q/'consumer-fixed-inputs'/name/'change.patch'
  assert digest(patch)==meta['patch_sha256']
  originals[name]={p:(root/p).read_bytes() for p in meta['overlay_hashes']}
 OUT.mkdir()
 (OUT/'inputs.json').write_text(json.dumps({'revisions':REVISIONS,'compiler':CONFIG['compiler'],'environment':ENV,'overlay_manifest':MANIFEST,'native_timing':False},indent=2)+'\n')
 try:
  for name in MANIFEST['consumers']:
   root=Q/name;patch=Q/'consumer-fixed-inputs'/name/'change.patch'
   subprocess.run(['git','apply','--check',str(patch)],cwd=root,check=True)
   subprocess.run(['git','apply',str(patch)],cwd=root,check=True)
   assert all(digest(root/p)==h for p,h in MANIFEST['consumers'][name]['overlay_hashes'].items())
  for label,revision in REVISIONS.items():
   subprocess.run(['git','checkout','--detach',revision],cwd=SOURCE,check=True)
   for name in MANIFEST['consumers']:
    root=Q/name;folder=OUT/label/name;folder.mkdir(parents=True)
    command=['cargo','bench','--locked','--bench','retained_fuzz','--no-run','--message-format=json',*FEATURES[name]]
    started=time.time()
    with (folder/'build.stdout').open('w') as stdout,(folder/'build.stderr').open('w') as stderr:
     result=subprocess.run(command,cwd=root,env=os.environ|ENV,stdout=stdout,stderr=stderr)
    record={'label':label,'hyperreal_revision':revision,'consumer':name,'consumer_revision':MANIFEST['consumers'][name]['revision'],'step':'build','command':command,'cwd':str(root),'environment':ENV,'exit_code':result.returncode,'seconds':time.time()-started}
    records.append(record);(OUT/'runs.json').write_text(json.dumps(records,indent=2)+'\n');print(label,name,'build',result.returncode,flush=True)
    if result.returncode:continue
    artifacts=[a for a in map(json.loads,(folder/'build.stdout').read_text().splitlines()) if a.get('reason')=='compiler-artifact' and a.get('executable') and a['target']['kind']==['bench'] and a['target']['name']=='retained_fuzz']
    assert len(artifacts)==1
    source=Path(artifacts[0]['executable']);binary=folder/'retained_fuzz';shutil.copy2(source,binary)
    metadata={'sha256':digest(binary),'bytes':binary.stat().st_size,'features':artifacts[0]['features'],'target':artifacts[0]['target']}
    (folder/'binary.json').write_text(json.dumps(metadata,indent=2)+'\n')
    command=['timeout','--signal=TERM','--kill-after=10s','900s',str(binary),'--test']
    started=time.time()
    with (folder/'fixtures.log').open('w') as log:result=subprocess.run(command,cwd=root,env=os.environ|ENV,stdout=log,stderr=subprocess.STDOUT)
    output=(folder/'fixtures.log').read_text()
    # Criterion's test mode must execute all100 frozen cases and their score.
    count=sum(line.startswith('Testing ') for line in output.splitlines())
    record={'label':label,'hyperreal_revision':revision,'consumer':name,'step':'fixtures','command':command,'cwd':str(root),'environment':ENV,'exit_code':result.returncode,'seconds':time.time()-started,'binary_sha256':metadata['sha256'],'testing_rows':count,'expected_rows':101}
    if result.returncode==0 and count!=101:record['validation_error']='incomplete frozen fixture inventory'
    records.append(record);(OUT/'runs.json').write_text(json.dumps(records,indent=2)+'\n');print(label,name,'fixtures',result.returncode,count,flush=True)
    assert digest(root/'promoted_slow_offenders.txt')==MANIFEST['consumers'][name]['source_hashes']['promoted_slow_offenders.txt']
 finally:
  for name,files in originals.items():
   for p,data in files.items():(Q/name/p).write_bytes(data)
  subprocess.run(['git','checkout','--detach',original_revision],cwd=SOURCE,check=True)
  for name in MANIFEST['consumers']:
   assert not subprocess.check_output(['git','status','--porcelain'],cwd=Q/name,text=True)
  assert not subprocess.check_output(['git','status','--porcelain'],cwd=SOURCE,text=True)
  (OUT/'restoration.json').write_text(json.dumps({'hyperreal_revision':original_revision,'pinned_consumers_clean':True},indent=2)+'\n')
 raise SystemExit(any(r['exit_code'] or r.get('validation_error') for r in records))

if __name__=='__main__':main()
