#!/usr/bin/env python3
"""Retain current pinned builds and release-suite outcomes without overclaiming scope."""
import gzip,hashlib,io,json,re,tarfile
from pathlib import Path
Q=Path(__file__).resolve().parent;REPO=Path('/home/tim/Documents/GitHub/workspace/hyperreal');OUT=Q/'metadata-consumers';DEST=REPO/'benchmarks/checkpoints'
runs=json.loads((OUT/'runs.json').read_text());assert len(runs)==11 and all(r['exit_code']==0 for r in runs)
inputs=json.loads((OUT/'inputs.json').read_text());restoration=json.loads((OUT/'restoration.json').read_text());assert restoration['all_pinned_consumers_clean']
counts=[]
for row in runs:
 if row['step']!='tests-all':continue
 text=(OUT/'candidate'/row['consumer']/'tests-all.stdout').read_text()
 matches=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',text)
 assert matches
 counts.append({'consumer':row['consumer'],'passed':sum(int(m[0]) for m in matches),'failed':sum(int(m[1]) for m in matches),'ignored':sum(int(m[2]) for m in matches),'filtered_out':sum(int(m[4]) for m in matches)})
files=[]
for p in OUT.rglob('*'):
 if not p.is_file() or 'bin' in p.relative_to(OUT).parts:continue
 files.append((p,str(p.relative_to(OUT))))
files.extend((Q/name,'drivers/'+name) for name in ['build_metadata_consumers.py','preserve_metadata_consumer_builds.py'])
archive=DEST/'2026-09-17-verus-consumer-metadata-builds.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as zipped:
  with tarfile.open(fileobj=zipped,mode='w') as tar:
   for p,name in sorted(files,key=lambda row:row[1]):
    data=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
report={'schema':1,'status':'consumer_build_milestone_not_acceptance','baseline':inputs['baseline'],'candidate':inputs['runtime_revision'],'runs':runs,'release_suites':counts,'benchmark_targets':sum(r.get('benchmark_targets',0) for r in runs),'pinned_consumers':{name:meta['revision'] for name,meta in inputs['consumers'].items()},'restoration':restoration,
 'pending':json.loads((OUT/'pending.json').read_text())['pending'],
 'limits':['The five completed release suites retain all reported ignored tests. Ignored or pending tests are not passes.','The Hypercurve build uses pinned 8228394; its release and long-running checks remain pending. Live Hypercurve was not modified.','No native timing or whole-consumer acceptance is claimed.'],
 'artifact':{'path':str(archive.relative_to(REPO)),'bytes':archive.stat().st_size,'files':len(files),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}}
baseline_targets=sum(len(json.loads((Q/'baseline/consumers'/r['consumer']/'binaries.json').read_text())) for r in runs if r['step']=='bench-build')
assert report['benchmark_targets']==baseline_targets==41
(DEST/'2026-09-17-verus-consumer-metadata-builds.json').write_text(json.dumps(report,indent=2)+'\n');print(report['artifact']);print(counts)
