#!/usr/bin/env python3
"""Retain fresh matched consumer controls, including every failed command."""
import gzip, hashlib, io, json, subprocess, tarfile
from pathlib import Path
Q = Path(__file__).resolve().parent
R = Path('/home/tim/Documents/GitHub/workspace/hyperreal')
O = Q / 'metadata-consumers'; D = R / 'benchmarks/checkpoints'
runs = json.loads((O / 'core-validation.json').read_text())
assert len(runs) == 102
sides = {label: {(row['consumer'], row['step']): row for row in runs if row['label'] == label}
         for label in ['baseline', 'candidate']}
assert len(sides['baseline']) == len(sides['candidate']) == 51
assert sides['baseline'].keys() == sides['candidate'].keys()
for key, before in sides['baseline'].items():
    after = sides['candidate'][key]
    for name in ['command', 'environment', 'cwd', 'consumer_revision', 'removed_environment_variables']:
        assert before[name] == after[name], (key, name)
inputs = json.loads((O / 'inputs.json').read_text())
for name, metadata in inputs['consumers'].items():
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=Q/name, text=True).strip() == metadata['revision']
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=Q/name, text=True)
    assert all(hashlib.sha256((Q/name/path).read_bytes()).hexdigest() == h for path, h in metadata['files'].items())
counts = {label: {'steps': len(rows), 'passed': sum(row['exit_code'] == 0 for row in rows.values()),
                  'failed': sum(row['exit_code'] != 0 for row in rows.values())}
          for label, rows in sides.items()}
assert counts['baseline'] == {'steps': 51, 'passed': 40, 'failed': 11}
assert counts['candidate'] == {'steps': 51, 'passed': 41, 'failed': 10}
assert all(sides['baseline'][key]['exit_code'] for key, row in sides['candidate'].items() if row['exit_code'])
files = [(O / 'core-validation.json', 'core-validation.json'), (O / 'inputs.json', 'inputs.json')]
for row in runs:
    p = Path(row['log']); assert p.is_file()
    files.append((p, str(p.relative_to(O))))
for name in ['validate_metadata_consumers.py', 'finish_metadata_consumer_validation.py', 'preserve_metadata_consumer_core.py']:
    files.append((Q/name, 'drivers/' + name))
archive = D / '2026-09-17-verus-consumer-metadata-core.tar.gz'
with archive.open('wb') as raw:
    with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w') as tar:
            for p, name in sorted(files, key=lambda item: item[1]):
                data=p.read_bytes(); info=tarfile.TarInfo(name); info.size=len(data); info.mode=0o644
                tar.addfile(info, io.BytesIO(data))
report = {
    'schema': 1, 'status': 'consumer_validation_failures_remain',
    'baseline': inputs['baseline'], 'candidate': inputs['runtime_revision'],
    'fresh_runs_on_both_revisions': True, 'matched_commands_environment_cwd_and_pins': True,
    'pinned_consumer_identity_checked_at_archive': True, 'counts': counts,
    'runs': runs, 'failures': [row for row in runs if row['exit_code']],
    'findings': [
        'Every candidate failure also occurs in the fresh baseline control. Both runs remove NO_COLOR and otherwise use identical controlled environments, commands, working directories and pinned consumer sources.',
        'Both revisions fail Hyperlattice all-target execution when Symbolica refuses a second unlicensed instance. No locks or unrelated processes were changed.',
        'Both revisions retain five formatting failures, Hypersolve strict lint and documentation failures, Hypercurve strict lint failure, and two failing Hypercurve UI tests.',
        'All three UI WASM and Trunk builds pass on both revisions. Hypercurve UI Clippy also passes on both.',
        'All four candidate allocation profiles pass. Baseline Hypersolve fails its Pow10/dense Bareiss counting-epoch assertion with 432 retained bytes; the corresponding candidate row reports zero and its complete profile passes. This is a bounded allocation workload, not full process-memory acceptance.'
    ],
    'limits': [
        'Failed or ignored tests are not passes, and this checkpoint is not acceptance.',
        'The remaining validation sequence was in its deep feature phase when this checkpoint was written; coverage, dispatch traces, isolated Hypercurve release checks and native consumer timings were not yet complete.',
        'Only pinned temporary consumer worktrees were used. Live Hypercurve was untouched.',
        'Exactness, whole-crate formal proof and final performance/resource assessment remain incomplete.'
    ],
    'artifact': {'path': str(archive.relative_to(R)), 'bytes': archive.stat().st_size,
                 'files': len(files), 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()},
}
(D / '2026-09-17-verus-consumer-metadata-core.json').write_text(json.dumps(report, indent=2) + '\n')
print(counts); print(report['artifact'])
