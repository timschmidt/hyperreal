#!/usr/bin/env python3
"""Check two consumer qualification differences in isolated pinned snapshots."""
import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import tarfile
import time
from fractions import Fraction

Q = Path(__file__).resolve().parent
D = Q / 'consumer-diagnostics'
R = Path('/home/tim/Documents/GitHub/workspace/hyperreal')
CONFIG = json.loads((Q / 'run.json').read_text())
CONFIG['candidate'] = 'cdc6d3a74fd2240f8037efe218c9ea424fd4e501'
E = CONFIG['environment'] | {
    'CARGO_TARGET_DIR': str(R / 'target/consumer-diagnostics-scmfudw9'),
    'CARGO_BUILD_JOBS': '4', 'CARGO_NET_OFFLINE': 'true', 'CCACHE_DISABLE': '1',
    'CARGO_INCREMENTAL': '0', 'CARGO_PROFILE_DEV_DEBUG': '0', 'CARGO_PROFILE_TEST_DEBUG': '0',
    'HYPERREAL_SKIP_BENCHMARK_REPORTS': '1',
}
pins = json.loads((D / 'pins.json').read_text())
for name, pin in pins.items():
    for path, expected in pin['files'].items():
        assert hashlib.sha256((D / name / path).read_bytes()).hexdigest() == expected

# Use the frozen benchmark's 22 representation constructors and square inputs.
source = (D / 'hypertri/benches/representations.rs').read_text()
constructors = source[source.index('fn fraction('):source.index('fn bench_real_representations(')]
example = '''use hypertri::{Point2, PolygonInput, Rational, Real};
''' + constructors + '''
fn main() {
    println!("case,degenerate,axis_aligned,unknown");
    for (name, value) in representation_values() {
        let square = vec![
            point(&value, &value, 0, 0), point(&value, &value, 4, 0),
            point(&value, &value, 4, 4), point(&value, &value, 0, 4),
        ];
        let polygon = PolygonInput::new(square.clone(), Vec::new());
        let facts = &polygon.facts().rings[0];
        println!("{name},{},{},{}", facts.known_degenerate_edges,
            facts.known_axis_aligned_edges, facts.unknown_edge_zero_status);
        for (index, (x, y)) in [(4, 0), (0, 4), (-4, 0), (0, -4)].into_iter().enumerate() {
            let current = &square[index];
            let next = &square[(index + 1) % 4];
            assert_eq!(&next.x - &current.x, Real::from(x), "{name}: dx");
            assert_eq!(&next.y - &current.y, Real::from(y), "{name}: dy");
        }
    }
}
'''
(D / 'hypertri/examples/baseline_fixture_check.rs').write_text(example)

# (2/7 - alpha/7)(4 + 2 alpha) == 1 modulo alpha^2 == 1/2.
constant = Fraction(2, 7) * 4 + Fraction(-1, 7) * 2 * Fraction(1, 2)
linear = Fraction(2, 7) * 2 + Fraction(-1, 7) * 4
assert constant == 1 and linear == 0
(D / 'rational_identity.json').write_text(json.dumps({
    'modulus': '2 alpha^2 - 1', 'input': '1 / (4 + 2 alpha)',
    'returned': '(2 - alpha) / 7', 'fixture_expected': '(1/2) / (2 + alpha)',
    'exact_product_constant': str(constant), 'exact_product_linear': str(linear),
    'denominators_nonzero_on_interval': '2/3 < alpha < 3/4 implies 4 + 2 alpha > 0',
    'oracle': 'Python fractions.Fraction; no floating point or Hyperreal operations',
}, indent=2) + '\n')

records = []
for label in ['baseline', 'candidate']:
    revision = CONFIG[label]
    source = D / 'hyperreal'
    if source.exists(): shutil.rmtree(source)
    source.mkdir()
    names = subprocess.check_output(['git', 'ls-tree', '--name-only', revision], cwd=R, text=True).splitlines()
    chosen = [name for name in names if name in ['Cargo.toml', 'Cargo.lock', 'src', 'README.md', 'build.rs'] or name.startswith('LICENSE')]
    data = subprocess.check_output(['git', 'archive', revision, *chosen], cwd=R)
    with tarfile.open(fileobj=io.BytesIO(data)) as tar: tar.extractall(source, filter='data')
    folder = D / 'results' / label
    folder.mkdir(parents=True)
    (folder / 'source-hashes.json').write_text(json.dumps({str(p.relative_to(source)):
        hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(source.rglob('*')) if p.is_file()}, indent=2) + '\n')
    for name in ['hypertri', 'hypersolve']:
        command = ['cargo', 'run', '--locked', '--all-features', '--example', 'baseline_fixture_check']
        start = time.time()
        with (folder / (name + '.log')).open('w') as output:
            result = subprocess.run(command, cwd=D / name, env=os.environ | E, stdout=output, stderr=subprocess.STDOUT)
        records.append({'label': label, 'revision': revision, 'consumer': name, 'command': command,
            'cwd': str(D / name), 'environment': E, 'exit_code': result.returncode, 'seconds': time.time() - start,
            'example_sha256': hashlib.sha256((D / name / 'examples/baseline_fixture_check.rs').read_bytes()).hexdigest()})
        (D / 'runs.json').write_text(json.dumps(records, indent=2) + '\n')
        print(label, name, result.returncode, round(time.time() - start, 1), flush=True)
        if result.returncode: raise SystemExit(result.returncode)
