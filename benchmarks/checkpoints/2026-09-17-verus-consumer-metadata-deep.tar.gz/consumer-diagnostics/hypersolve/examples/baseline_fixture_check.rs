use hyperreal::Real;
use hypersolve::{
    AlgebraicFiberRationalReductionStatus, AlgebraicRootRepresentation,
    AlgebraicRootValidationReport, AlgebraicRootValidationStatus, BivariatePolynomial,
    CurveResultantParameter, IsolatedRootInterval, SymbolId,
    reduce_bivariate_rational_function_at_algebraic_parameter,
};

fn r(value: i64) -> Real { Real::from(value) }

fn main() {
    let root = AlgebraicRootRepresentation {
        constraint_index: 0,
        symbol: SymbolId(0),
        interval_index: 0,
        polynomial_coefficients: vec![r(-1), Real::zero(), r(2)],
        interval: IsolatedRootInterval {
            lower: (r(2) / r(3)).unwrap(),
            upper: (r(3) / r(4)).unwrap(),
            exact_root: None,
            distinct_root_count: 1,
        },
        validation: AlgebraicRootValidationReport {
            status: AlgebraicRootValidationStatus::Valid,
            message: None,
        },
    };
    let fiber = BivariatePolynomial::new(vec![vec![Real::zero(), Real::one()], vec![-Real::one()]]);
    let numerator = BivariatePolynomial::new(vec![vec![Real::one()]]);
    let denominator = BivariatePolynomial::new(vec![vec![r(4)], vec![r(2)]]);
    let report = reduce_bivariate_rational_function_at_algebraic_parameter(
        &fiber, &numerator, &denominator, CurveResultantParameter::First, &root,
        hyperlimit::PredicatePolicy::STRICT,
    );
    println!("{report:?}");
    assert_eq!(report.status, AlgebraicFiberRationalReductionStatus::ReducedToRetainedField);
    assert_eq!(report.numerator_coefficients, vec![(r(2) / r(7)).unwrap(), (r(-1) / r(7)).unwrap()]);
    assert_eq!(report.denominator_coefficients, vec![Real::one()]);
    // The independent Fraction oracle in the driver checks this rationalized
    // representation against 1 / (4 + 2 alpha), modulo 2 alpha^2 - 1.
}
