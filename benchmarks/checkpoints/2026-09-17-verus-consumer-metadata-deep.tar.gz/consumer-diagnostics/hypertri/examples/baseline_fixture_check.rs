use hypertri::{Point2, PolygonInput, Rational, Real};
use hyperreal::ZeroKnowledge;
fn fraction(numerator: i64, denominator: u64) -> Real {
    Real::new(Rational::fraction(numerator, denominator).expect("nonzero denominator"))
}

fn representation_values() -> Vec<(&'static str, Real)> {
    let pi = Real::pi();
    let e = Real::e();
    let pi_squared = &pi * &pi;
    let sqrt_two = Real::from(2).sqrt().expect("positive radicand");
    let ln_two = Real::from(2).ln().expect("positive logarithm input");
    let ln_three = Real::from(3).ln().expect("positive logarithm input");

    vec![
        ("One", fraction(3, 2)),
        ("Pi", pi.clone()),
        ("PiPow", pi_squared.clone()),
        ("PiInv", pi.clone().inverse().expect("pi is nonzero")),
        ("PiExp", &pi * &e),
        ("PiInvExp", (&e / &pi).expect("pi is nonzero")),
        ("PiSqrt", &pi * &sqrt_two),
        ("ConstProduct", &pi_squared * &e),
        ("ConstOffset", &pi - Real::from(3)),
        ("ConstProductSqrt", &(&pi_squared * &e) * &sqrt_two),
        ("Sqrt", sqrt_two),
        ("Exp", Real::from(2).exp().expect("finite exponential")),
        ("Ln", ln_three.clone()),
        (
            "LnAffine",
            (Real::from(2) * &e).ln().expect("positive logarithm input"),
        ),
        ("LnProduct", &ln_two * &ln_three),
        ("Log10", Real::from(2).log10().expect("positive input")),
        ("Log2", Real::from(3).log2().expect("positive input")),
        (
            "Pow10",
            fraction(1, 7)
                .exp10()
                .expect("finite rational base-ten power"),
        ),
        (
            "Pow2",
            fraction(1, 7)
                .exp2()
                .expect("finite rational base-two power"),
        ),
        ("SinPi", fraction(1, 5).sin_pi()),
        (
            "TanPi",
            fraction(1, 5)
                .tan_pi()
                .expect("one fifth of a turn is not a tangent pole"),
        ),
        ("Irrational", Real::one().sin()),
    ]
}

fn point(tx: &Real, ty: &Real, x: i64, y: i64) -> Point2 {
    Point2::new(tx + Real::from(x), ty + Real::from(y))
}


fn main() {
    println!("case,degenerate,axis_aligned,unknown");
    for (name, value) in representation_values() {
        let square = vec![
            point(&value, &value, 0, 0), point(&value, &value, 4, 0),
            point(&value, &value, 4, 4), point(&value, &value, 0, 4),
        ];
        let polygon = PolygonInput::new(square.clone(), Vec::new());
        let facts = &polygon.facts().rings[0];
        println!("{name},{},{},{}", facts.known_degenerate_edges,
            facts.known_axis_aligned_edges, facts.unknown_edge_zero_status);
        for (index, (x, y)) in [(4, 0), (0, 4), (-4, 0), (0, -4)].into_iter().enumerate() {
            let current = &square[index];
            let next = &square[(index + 1) % 4];
            let dx = (&next.x - &current.x).structural_facts().zero;
            let dy = (&next.y - &current.y).structural_facts().zero;
            println!("edge,{name},{index},{dx:?},{dy:?}");
            for (zero, expected) in [(dx, x), (dy, y)] {
                // Shared translation cancels mathematically. Unknown remains
                // an explicit outcome; only reported certificates are checked.
                match zero {
                    ZeroKnowledge::Zero => assert_eq!(expected, 0, "{name}: false zero"),
                    ZeroKnowledge::NonZero => assert_ne!(expected, 0, "{name}: false nonzero"),
                    ZeroKnowledge::Unknown => {},
                }
            }
        }
    }
}
