use hypertri::{Point2, PolygonInput, Real};

fn main() {
    let polygon = PolygonInput::new(vec![
        Point2::new(Real::zero(), Real::zero()),
        Point2::new(Real::one().sin(), Real::zero()),
        Point2::new(Real::from(2).sin(), Real::one()),
    ], Vec::new());
    println!("{:?}", polygon.facts());
    assert!(polygon.facts().unknown_edge_zero_status_count() > 0);
}
