#!/usr/bin/env python3
"""Retain complete powersets, coverage failures, traces and bounded diagnostics."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile

Q = Path(__file__).resolve().parent
R = Path('/home/tim/Documents/GitHub/workspace/hyperreal')
O = Q / 'metadata-consumers'
D = R / 'benchmarks/checkpoints'
inputs = json.loads((O / 'inputs.json').read_text())
deep = json.loads((O / 'deep-validation.json').read_text())
traces = json.loads((O / 'traces-validation.json').read_text())
latest = {(r['label'], r['consumer'], r['step']): r for r in deep}
assert len(deep) == 13 and len(latest) == 12
assert len(traces) == 10 and all(r['exit_code'] == 0 for r in traces)
for name, pin in inputs['consumers'].items():
    assert subprocess.check_output(['git','rev-parse','HEAD'], cwd=Q/name, text=True).strip() == pin['revision']
    assert not subprocess.check_output(['git','status','--porcelain'], cwd=Q/name, text=True)
    for path, expected in pin['files'].items():
        assert hashlib.sha256((Q/name/path).read_bytes()).hexdigest() == expected
for label in ['baseline', 'candidate']:
    for step in ['powerset-check', 'powerset-test']:
        row = latest[(label, 'hypertri', step)]
        assert row['exit_code'] == 0
        assert '(256/256)' in Path(row['log']).read_text()
    assert latest[(label, 'hyperlattice', 'coverage')]['exit_code'] == 101
    assert latest[(label, 'hypersolve', 'coverage')]['exit_code'] == 101
    assert latest[(label, 'hyperlimit', 'coverage')]['exit_code'] == 0
assert latest[('baseline','hypertri','coverage')]['exit_code'] == 0
assert latest[('candidate','hypertri','coverage')]['exit_code'] == 2
probe = Q / 'consumer-diagnostics'
diagnostics = json.loads((probe/'runs.json').read_text())
assert len(diagnostics) == 4 and all(r['exit_code']==0 for r in diagnostics)
def summaries(label):
    lines=(probe/'results'/label/'hypertri.log').read_text().splitlines()
    return {parts[0]: [int(x) for x in parts[1:]] for line in lines
            if len(parts:=line.split(',')) == 4 and all(x.isdecimal() for x in parts[1:])}
b,c = summaries('baseline'),summaries('candidate')
assert len(b)==22 and b.keys()==c.keys()
assert b['ConstProductSqrt']==[0,0,4] and c['ConstProductSqrt']==[0,4,0]
assert all(b[n]==c[n] for n in b if n!='ConstProductSqrt')
trace_rows=[]
for name in ['hypertri','hypersolve','hypercurve','hypermesh']:
    variants={}
    for label in ['baseline','candidate']:
        rows={}
        for line in (O/label/name/'traces/dispatch-trace.log').read_text().splitlines():
            if match:=re.search(r'^([^:]+):.*?TraceCorrelationSummary \{ ([^}]+) \}',line):
                row={key:int(value) for key,value in re.findall(r'(\w+): (\d+)',match[2])}
                assert match[1] not in rows
                rows[match[1]]=row
        assert rows,name
        variants[label]=rows
    assert variants['baseline'].keys()==variants['candidate'].keys()
    for case,baseline in variants['baseline'].items():
        candidate=variants['candidate'][case]
        assert baseline.keys()==candidate.keys()
        trace_rows.append({'consumer':name,'case':case,'baseline':baseline,'candidate':candidate,
            'deltas':{k:candidate[k]-baseline[k] for k in baseline}})
(O/'trace-comparison.json').write_text(json.dumps({'rows':trace_rows,
    'limits':['Trace counts are diagnostic and are not native timings or allocation-byte measurements.',
        'Hyperlattice executes four trace assertions on each revision but report suppression hides its counts; a separate report capture remains needed.']},indent=2)+'\n')
files=[]
for label in ['baseline','candidate']:
    for name in inputs['consumers']:
        for phase in ['deep','traces']:
            folder=O/label/name/phase
            if folder.exists():files += [(p,str(p.relative_to(Q))) for p in folder.rglob('*') if p.is_file()]
files += [(p,str(p.relative_to(Q))) for p in (O/'deep-quota-attempt').rglob('*') if p.is_file()]
for name in ['inputs.json','deep-validation.json','traces-validation.json','trace-comparison.json']:
    files.append((O/name,'metadata-consumers/'+name))
for folder in [probe/'results',probe/'failed-structural-equality-attempt']:
    files += [(p,str(p.relative_to(Q))) for p in folder.rglob('*') if p.is_file()]
for name in ['pins.json','runs.json','rational_identity.json','unknown-coverage-probe.log',
    'hypertri/examples/baseline_fixture_check.rs','hypertri/examples/unknown_coverage_probe.rs',
    'hypersolve/examples/baseline_fixture_check.rs']:
    files.append((probe/name,'consumer-diagnostics/'+name))
for name in ['preserve_metadata_consumer_deep.py','validate_metadata_consumers.py',
             'resume_metadata_consumer_validation.py','diagnose_metadata_consumers.py']:
    files.append((Q/name,'drivers/'+name))
archive=D/'2026-09-17-verus-consumer-metadata-deep.tar.gz'
with archive.open('wb') as raw:
    with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as compressed:
        with tarfile.open(fileobj=compressed,mode='w') as tar:
            for p,name in sorted(files,key=lambda item:item[1]):
                data=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644
                tar.addfile(info,io.BytesIO(data))
report={
    'schema':1,'status':'deep_consumer_comparison_not_acceptance',
    'baseline':inputs['baseline'],'candidate':inputs['runtime_revision'],
    'consumer_pins':{n:p['revision'] for n,p in inputs['consumers'].items()},
    'deep':{'historical_command_records':13,'latest_outcomes':12,
        'baseline':{'pass':4,'fail':2},'candidate':{'pass':3,'fail':3},
        'hypertri_feature_powersets':{'check_configurations_each':256,'test_configurations_each':256,'all_pass':True},
        'coverage':{
            'hyperlattice':'Both fail on another unlicensed Symbolica instance; no locks or unrelated processes were modified.',
            'hyperlimit':{'production_lines':10849,'baseline_hits':10797,'candidate_hits':10798},
            'hypertri':{'production_lines':6600,'baseline_hits':6271,'candidate_hits':6268,
                'required_percent':95,'candidate_gate_passed':False,
                'missing_lines':'src/types.rs:326-328 count unknown zero-status edges.',
                'diagnostic':'The frozen 22-form square probe reports four unknown edges for baseline ConstProductSqrt and four known axis-aligned edges for the candidate. The other 21 summaries agree; every reported zero/nonzero answer matches the authored translation geometry. A separate sine triangle still exercises unknown outcomes.'},
            'hypersolve':'Both fail the same certification benchmark representation assertion; partial coverage is not a completed pass.'}},
    'hypersolve_fixture':{'input':'1 / (4 + 2 alpha), alpha^2=1/2, 2/3<alpha<3/4',
        'expected':'(1/2) / (2 + alpha)','returned_both':'(2 - alpha) / 7 with denominator 1',
        'independent_oracle':'Exact Python Fraction polynomial multiplication modulo 2 alpha^2-1 proves equality.',
        'paired_diagnostic_commands_passed':2,'production_consumer_changes':False},
    'traces':{'commands_exited_zero':10,'stdout_summary_pairs':len(trace_rows),
        'hyperlattice':'Four workload trace assertions pass on each revision, but report suppression omitted the counts. Supplemental capture remains pending.'},
    'diagnostic_limit':'The first probe incorrectly used structural PartialEq as semantic equality and failed on an integer-valued computable expression. Its source, driver and log are retained. The corrected probe checks only the known zero/nonzero certificates against independent authored edge differences and records unknowns.',
    'quota_recovery':'The initial baseline powerset stopped at configuration125/256 due the51490MiB per-user tmpfs quota. Damaged isolated-checkout files and failed restoration were retained, owned idle build caches removed, the checkout repaired and the whole test powerset rerun. Coverage moved to a workspace target. No failure is relabeled a pass.',
    'limits':['Original failures remain recorded; isolated fixture supplements are running and are not included as passes here.',
        'Coverage report directories may contain incidental reports from earlier consumers because the shared target was copied. Only command-specific completed reports support the stated counts.',
        'Long Hypercurve cases and native performance comparisons remain pending. Live Hypercurve is untouched.',
        'The full proof and baseline acceptance remain incomplete.'],
    'artifact':{'path':str(archive.relative_to(R)),'files':len(files),'bytes':archive.stat().st_size,
        'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},
}
(D/'2026-09-17-verus-consumer-metadata-deep.json').write_text(json.dumps(report,indent=2)+'\n')
print(report['traces']);print(report['artifact'])
