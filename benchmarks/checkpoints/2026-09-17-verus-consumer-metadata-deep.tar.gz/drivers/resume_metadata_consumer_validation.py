#!/usr/bin/env python3
"""Run remaining non-native checks serially; retain every failing command."""
import json, subprocess, time
from pathlib import Path
Q = Path(__file__).resolve().parent
records = []
jobs = [
    ['validate_metadata_consumers.py', 'deep'],
    ['validate_metadata_consumers.py', 'traces'],
    ['qualify_metadata_hypercurve.py'],
]
for job in jobs:
    command = ['python3', str(Q / job[0]), *job[1:]]
    start = time.time()
    result = subprocess.run(command)
    records.append({'command': command, 'exit_code': result.returncode,
                    'seconds': time.time() - start})
    (Q / 'metadata-consumers/remaining-phases.json').write_text(json.dumps(records, indent=2) + '\n')
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=Q / 'consumer-source', text=True)
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=Q / 'consumer-source', text=True).strip() == '598f05944573133ae98e6c444fd9c26797ef49a2'
    print('Completed non-native validation phase:', job, 'exit', result.returncode, flush=True)
raise SystemExit(any(row['exit_code'] for row in records))
