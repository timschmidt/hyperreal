#!/usr/bin/env python3
"""Retain matched supplemental fixture corrections without overwriting controls."""
import difflib
import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import tarfile
import time

Q = Path(__file__).resolve().parent
D = Q / 'consumer-diagnostics'
O = Q / 'consumer-fixture-supplements'
O.mkdir()
R = Path('/home/tim/Documents/GitHub/workspace/hyperreal')
C = json.loads((Q / 'run.json').read_text())
C['candidate'] = 'cdc6d3a74fd2240f8037efe218c9ea424fd4e501'
E = C['environment'] | {
    'CARGO_TARGET_DIR': str(R / 'target/consumer-diagnostic-coverage-scmfudw9'),
    'CARGO_INCREMENTAL': '0', 'CARGO_PROFILE_DEV_DEBUG': '0', 'CARGO_PROFILE_TEST_DEBUG': '0',
    'CARGO_BUILD_JOBS': '4', 'CARGO_NET_OFFLINE': 'true', 'CCACHE_DISABLE': '1', 'RUST_TEST_THREADS': '2',
    **{name + '_SKIP_BENCHMARK_REPORTS': '1' for name in ['HYPERREAL','HYPERLATTICE','HYPERLIMIT','HYPERTRI','HYPERSOLVE']},
}
pins = json.loads((D / 'pins.json').read_text())
for name, pin in pins.items():
    for path, expected in pin['files'].items():
        assert hashlib.sha256((D / name / path).read_bytes()).hexdigest() == expected

path = D / 'hypersolve/benches/certification.rs'
before = path.read_text()
anchor = '''        rational_reduction.numerator_coefficients,
        vec![(r(1) / r(2)).unwrap()]
    );
    assert_eq!(
        rational_reduction.denominator_coefficients,
        vec![r(2), Real::one()]'''
replacement = '''        rational_reduction.numerator_coefficients,
        vec![(r(2) / r(7)).unwrap(), (r(-1) / r(7)).unwrap()]
    );
    assert_eq!(
        rational_reduction.denominator_coefficients,
        vec![Real::one()]'''
assert before.count(anchor) == 1
after = before.replace(anchor, replacement)
path.write_text(after)
(O / 'hypersolve-fixture.patch').write_text(''.join(difflib.unified_diff(
    before.splitlines(keepends=True), after.splitlines(keepends=True),
    fromfile='a/benches/certification.rs', tofile='b/benches/certification.rs')))
test = '''use hypertri::{Point2, PolygonInput, Real};

#[test]
fn polygon_facts_retain_unresolved_transcendental_edge_differences() {
    let polygon = PolygonInput::new(
        vec![
            Point2::new(Real::zero(), Real::zero()),
            Point2::new(Real::one().sin(), Real::zero()),
            Point2::new(Real::from(2).sin(), Real::one()),
        ],
        Vec::new(),
    );
    assert!(polygon.facts().unknown_edge_zero_status_count() > 0);
}
'''
path = D / 'hypertri/tests/uncertain_edge_coverage.rs'
assert not path.exists()
path.write_text(test)
(O / 'hypertri-uncertainty-test.patch').write_text(''.join(difflib.unified_diff(
    [], test.splitlines(keepends=True), fromfile='/dev/null', tofile='b/tests/uncertain_edge_coverage.rs')))
inputs = {name: {str(p.relative_to(D / name)): hashlib.sha256(p.read_bytes()).hexdigest()
    for p in sorted((D / name).rglob('*')) if p.is_file()} for name in pins}
(O / 'inputs.json').write_text(json.dumps({'baseline': C['baseline'], 'candidate': C['candidate'],
    'consumer_pins': {n: p['revision'] for n,p in pins.items()}, 'consumer_files': inputs,
    'environment': E, 'compiler': C['compiler'],
    'limits': ['These are fixture supplements; all original coverage failures remain recorded.',
        'Only isolated diagnostic snapshots are changed. Live and pinned primary consumer checkouts remain untouched.',
        'No production consumer source changed. The coverage threshold remains 95 percent.',
        'Prior diagnostic examples remain present; their original and failed checks are separately retained.'],
}, indent=2) + '\n')
records = []
for label in ['baseline', 'candidate']:
    revision = C[label]
    source = D / 'hyperreal'
    shutil.rmtree(source)
    source.mkdir()
    names = subprocess.check_output(['git', 'ls-tree', '--name-only', revision], cwd=R, text=True).splitlines()
    chosen = [n for n in names if n in ['Cargo.toml','Cargo.lock','src','README.md','build.rs'] or n.startswith('LICENSE')]
    data = subprocess.check_output(['git','archive',revision,*chosen], cwd=R)
    with tarfile.open(fileobj=io.BytesIO(data)) as tar: tar.extractall(source, filter='data')
    for name in ['hypertri', 'hypersolve']:
        folder = O / label / name
        folder.mkdir(parents=True)
        command = ['timeout','--signal=TERM','--kill-after=10s','1800s','bash','scripts/coverage.sh']
        start = time.time()
        with (folder / 'coverage.log').open('w') as log:
            env = os.environ | E
            env.pop('NO_COLOR', None)
            result = subprocess.run(command,cwd=D/name,env=env,stdout=log,stderr=subprocess.STDOUT)
        records.append({'label':label,'revision':revision,'consumer':name,'step':'coverage',
            'command':command,'cwd':str(D/name),'environment':E,'exit_code':result.returncode,
            'seconds':time.time()-start})
        reports = folder / 'reports'
        reports.mkdir()
        target = Path(E['CARGO_TARGET_DIR'])
        for p in target.iterdir():
            if p.is_file() and p.suffix in ['.txt','.json','.profdata']:
                shutil.copy2(p,reports/p.name)
        if (target/'html').exists(): shutil.copytree(target/'html',reports/'html')
        (O/'runs.json').write_text(json.dumps(records,indent=2)+'\n')
        print(label,name,'coverage',result.returncode,round(time.time()-start,1),flush=True)
    # Freeze corrected certification binaries for a separate paired native screen.
    folder = O / label / 'hypersolve'
    command = ['cargo','bench','--locked','--all-features','--bench','certification','--no-run','--message-format=json']
    build_env = os.environ | E | {'CARGO_TARGET_DIR':str(R/'target/consumer-diagnostics-scmfudw9')}
    start = time.time()
    with (folder/'build.jsonl').open('w') as output,(folder/'build.stderr').open('w') as errors:
        result = subprocess.run(command,cwd=D/'hypersolve',env=build_env,stdout=output,stderr=errors)
    records.append({'label':label,'revision':revision,'consumer':'hypersolve','step':'corrected-bench-build',
        'command':command,'cwd':str(D/'hypersolve'),'environment':E|{'CARGO_TARGET_DIR':build_env['CARGO_TARGET_DIR']},
        'exit_code':result.returncode,'seconds':time.time()-start})
    if result.returncode == 0:
        artifacts = [json.loads(line) for line in (folder/'build.jsonl').read_text().splitlines() if line.startswith('{')]
        executables = [a['executable'] for a in artifacts if a.get('reason')=='compiler-artifact'
            and a['target']['name']=='certification' and a.get('executable')]
        assert len(executables)==1
        binary=folder/'certification';shutil.copy2(executables[0],binary)
        (folder/'binary.json').write_text(json.dumps({'sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),
            'bytes':binary.stat().st_size,'source_binary':executables[0]},indent=2)+'\n')
    (O/'runs.json').write_text(json.dumps(records,indent=2)+'\n')
    print(label,'hypersolve','corrected-bench-build',result.returncode,round(time.time()-start,1),flush=True)
    for name, files in inputs.items():
        assert all(hashlib.sha256((D/name/p).read_bytes()).hexdigest()==h for p,h in files.items())
raise SystemExit(any(r['exit_code'] for r in records))
