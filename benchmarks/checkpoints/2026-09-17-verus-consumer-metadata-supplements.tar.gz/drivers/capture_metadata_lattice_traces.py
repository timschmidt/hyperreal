#!/usr/bin/env python3
"""Capture the four lattice reports in an isolated output directory.

Run only after the isolated diagnostic source and target are idle, and before native timing.
"""
import hashlib
import io
import tarfile
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

Q = Path(__file__).resolve().parent
D = Q / 'consumer-diagnostics'
R = Path('/home/tim/Documents/GitHub/workspace/hyperreal')
S = D / 'hyperreal'
L = D / 'hyperlattice'
O = Q / 'metadata-lattice-traces'
C = json.loads((Q / 'run.json').read_text())
C['candidate'] = 'cdc6d3a74fd2240f8037efe218c9ea424fd4e501'
E = C['environment'] | {'CARGO_TARGET_DIR': str(R / 'target/consumer-diagnostics-scmfudw9'),
    'CARGO_BUILD_JOBS': '4', 'CARGO_NET_OFFLINE': 'true', 'CCACHE_DISABLE': '1'}
pin = json.loads((Q / 'metadata-consumers/inputs.json').read_text())['consumers']['hyperlattice']
original_sources = {str(p.relative_to(S)): p.read_bytes() for p in S.rglob('*') if p.is_file()}
original = C['candidate']
for name, data in original_sources.items():
    assert data == subprocess.check_output(['git', 'show', original + ':' + name], cwd=R), name
assert all(hashlib.sha256((L / name).read_bytes()).hexdigest() == expected for name, expected in pin['files'].items())
def checkout(revision):
    names = subprocess.check_output(['git', 'ls-tree', '--name-only', revision], cwd=R, text=True).splitlines()
    chosen = [n for n in names if n in ['Cargo.toml','Cargo.lock','src','README.md','build.rs'] or n.startswith('LICENSE')]
    data = subprocess.check_output(['git','archive',revision,*chosen], cwd=R)
    shutil.rmtree(S)
    S.mkdir()
    with tarfile.open(fileobj=io.BytesIO(data)) as tar: tar.extractall(S, filter='data')
O.mkdir()
runtime = O / 'runtime'
runtime.mkdir()
(O / 'inputs.json').write_text(json.dumps({'baseline': C['baseline'], 'candidate': C['candidate'],
    'consumer': pin, 'compiler': C['compiler'], 'environment': E,
    'limits': ['Reports are trace diagnostics, not native timings.',
        'The report-only suppression flag is removed when running the frozen binary in a separate output directory.']}, indent=2) + '\n')
records = []
try:
    for label in ['baseline', 'candidate']:
        revision = C[label]
        checkout(revision)
        folder = O / label
        folder.mkdir()
        command = ['cargo', 'bench', '--locked', '--all-features', '--bench', 'api_dispatch_trace',
            '--no-run', '--message-format=json']
        start = time.time()
        with (folder / 'build.jsonl').open('w') as output, (folder / 'build.stderr').open('w') as errors:
            result = subprocess.run(command, cwd=L, env=os.environ | E, stdout=output, stderr=errors)
        records.append({'label': label, 'revision': revision, 'step': 'build', 'command': command,
            'cwd': str(L), 'exit_code': result.returncode, 'seconds': time.time() - start})
        (O / 'runs.json').write_text(json.dumps(records, indent=2) + '\n')
        if result.returncode: raise RuntimeError('Trace build failed')
        rows = [json.loads(line) for line in (folder / 'build.jsonl').read_text().splitlines() if line.startswith('{')]
        binaries = [row['executable'] for row in rows if row.get('reason') == 'compiler-artifact'
            and row['target']['name'] == 'api_dispatch_trace' and row.get('executable')]
        assert len(binaries) == 1
        executable = runtime / 'trace'
        shutil.copy2(binaries[0], executable)
        shutil.copy2(binaries[0], folder / 'trace')
        env = os.environ | E
        env.pop('HYPERLATTICE_SKIP_BENCHMARK_REPORTS', None)
        env.pop('NO_COLOR', None)
        command = [str(executable)]
        start = time.time()
        with (folder / 'run.log').open('w') as output:
            result = subprocess.run(command, cwd=runtime, env=env, stdout=output, stderr=subprocess.STDOUT)
        report = runtime / 'api_dispatch_trace.md'
        assert report.is_file()
        report.rename(folder / report.name)
        records.append({'label': label, 'revision': revision, 'step': 'trace', 'command': command,
            'cwd': str(runtime), 'removed_environment_variables': ['HYPERLATTICE_SKIP_BENCHMARK_REPORTS', 'NO_COLOR'],
            'exit_code': result.returncode, 'seconds': time.time() - start,
            'binary_sha256': hashlib.sha256(executable.read_bytes()).hexdigest()})
        (O / 'runs.json').write_text(json.dumps(records, indent=2) + '\n')
        if result.returncode: raise RuntimeError('Trace assertions failed')
        print(label, 'four lattice workloads captured', flush=True)
finally:
    checkout(original)
    assert original_sources == {str(p.relative_to(S)): p.read_bytes() for p in S.rglob('*') if p.is_file()}
    assert all(hashlib.sha256((L / name).read_bytes()).hexdigest() == expected for name, expected in pin['files'].items())
    (O / 'restoration.json').write_text(json.dumps({'hyperreal_revision': original,
        'isolated_hyperlattice_inputs_unchanged': True, 'inputs_unchanged': True}, indent=2) + '\n')
