#!/usr/bin/env python3
"""Preserve isolated consumer fixture controls, failed preparation and trace reports."""
import gzip,hashlib,io,json,re,tarfile
from pathlib import Path
Q=Path(__file__).resolve().parent
R=Path('/home/tim/Documents/GitHub/workspace/hyperreal')
D=R/'benchmarks/checkpoints'
folders=['consumer-fixture-supplements','consumer-fixture-supplements-incomplete-snapshot','metadata-lattice-traces']
inputs=json.loads((Q/folders[0]/'inputs.json').read_text())
success=json.loads((Q/folders[0]/'runs.json').read_text())
failed=json.loads((Q/folders[1]/'runs.json').read_text())
traces=json.loads((Q/folders[2]/'runs.json').read_text())
assert len(success)==6 and all(row['exit_code']==0 for row in success)
assert len(failed)==6 and sum(row['exit_code']==101 for row in failed)==4
assert len(traces)==4 and all(row['exit_code']==0 for row in traces)
rows={}
for label in ['baseline','candidate']:
 text=(Q/folders[2]/label/'api_dispatch_trace.md').read_text()
 rows[label]={match[1]:[int(x) for x in match.groups()[1:]] for match in re.finditer(r'^\| `([^`]+)` \| (\d+) \| (\d+) \| (\d+) \| (\d+) \| (\d+) \| (\d+) \| (\d+) \|$',text,re.M)}
 assert len(rows[label])==4
assert rows['baseline']==rows['candidate']
files=[]; excluded=[]
for folder in folders:
 for p in (Q/folder).rglob('*'):
  if not p.is_file():continue
  with p.open('rb') as f:magic=f.read(4)
  if magic in [b'\x7fELF',b'\x00asm']:
   excluded.append({'path':str(p.relative_to(Q)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
  else:files.append((p,str(p.relative_to(Q))))
(Q/folders[0]/'excluded-executable-bytes.json').write_text(json.dumps(excluded,indent=2)+'\n')
files.append((Q/folders[0]/'excluded-executable-bytes.json',folders[0]+'/excluded-executable-bytes.json'))
for name in ['preserve_metadata_consumer_supplements.py','qualify_consumer_fixture_supplements.py','capture_metadata_lattice_traces.py','screen_metadata_fixture_supplement.py']:
 files.append((Q/name,'drivers/'+name))
archive=D/'2026-09-17-verus-consumer-metadata-supplements.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as zipped:
  with tarfile.open(fileobj=zipped,mode='w') as tar:
   for p,name in sorted(files,key=lambda pair:pair[1]):
    data=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
report={
 'schema':1,'status':'isolated_consumer_controls_for_intermediate_runtime_not_acceptance',
 'baseline':inputs['baseline'],'candidate':inputs['candidate'],'consumer_pins':inputs['consumer_pins'],
 'coverage':{
  'hypertri':{'production_lines':6600,'hits_each':6271,'percent_each':95.02,'required_percent':95,
   'test_change':'A sine-coordinate triangle independently preserves coverage of unknown zero-status edges; no production branch or gate changes.'},
  'hypersolve':{'production_lines':39571,'baseline_hits':34192,'candidate_hits':34194,'percent_each':86.41,'required_percent':85,
   'fixture_change':'Expected retained-field numerator [2/7,-1/7] and denominator [1] match both implementations; exact Fraction polynomial multiplication independently checks the value.'}},
 'corrected_certification_bench':{'matched_builds_passed':2,'native_timing_run':False},
 'lattice_trace':{'builds_passed':2,'runs_passed':2,'paired_workloads':4,'columns':['dependency_dispatch','linear_algebra','exact_reducers','approximation','rational_temporaries','rational_reductions','rational_gcds'],'baseline':rows['baseline'],'candidate':rows['candidate'],'identical_summary_counts':True},
 'failed_preparation':{'coverage_failures_preserved':4,'cause':'The initial diagnostic snapshot omitted tracked fuzz/Cargo.toml files included by benchmark fixtures. Restoring every tracked pinned input allowed the complete rerun to pass.','successful_builds_in_failed_attempt':2},
 'limits':['Only isolated pinned snapshots were changed; live consumers, including concurrently edited Hypercurve, were untouched.',
  'Original unmodified consumer failures remain in the deep checkpoint; these supplemented checks do not relabel them.',
  'These results qualify cdc6d3a only. Commit89c89e2 subsequently repairs discovered magnitude-planning accuracy defects and requires fresh affected qualification.',
  'Trace counts are diagnostics, not native timings or allocation-byte measurements.',
  'Copied report directories may contain incidental earlier reports; only completed command-specific reports support coverage counts.',
  'Executable bytes remain frozen in temporary storage; their hashes and build records are archived.',
  'Full proof and baseline acceptance remain incomplete.'],
 'artifact':{'path':str(archive.relative_to(R)),'bytes':archive.stat().st_size,'files':len(files),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}}
(D/'2026-09-17-verus-consumer-metadata-supplements.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report['artifact']))
