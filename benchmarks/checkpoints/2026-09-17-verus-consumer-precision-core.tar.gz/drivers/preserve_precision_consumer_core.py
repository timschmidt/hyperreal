#!/usr/bin/env python3
"""Preserve every current consumer core outcome, including all failures."""
import gzip,hashlib,io,json,re,subprocess,tarfile
from pathlib import Path
Q=Path(__file__).resolve().parent;R=Path('/home/tim/Documents/GitHub/workspace/hyperreal');O=Q/'precision-consumers';D=R/'benchmarks/checkpoints'
runs=json.loads((O/'core-validation.json').read_text());assert len(runs)==51
assert sum(r['exit_code']==0 for r in runs)==41 and sum(r['exit_code']!=0 for r in runs)==10
inputs=json.loads((O/'inputs.json').read_text())
for name,meta in inputs['consumers'].items():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=Q/name,text=True).strip()==meta['revision']
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=Q/name,text=True)
 assert all(hashlib.sha256((Q/name/p).read_bytes()).hexdigest()==h for p,h in meta['files'].items())
assert not subprocess.check_output(['git','status','--porcelain'],cwd=Q/'consumer-source',text=True)
restoration={'hyperreal_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=Q/'consumer-source',text=True).strip(),'all_pinned_consumers_clean':True,'source_hashes_match_initial_inventory':True}
(O/'core-restoration.json').write_text(json.dumps(restoration,indent=2)+'\n')
files=[(O/n,n) for n in ['core-validation.json','core-restoration.json','inputs.json']]
for r in runs:
 p=Path(r['log']);assert p.is_file();files.append((p,str(p.relative_to(O))))
files += [(Q/'validate_precision_consumers.py','drivers/validate_precision_consumers.py'),(Path(__file__),'drivers/preserve_precision_consumer_core.py')]
failures=[r for r in runs if r['exit_code']]
old=[r for r in json.loads((Q/'consumer-core-validation.json').read_text()) if r['label']=='baseline']
old_keys={(r['consumer'],r['step']) for r in old if r['exit_code']};assert all((r['consumer'],r['step']) in old_keys for r in failures)
files.append((Q/'consumer-core-validation.json','historical-control/consumer-core-validation.json'))
for r in old:
 p=Path(r['log'])
 if p.is_file():files.append((p,'historical-control/'+r['consumer']+'/'+r['step']+'.log'))
archive=D/'2026-09-17-verus-consumer-precision-core.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as zipped:
  with tarfile.open(fileobj=zipped,mode='w') as tar:
   for p,name in sorted(files,key=lambda x:x[1]):
    data=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
report={'schema':1,'status':'consumer_validation_failures_remain','baseline':inputs['baseline'],'candidate':inputs['runtime_revision'],'steps':51,'passed':41,'failed':10,'runs':runs,'failures':failures,'restoration':restoration,
 'findings':['The Hyperlattice all-target command fails when Symbolica refuses another unlicensed process. No locks or unrelated processes were changed.','Formatting failures include the pinned Hyperlimit triangle source reached through downstream workspace dependencies. Hypersolve strict Clippy/docs, Hypercurve strict Clippy and two Hypercurve UI tests fail. All logs are retained.','All three UI WASM/Trunk builds pass after removing inherited NO_COLOR. Hypercurve UI Clippy passes, and all four allocation-profile commands pass in this run.','Each currently failing command also failed in the historical fixed-baseline core run. The historical baseline had three initial Trunk failures before the NO_COLOR fix and a Hypersolve allocation assertion failure; these are not claimed as identical-environment runtime regressions or improvements.'],
 'limits':['This is an outcome inventory with unresolved failures, not acceptance.','Ignored tests and failed steps are not passes. Hypercurve full release and long-running tests, deep coverage/powerset/tracing and native timings remain pending.','Only pinned temporary consumer worktrees were used. The concurrently edited live Hypercurve checkout was untouched.','The historical baseline control is retained with its original environment and outcomes; no fresh baseline replay of all 51 steps is claimed.'],
 'artifact':{'path':str(archive.relative_to(R)),'bytes':archive.stat().st_size,'files':len(files),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}}
(D/'2026-09-17-verus-consumer-precision-core.json').write_text(json.dumps(report,indent=2)+'\n');print(report['artifact'])
