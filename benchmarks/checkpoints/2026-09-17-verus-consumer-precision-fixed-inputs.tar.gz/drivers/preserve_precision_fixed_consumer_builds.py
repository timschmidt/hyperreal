#!/usr/bin/env python3
"""Preserve pinned fixed-input consumer build/replay evidence, excluding binaries."""
import gzip,hashlib,io,json,tarfile
from pathlib import Path
Q=Path(__file__).resolve().parent;REPO=Path('/home/tim/Documents/GitHub/workspace/hyperreal');OUT=Q/'precision-consumer-fixed-builds';DEST=REPO/'benchmarks/checkpoints'
runs=json.loads((OUT/'runs.json').read_text());assert len(runs)==8 and all(r['exit_code']==0 and not r.get('validation_error') for r in runs)
replays=[r for r in runs if r['step']=='fixtures'];assert len(replays)==4 and all(r['testing_rows']==101 for r in replays)
inputs=json.loads((OUT/'inputs.json').read_text());restored=json.loads((OUT/'restoration.json').read_text());assert restored['pinned_consumers_clean']
baseline_inputs=json.loads((Q/'magnitude-consumer-fixed-builds/inputs.json').read_text());assert inputs['overlay_manifest']==baseline_inputs['overlay_manifest'] and inputs['compiler']==baseline_inputs['compiler']
files=[]
for folder,prefix in [(OUT,'builds'),(Q/'consumer-fixed-inputs','overlays')]:
 for p in folder.rglob('*'):
  if not p.is_file() or p.name=='retained_fuzz':continue
  files.append((p,prefix+'/'+str(p.relative_to(folder))))
for name in ['prepare_fixed_consumer_inputs.py','build_precision_fixed_consumer_inputs.py','preserve_precision_fixed_consumer_builds.py']:
 files.append((Q/name,'drivers/'+name))
archive=DEST/'2026-09-17-verus-consumer-precision-fixed-inputs.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as zipped:
  with tarfile.open(fileobj=zipped,mode='w') as tar:
   for p,name in sorted(files,key=lambda row:row[1]):
    data=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
report={'schema':1,'status':'fixed_input_build_and_replay_milestone_not_acceptance','baseline':baseline_inputs['revisions']['baseline'],'baseline_build_evidence':'benchmarks/checkpoints/2026-09-17-verus-consumer-fixed-inputs.json','candidate':inputs['revisions']['candidate'],
 'consumers':inputs['overlay_manifest']['consumers'],'ordered_inputs_per_variant':400,'successful_candidate_builds':4,'successful_candidate_fixture_replays':4,'criterion_rows_per_replay':101,
 'freeze_switch':inputs['overlay_manifest']['switch'],'method':'The candidate uses the same pinned source paths, lockfiles, compiler, benchmark-only overlay and 400 stored seeds in their stored order as the previously qualified fixed-baseline builds. Those unchanged baseline binaries and evidence are reused. The explicit freeze mode bypasses adaptive promotion and permits Criterion test/list mode. Normal adaptive behavior remains when the switch is absent.',
 'runs':runs,'restoration':restored,
 'limits':['No native timing or performance acceptance is inferred from fixture durations.','This supplement does not replace all ordinary consumer tests, feature matrices, fuzz targets, benchmarks or coverage.','Live consumer worktrees, including concurrently edited Hypercurve, were not modified. Hypercurve is not one of these four patched harnesses.','The aggregate score replays the same 100 inputs again; it does not represent 100 additional independent cases.'],
 'artifact':{'path':str(archive.relative_to(REPO)),'bytes':archive.stat().st_size,'files':len(files),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}}
(DEST/'2026-09-17-verus-consumer-precision-fixed-inputs.json').write_text(json.dumps(report,indent=2)+'\n');print(report['artifact'])
