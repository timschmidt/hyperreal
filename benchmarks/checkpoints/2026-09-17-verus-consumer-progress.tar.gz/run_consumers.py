#!/usr/bin/env python3
"""Build every consumer benchmark and run their full-feature release suites."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

ROOT = Path(__file__).resolve().parent
CONFIG = json.loads((ROOT / "run.json").read_text())
CONSUMERS = json.loads((ROOT / "consumers.json").read_text())
ENV = os.environ | CONFIG["environment"] | {"CARGO_TARGET_DIR": str(ROOT / "consumer-target")}
RESULTS = []
FEATURES = {"hyperlattice": [], "hyperlimit": [], "hypertri": ["all-algorithms,runtime-select,f64-interop"],
            "hypersolve": [], "hypercurve": ["triangulation,svg,hershey,comparative-benchmarks"], "hypermesh": []}
for label in ["baseline", "candidate"]:
    subprocess.run(["git", "checkout", "--detach", CONFIG[label]], cwd=ROOT / "consumer-source", check=True)
    for name, features in FEATURES.items():
        folder = ROOT / label / "consumers" / name
        folder.mkdir(parents=True)
        build = ["cargo", "bench", "--locked", "--benches", "--no-run", "--message-format=json"]
        if features:
            build += ["--features", features[0]]
        for step, command in [
            ("bench-build", build),
            ("tests-all", ["cargo", "test", "--locked", "--release", "--all-features", "--no-fail-fast", "--", "--test-threads=2"]),
        ]:
            started = time.time()
            with (folder / (step + ".stdout")).open("w") as output, (folder / (step + ".stderr")).open("w") as error:
                result = subprocess.run(command, cwd=ROOT / name, env=ENV, stdout=output, stderr=error)
            RESULTS.append({"label": label, "hyperreal_revision": CONFIG[label], "consumer": name,
                "consumer_revision": CONSUMERS[name]["revision"], "command": command,
                "step": step, "exit_code": result.returncode, "seconds": time.time() - started,
                "stdout": str(folder / (step + ".stdout")), "stderr": str(folder / (step + ".stderr"))})
            (ROOT / "consumer-results.json").write_text(json.dumps(RESULTS, indent=2) + "\n")
            print(label, name, step, result.returncode, round(time.time() - started, 1), flush=True)
            if step == "bench-build" and result.returncode == 0:
                (folder / "bin").mkdir()
                binaries = {}
                for line in (folder / (step + ".stdout")).read_text().splitlines():
                    artifact = json.loads(line)
                    if artifact.get("reason") != "compiler-artifact" or not artifact.get("executable"):
                        continue
                    if artifact["target"]["kind"] != ["bench"]:
                        continue
                    destination = folder / "bin" / artifact["target"]["name"]
                    shutil.copy2(artifact["executable"], destination)
                    binaries[destination.name] = {"sha256": hashlib.sha256(destination.read_bytes()).hexdigest(),
                        "features": artifact["features"], "target": artifact["target"], "bytes": destination.stat().st_size}
                (folder / "binaries.json").write_text(json.dumps(binaries, indent=2) + "\n")

raise SystemExit(any(r["exit_code"] for r in RESULTS))
