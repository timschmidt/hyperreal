#!/usr/bin/env python3
"""Check coverage exclusions and correct preserved reports without rerunning workloads."""
import hashlib,json,re,subprocess
from pathlib import Path
Q=Path(__file__).resolve().parent;R=Path('/home/tim/Documents/GitHub/workspace/hyperreal');O=Q/'coverage-accounting-audit';O.mkdir()
script=(R/'scripts/coverage.sh').read_text();program=script.split("awk -F'|' -v prefix=\"${repo_dir}/\" '",1)[1].split("\n    '\n",1)[0]
(O/'production-lines.awk').write_text(program)
fixtures={
 'src/named.rs':'fn production() {}\n#[cfg(test)]\nmod domain_cases {\n fn regression() {}\n}\n',
 'src/dedicated_tests.rs':'fn regression() {}\n',
 'src/uncovered.rs':'fn production() {}\n',
 'src/inline.rs':'#[cfg(test)]\n\nmod tests {\n fn regression() {}\n}\n',
}
annotations=[]
for name,content in fixtures.items():
 p=O/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(content);annotations.append(str(p)+':')
 if name=='src/named.rs':annotations+=['1|3|fn production() {}','4|1| fn regression() {}']
 elif name=='src/uncovered.rs':annotations+=['1|0|fn production() {}']
 elif name=='src/inline.rs':annotations+=['4|1| fn regression() {}']
 else:annotations+=['1|1|fn regression() {}']
data='\n'.join(annotations)+'\n';(O/'fixture-coverage.txt').write_text(data)
command=['awk','-F|','-v','prefix='+str(O)+'/', '-f',str(O/'production-lines.awk')]
result=subprocess.run(command,input=data,text=True,capture_output=True);(O/'fixture-result.txt').write_text(result.stdout+result.stderr)
assert result.returncode==0 and re.search(r'^TOTAL\s+2\s+1\s+1\s+50.00%$',result.stdout,re.M),result.stdout
comparisons={}
for label,rev,path in [('baseline_classification_repaired','a2da8e2b5de9a1a4653d3662f2f05cb6533fd7ef',Q/'baseline-audit-repair/coverage-matrix.log'),('precision_candidate','89c89e278671719e568ce3acbea686821f91b8a2',Q/'certified-planning-complete/validation/coverage-matrix.stdout')]:
 text=path.read_text().split('Production executable lines (test-only source excluded):',1)[1]
 rows={m[1]:dict(zip(['lines','hit','missed'],map(int,m.groups()[1:]))) for m in re.finditer(r'^(src/\S+)\s+(\d+)\s+(\d+)\s+(\d+)\s+[\d.]+%$',text,re.M)}
 assert rows
 excluded={n:r for n,r in rows.items() if n.endswith('_tests.rs') or n=='src/computable/approximation.rs'}
 sources={n:subprocess.check_output(['git','show',rev+':'+n],cwd=R) for n in excluded}
 for n,data in sources.items():
  p=O/label/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 totals={k:sum(r[k] for n,r in rows.items() if n not in excluded) for k in ['lines','hit','missed']}
 totals['percent']=100*totals['hit']/totals['lines']
 comparisons[label]={'revision':rev,'original_report':str(path),'original_report_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'excluded_rows':excluded,'corrected_totals':totals,'excluded_source_sha256':{n:hashlib.sha256(b).hexdigest() for n,b in sources.items()}}
(O/'audit.json').write_text(json.dumps({'fixture_command':command,'fixture_exit_code':result.returncode,'fixture_expected':{'lines':2,'hit':1,'missed':1},'script_sha256':hashlib.sha256(script.encode()).hexdigest(),'comparisons':comparisons,'method':'Subtract only fully test-only executable file rows from the preserved physical-line reports. approximation.rs contains imports/includes followed by test modules; its executable lines are all tests. Dedicated *_tests.rs files are cfg(test)-gated directly or by their parent module. No workload was rerun and no original result was overwritten.','limits':'The baseline completed coverage uses the previously preserved classification-only repair for exact_quadratic_normal_form; its original inventory failure remains a failure. The script follows the repository convention that inline cfg(test) modules trail production code. Coverage remains supplementary and is not a formal proof percentage.'},indent=2)+'\n')
print(json.dumps({label:row['corrected_totals'] for label,row in comparisons.items()}))
