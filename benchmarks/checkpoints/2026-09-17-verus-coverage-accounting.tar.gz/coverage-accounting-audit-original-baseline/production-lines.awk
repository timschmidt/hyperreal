
        /^\/.*\.rs:$/ {
            file = $0
            sub(/:$/, "", file)
            relative = substr(file, length(prefix) + 1)
            boundary = 999999

            if (relative ~ /(^|\/)(tests|[[:alnum:]_]+_tests)\.rs$/ || relative == "src/real/normal_reference.rs") {
                boundary = 1
            } else {
                source_line_number = 0
                pending_cfg_test = 0
                while ((getline source_line < file) > 0) {
                    source_line_number++
                    if (source_line ~ /^[[:space:]]*#\[cfg\(test\)\][[:space:]]*$/) {
                        pending_cfg_test = source_line_number
                        continue
                    }
                    if (pending_cfg_test != 0 && source_line ~ /^[[:space:]]*$/) {
                        continue
                    }
                    if (pending_cfg_test != 0 && source_line ~ /^[[:space:]]*mod[[:space:]]+[[:alpha:]_][[:alnum:]_]*[[:space:]]*\{/) {
                        boundary = pending_cfg_test
                        break
                    }
                    if (pending_cfg_test != 0) {
                        pending_cfg_test = 0
                    }
                }
                close(file)
            }

            files[file] = 1
            boundaries[file] = boundary
            next
        }
        file != "" && $1 ~ /^[[:space:]]*[0-9]+$/ {
            line = $1 + 0
            count = $2
            gsub(/[[:space:]]/, "", count)
            if (line < boundaries[file] && count != "") {
                total[file]++
                if (count != "0") {
                    hit[file]++
                }
            }
        }
        END {
            for (file in files) {
                order[++file_count] = file
            }
            for (left = 1; left <= file_count; left++) {
                for (right = left + 1; right <= file_count; right++) {
                    if (order[left] > order[right]) {
                        temporary = order[left]
                        order[left] = order[right]
                        order[right] = temporary
                    }
                }
            }
            printf "%-58s %8s %8s %8s %9s\n", "Source", "Lines", "Hit", "Missed", "Coverage"
            for (row = 1; row <= file_count; row++) {
                file = order[row]
                relative = substr(file, length(prefix) + 1)
                missed = total[file] - hit[file]
                coverage = total[file] ? 100 * hit[file] / total[file] : 100
                printf "%-58s %8d %8d %8d %8.2f%%\n", relative, total[file], hit[file], missed, coverage
                sum += total[file]
                sum_hit += hit[file]
            }
            printf "%-58s %8d %8d %8d %8.2f%%\n", "TOTAL", sum, sum_hit, sum - sum_hit, 100 * sum_hit / sum
        }