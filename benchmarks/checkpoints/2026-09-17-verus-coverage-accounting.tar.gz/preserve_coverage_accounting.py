#!/usr/bin/env python3
import gzip,hashlib,io,json,tarfile
from pathlib import Path
Q=Path(__file__).resolve().parent;R=Path('/home/tim/Documents/GitHub/workspace/hyperreal');D=R/'benchmarks/checkpoints'
audit=json.loads((Q/'coverage-accounting-audit/audit.json').read_text())
files=[]
for folder in ['coverage-accounting-audit','coverage-accounting-audit-original-baseline']:
 files.extend((p,str(p.relative_to(Q))) for p in (Q/folder).rglob('*') if p.is_file())
for name in ['preserve_coverage_accounting.py','audit_coverage_accounting.py','baseline/validation/coverage-matrix.log','baseline-audit-repair/coverage-matrix.log','baseline-audit-repair/classification-only.patch','baseline-audit-repair/results.json','certified-planning-complete/validation/coverage-matrix.stdout']:
 files.append((Q/name,name))
files.append((R/'scripts/coverage.sh','corrected-scripts/coverage.sh'))
archive=D/'2026-09-17-verus-coverage-accounting.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as tar:
   for p,name in sorted(files,key=lambda pair:pair[1]):
    data=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
report={'schema':1,'status':'coverage_accounting_correction_not_proof_or_acceptance','baseline':'a2da8e2b5de9a1a4653d3662f2f05cb6533fd7ef','script_sha256':audit['script_sha256'],'fixture_check':{'passed':True,'production_lines':2,'hit':1,'missed':1,'covers':['named inline test module','module named tests','dedicated test-only source','uncovered production line']},'comparisons':audit['comparisons'],'method':audit['method'],'limits':[audit['limits'],'The first correction attempt selected the original failing baseline log and correctly could not derive a completed coverage report; its diagnostic and passing parser fixture are preserved.','Original reports and prior checkpoints remain unchanged; this correction supersedes their production-only line counts for the two listed revisions.','The later bound-composition candidate requires a fresh corrected coverage run.'], 'artifact':{'path':str(archive.relative_to(R)),'bytes':archive.stat().st_size,'files':len(files),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}}
(D/'2026-09-17-verus-coverage-accounting.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report['artifact']))
