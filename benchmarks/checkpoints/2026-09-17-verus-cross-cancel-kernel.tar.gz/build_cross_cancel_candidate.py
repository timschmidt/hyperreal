#!/usr/bin/env python3
"""Build the exact root kernel runtime at the fixed baseline comparison path."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

Q = Path(__file__).resolve().parent
REPO = Path('/home/tim/Documents/GitHub/workspace/hyperreal')
SOURCE = Q / 'source'
OUT = Q / 'cross-cancel-candidate'
ENV = json.loads((Q / 'run.json').read_text())['environment'] | {
    'CARGO_BUILD_JOBS': '4', 'CCACHE_DISABLE': '1', 'CARGO_NET_OFFLINE': 'true'}
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=SOURCE, text=True)
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=SOURCE, text=True).strip()
assert base == '561e36a6df4a91e9ede58a74eaea64dad0370238'
names = subprocess.check_output(['git', 'diff', '--name-only', base, '--', 'src'], cwd=REPO, text=True).splitlines()
assert set(names) == {'src/verified/fraction.rs', 'src/rational/arithmetic/aggregate_products.rs', 'src/rational/arithmetic/tests.rs'}
originals = {name: (SOURCE / name).read_bytes() for name in names}
OUT.mkdir()
(OUT / 'bin').mkdir()
records = []
binaries = {}
try:
    for name in names:
        (SOURCE / name).write_bytes((REPO / name).read_bytes())
    inputs = subprocess.check_output(['git', 'ls-files', '-z', 'src', 'benches', 'Cargo.toml', 'Cargo.lock'], cwd=SOURCE).decode().split('\0')
    for name in inputs:
        if name:
            assert (SOURCE / name).read_bytes() == (REPO / name).read_bytes(), name
    (OUT / 'inputs.json').write_text(json.dumps({name: hashlib.sha256((SOURCE / name).read_bytes()).hexdigest() for name in inputs if name}, indent=2) + '\n')
    (OUT / 'change.patch').write_bytes(subprocess.check_output(['git', 'diff'], cwd=SOURCE))
    for step, command, cwd, extra in [
        ('probe-build', ['cargo', 'build', '--offline', '--release', '--message-format=json'], Q / 'representation-probe',
         {'CARGO_TARGET_DIR': str(Q / 'probe-target'), 'CARGO_BUILD_JOBS': '2'}),
        ('bench-build', ['cargo', 'bench', '--locked', '--offline', '--features', 'simple', '--benches', '--no-run', '--message-format=json'], SOURCE, {}),
    ]:
        start = time.time()
        with (OUT / (step + '.stdout')).open('w') as output, (OUT / (step + '.stderr')).open('w') as error:
            result = subprocess.run(command, cwd=cwd, env=os.environ | ENV | extra, stdout=output, stderr=error)
        records.append({'runtime_base': base, 'step': step, 'command': command, 'cwd': str(cwd), 'environment': ENV | extra,
                        'exit_code': result.returncode, 'seconds': time.time() - start})
        temporary = OUT / 'builds.next.json'
        temporary.write_text(json.dumps(records, indent=2) + '\n')
        temporary.replace(OUT / 'builds.json')
        print(step, result.returncode, round(time.time() - start, 1), flush=True)
        if result.returncode:
            raise SystemExit(result.returncode)
        if step == 'probe-build':
            shutil.copy2(Q / 'probe-target/release/hyperreal-representation-probe', OUT / 'probe')
            (OUT / 'probe.json').write_text(json.dumps({'sha256': hashlib.sha256((OUT / 'probe').read_bytes()).hexdigest(), 'build': records[-1]}, indent=2) + '\n')
        else:
            for line in (OUT / (step + '.stdout')).read_text().splitlines():
                artifact = json.loads(line)
                if artifact.get('reason') != 'compiler-artifact' or not artifact.get('executable') or artifact['target']['kind'] != ['bench']:
                    continue
                dest = OUT / 'bin' / artifact['target']['name']
                shutil.copy2(artifact['executable'], dest)
                binaries[dest.name] = {'sha256': hashlib.sha256(dest.read_bytes()).hexdigest(), 'bytes': dest.stat().st_size,
                                      'features': artifact['features'], 'target': artifact['target']}
            (OUT / 'binaries.json').write_text(json.dumps(binaries, indent=2) + '\n')
finally:
    for name, data in originals.items():
        (SOURCE / name).write_bytes(data)
    status = subprocess.check_output(['git', 'status', '--porcelain'], cwd=SOURCE, text=True)
    (OUT / 'restored-status.txt').write_text(status)
    assert not status, status
