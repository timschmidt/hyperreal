#![feature(proc_macro_hygiene)]
mod verified;
