#!/usr/bin/env python3
"""Retain the proved cancellation traversal and its runtime qualification."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

Q = Path(__file__).resolve().parent
REPO = Path('/home/tim/Documents/GitHub/workspace/hyperreal')
DEST = REPO / 'benchmarks/checkpoints'
TRIAL = Q / 'cross-cancel-proof-trial'
qualification = json.loads((TRIAL / 'qualification.json').read_text())
proof = json.loads((TRIAL / 'corrected-official-proof/evidence.json').read_text())
assert proof['verification_results']['success']
assert proof['verification_results']['verified'] == 374
checks = json.loads((TRIAL / 'root-validation/runs.json').read_text())
assert len(checks) == 5
assert [r['exit_code'] for r in checks] == [0, 0, 0, 0, 101]
assert 'Finished' in (TRIAL / 'clippy-corrected.stderr').read_text()
assert '374 verification units verified, 0 errors' in (TRIAL / 'proof-corrected.stdout').read_text()
rejections = (TRIAL / 'all-mutations.log').read_text()
assert rejections.count('Rejected incorrect') == 73
assert rejections.count('Rejected attempted assumption bypass') == 1
fuzz = json.loads((Q / 'cross-cancel-fuzz/runs.json').read_text())
assert len(fuzz) == 6 and all(r['exit_code'] == 0 for r in fuzz)
assert sum(r['corpus_files'] for r in fuzz) == 6492
assert not (Q / 'cross-cancel-fuzz/restored-status.txt').read_text()
builds = json.loads((Q / 'cross-cancel-candidate/builds.json').read_text())
assert len(builds) == 2 and all(r['exit_code'] == 0 for r in builds)
assert not (Q / 'cross-cancel-candidate/restored-status.txt').read_text()
files = set()
for folder in [TRIAL, Q / 'cross-cancel-fuzz', Q / 'cross-cancel-candidate']:
    for path in folder.rglob('*'):
        if not path.is_file():
            continue
        relative = path.relative_to(folder)
        if 'corpus' in relative.parts or 'bin' in relative.parts or path.name == 'probe':
            continue
        if relative.parts[0] == 'official-proof' and path.name not in ['evidence.json', 'verus.json', 'verus.stderr']:
            continue
        files.add(path)
files.update(Q / name for name in ['qualify_cross_cancel_root.py', 'replay_cross_cancel_corpora.py',
    'build_cross_cancel_candidate.py', 'preserve_cross_cancel_kernel.py', 'run.json', 'saved-corpora.json'])
archive = DEST / '2026-09-17-verus-cross-cancel-kernel.tar.gz'
with archive.open('wb') as output:
    with gzip.GzipFile(fileobj=output, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for path in sorted(files):
                data = path.read_bytes()
                info = tarfile.TarInfo(str(path.relative_to(Q)))
                info.size = len(data)
                info.mode = 0o644
                tar.addfile(info, io.BytesIO(data))
report = {'schema': 1, 'status': 'proof_and_correctness_milestone_not_acceptance',
    'baseline': 'a2da8e2b5de9a1a4653d3662f2f05cb6533fd7ef',
    'candidate': qualification['revision'], 'verification_units': 374, 'production_contracts': 54,
    'model_theorems': 66, 'open_obligation_groups': 13, 'no_cheating': True,
    'source_hashes': proof['sources'], 'qualification': qualification, 'validation': checks,
    'mutation_rejections': 73, 'assumption_bypass_rejected': True,
    'frozen_asan_inputs': sum(r['corpus_files'] for r in fuzz), 'fuzz_runs': fuzz,
    'frozen_corpora_artifact': 'benchmarks/checkpoints/2026-09-17-verus-corpora.tar.gz',
    'matched_builds': builds, 'limits': [
        'The proof covers the production cancellation loop and ordered checked products, including unit shortcuts and overflow before a later zero.',
        'BigUint import, positive-denominator caller invariants, surrounding rational algorithms and complete dependency refinement remain unverified.',
        'Both test configurations, the representation matrix, all mutations and frozen ASan replay succeeded. The original Clippy failure is retained with its annotation-only correction and successful strict rerun.',
        'Tests, fuzz and matched executables precede the lint-only annotation. The corrected official proof hashes the committed source; no executable statements or test assertions changed.',
        'The earlier isolated proof is partial relative to the repository proof target. Only the corrected official report establishes the 374-unit result.',
        'Native timing, full resource/size/coverage checks and current downstream qualification are still pending for this runtime.',
        'The metadata shortcut remains a separate unadopted experiment. No runtime or baseline acceptance is claimed.'],
    'artifact': {'path': str(archive.relative_to(REPO)), 'bytes': archive.stat().st_size,
                 'files': len(files), 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()}}
(DEST / '2026-09-17-verus-cross-cancel-kernel.json').write_text(json.dumps(report, indent=2) + '\n')
print(report['artifact'])
