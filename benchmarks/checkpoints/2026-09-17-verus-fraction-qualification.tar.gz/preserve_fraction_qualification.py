#!/usr/bin/env python3
"""Archive completed matched-path builds, coverage and resource diagnostics."""
import gzip,hashlib,io,json,re,shutil,subprocess,tarfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REPO=Path('/home/tim/Documents/GitHub/workspace/hyperreal')
OUT=ROOT/'fraction-candidate'
DEST=REPO/'benchmarks/checkpoints'
REPORT=DEST/'2026-09-17-verus-fraction.json'
REVISION=subprocess.check_output(['git','rev-parse','8c74849'],cwd=REPO,text=True).strip()
checks=json.loads((OUT/'validation-results.json').read_text())
assert len(checks)==13 and all(r['exit_code']==0 for r in checks)
assert not (OUT/'validation-worktree-status.txt').read_text()
profiles=json.loads((OUT/'profiles.json').read_text())
assert all(r['exit_code']==0 for r in profiles)
resource=json.loads((OUT/'resource-comparison.json').read_text());resource['runtime_candidate']=REVISION
(OUT/'resource-comparison.json').write_text(json.dumps(resource,indent=2)+'\n')
for name in ['qualify_fraction_builds.py','profile_fraction.py','preserve_fraction_qualification.py']:
 shutil.copy2(ROOT/name,OUT/name)
files=[]
for name in ['validation','coverage-html','profiles']:
 files.extend(p for p in (OUT/name).rglob('*') if p.is_file())
files.extend(OUT/name for name in ['validation-results.json','validation-worktree-status.txt','binaries.json',
 'profiles.json','resource-comparison.json','dispatch_trace.md','expanded-runtime.rs','expanded-runtime.log',
 'expanded-runtime-counts.json','qualify_fraction_builds.py','profile_fraction.py','preserve_fraction_qualification.py',
 'representation-probe/binary.json'])
archive=DEST/'2026-09-17-verus-fraction-qualification.tar.gz'
with archive.open('wb') as output:
 with gzip.GzipFile(fileobj=output,mode='wb',filename='',mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as tar:
   for p in sorted(files):
    data=p.read_bytes();info=tarfile.TarInfo(str(p.relative_to(OUT)));info.size=len(data);info.mode=0o644
    tar.addfile(info,io.BytesIO(data))
report=json.loads(REPORT.read_text())
report['matched_build_and_validation']=checks
coverage=re.search(r'^TOTAL\s+(\d+)\s+(\d+)\s+(\d+)\s+([\d.]+)%$',(OUT/'validation/coverage-matrix.stdout').read_text(),re.M)
assert coverage
report['coverage']={'production_executable_lines':int(coverage[1]),'covered_lines':int(coverage[2]),
                    'uncovered_lines':int(coverage[3]),'line_coverage_percent':float(coverage[4]),
                    'interpretation':'Seven-configuration executable-line coverage; this is not formal proof coverage.'}
report['resource_diagnostics']=resource
report['resource_commands']=profiles
report['expanded_runtime_source']=json.loads((OUT/'expanded-runtime-counts.json').read_text())
report['expanded_runtime_source']['revision']=REVISION
report['expanded_runtime_source']['baseline_lines']=35597
report['expanded_runtime_source']['baseline_tokei_code']=33491
report['expanded_runtime_source']['interpretation']='Same nightly no-default-feature macro-expanded library as the baseline audit; tests and ghost code erased, compiler-generated items retained. Auxiliary source-size view, not machine-code size.'
report['binary_artifacts']=json.loads((OUT/'binaries.json').read_text())
report['qualification_artifact']={'path':str(archive.relative_to(REPO)),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
                                 'bytes':archive.stat().st_size,'files':len(files),
                                 'contents':'Complete matched build/check/coverage logs and HTML, profile output, source expansion, binary metadata and audit drivers. Executable payloads remain in the temporary audit directory.'}
report['pending']=['Full implementation/caller/dependency proofs','Native benchmark comparisons against the fixed pre-Verus baseline',
                  'Downstream qualification of this runtime revision','Resolution of prior performance and resource findings, including larger binary/source sizes',
                  'Final source-bound acceptance']
REPORT.write_text(json.dumps(report,indent=2)+'\n')
print(report['qualification_artifact'])
print(report['coverage'])
