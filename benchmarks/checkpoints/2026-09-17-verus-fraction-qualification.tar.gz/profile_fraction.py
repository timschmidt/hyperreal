#!/usr/bin/env python3
"""Collect supplementary resource diagnostics; elapsed times are not timings."""
import hashlib,json,os,subprocess,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'fraction-candidate'
CONFIG=json.loads((ROOT/'run.json').read_text())
REVISION=subprocess.check_output(['git','rev-parse','8c74849'],cwd=ROOT/'source',text=True).strip()
ENV=os.environ | CONFIG['environment']
RECORDS=[]
folder=OUT/'profiles';folder.mkdir(exist_ok=True)
binary=OUT/'bin/allocation_profile'
commands=[
 ('allocations',[str(binary),'64']),
 ('callgrind',['valgrind','--tool=callgrind','--callgrind-out-file='+str(folder/'callgrind.out'),str(binary),'64']),
 ('massif',['valgrind','--tool=massif','--stacks=yes','--time-unit=B','--detailed-freq=1','--massif-out-file='+str(folder/'massif.out'),str(binary),'64']),
 ('memcheck',['valgrind','--tool=memcheck','--error-exitcode=99','--leak-check=full','--show-leak-kinds=definite,indirect','--errors-for-leak-kinds=definite,indirect',str(binary),'64']),
 ('heaptrack',['heaptrack','--output',str(folder/'heaptrack'),str(binary),'64']),
 ('dispatch',[str(OUT/'bin/dispatch_trace')]),
 ('sections',['size','-A',*[str(p) for p in sorted((OUT/'bin').iterdir()) if p.suffix!='.wasm']]),
]
for name,command in commands:
 env=ENV.copy()
 if name=='dispatch':env.pop('HYPERREAL_SKIP_BENCHMARK_REPORTS',None)
 start=time.time()
 with (folder/(name+'.log')).open('w') as log:
  result=subprocess.run(command,cwd=OUT,env=env,stdout=log,stderr=subprocess.STDOUT)
 RECORDS.append({'revision':REVISION,'baseline':CONFIG['baseline'],'name':name,'command':command,
                 'exit_code':result.returncode,'seconds':time.time()-start,'log':str(folder/(name+'.log')),
                 'cwd':str(OUT),'native_timing':False,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest() if name not in ['dispatch','sections'] else None})
 (OUT/'profiles.json').write_text(json.dumps(RECORDS,indent=2)+'\n')
 print(name,result.returncode,round(time.time()-start,1),flush=True)
if (folder/'heaptrack.zst').exists():
 with (folder/'heaptrack-summary.txt').open('w') as log:
  result=subprocess.run(['heaptrack_print',str(folder/'heaptrack.zst')],stdout=log,stderr=subprocess.STDOUT)
 RECORDS.append({'name':'heaptrack-summary','exit_code':result.returncode})
 (OUT/'profiles.json').write_text(json.dumps(RECORDS,indent=2)+'\n')
raise SystemExit(any(r['exit_code'] for r in RECORDS))
