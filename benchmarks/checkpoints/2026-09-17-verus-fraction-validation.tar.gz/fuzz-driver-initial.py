#!/usr/bin/env python3
"""Replay the fixed baseline corpus inventory after native fraction refinement."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'fuzz-source'
REVISION = subprocess.check_output(['git', 'rev-parse', '8c74849'], cwd=SOURCE, text=True).strip()
OUT = ROOT / 'fraction-candidate'
OUT.mkdir(exist_ok=True)
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=SOURCE, text=True)
subprocess.run(['git', 'checkout', '--detach', REVISION], cwd=SOURCE, check=True)
CONFIG = json.loads((ROOT / 'run.json').read_text())
ENV = os.environ | CONFIG['environment'] | {'CCACHE_DISABLE':'1', 'CARGO_BUILD_JOBS':'2', 'ASAN_OPTIONS':'detect_leaks=0'}
INVENTORY = json.loads((ROOT / 'saved-corpora.json').read_text())
RESULTS = []
for target, files in INVENTORY.items():
    folder = OUT / 'fuzz' / target
    (folder / 'corpus').mkdir(parents=True)
    (folder / 'artifacts').mkdir()
    original = ROOT / 'baseline/fuzz' / (target + '-saved-corpus') / 'corpus'
    for name, digest in files.items():
        source = original / name
        assert hashlib.sha256(source.read_bytes()).hexdigest() == digest
        shutil.copy2(source, folder / 'corpus' / name)
    command = ['cargo', '+nightly', 'fuzz', 'run', target, str(folder / 'corpus'),
               '--fuzz-dir', 'fuzz', '--target-dir', str(ROOT / 'fuzz-target'), '--',
               '-runs=0', '-timeout=10', '-seed=93537', '-artifact_prefix=' + str(folder / 'artifacts') + '/']
    log = folder / 'run.log'
    start = time.time()
    with log.open('w') as output:
        result = subprocess.run(command, cwd=SOURCE, env=ENV, stdout=output, stderr=subprocess.STDOUT)
    RESULTS.append({'revision':REVISION, 'baseline':CONFIG['baseline'], 'target':target,
                    'command':command, 'exit_code':result.returncode, 'seconds':time.time()-start,
                    'log':str(log), 'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),
                    'corpus_files':len(files), 'sanitizer':'address', 'ASAN_OPTIONS':'detect_leaks=0',
                    'leak_checker_note':'Previously observed unsupported ptrace environment; ASan stays enabled.'})
    (OUT / 'fuzz-results.json').write_text(json.dumps(RESULTS, indent=2) + '\n')
    print(target, result.returncode, round(time.time()-start,1), flush=True)
status = subprocess.check_output(['git', 'status', '--porcelain'], cwd=SOURCE, text=True)
(OUT / 'fuzz-worktree-status.txt').write_text(status)
assert not status, status
raise SystemExit(any(r['exit_code'] for r in RESULTS))
