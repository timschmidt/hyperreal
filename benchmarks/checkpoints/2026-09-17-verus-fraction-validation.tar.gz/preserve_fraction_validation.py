#!/usr/bin/env python3
"""Retain the completed proof, executable tests and fixed-corpus replay."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import shutil
import subprocess
import tarfile

ROOT=Path(__file__).resolve().parent
REPO=Path('/home/tim/Documents/GitHub/workspace/hyperreal')
OUT=ROOT/'fraction-candidate'
DEST=REPO/'benchmarks/checkpoints'
REVISION=subprocess.check_output(['git','rev-parse','8c74849'],cwd=REPO,text=True).strip()
BASELINE=json.loads((ROOT/'run.json').read_text())['baseline']
shutil.copytree('/tmp/hyperreal-fraction-validation',OUT/'initial-validation',dirs_exist_ok=True)
for name in ['replay_fraction_corpora.py','qualify_fraction_builds.py','preserve_fraction_validation.py']:
 shutil.copy2(ROOT/name,OUT/name)
evidence=json.loads((OUT/'formal/evidence.json').read_text())
assert all(hashlib.sha256((REPO/name).read_bytes()).hexdigest()==digest for name,digest in evidence['sources'].items())
checks=json.loads((OUT/'initial-validation/results.json').read_text())
fuzz=json.loads((OUT/'fuzz-results.json').read_text())
assert len(checks)==4 and all(r['exit_code']==0 for r in checks)
assert len(fuzz)==6 and all(r['exit_code']==0 for r in fuzz)
assert sum(r['corpus_files'] for r in fuzz)==6492
rejections=(OUT/'formal/hyperreal-fraction-rejections.log').read_text()
assert rejections.count('Rejected incorrect')==67 and 'Rejected attempted assumption bypass' in rejections
files=[]
for folder in ['formal','initial-validation','fuzz']:
 for p in (OUT/folder).rglob('*'):
  if p.is_file() and not ('corpus' in p.relative_to(OUT).parts or 'artifacts' in p.relative_to(OUT).parts):files.append(p)
files += [OUT/name for name in ['fuzz-results.json','fuzz-worktree-status.txt','fuzz-driver-initial.py',
    'fuzz-driver-interruption.json','replay_fraction_corpora.py','qualify_fraction_builds.py','preserve_fraction_validation.py']]
archive=DEST/'2026-09-17-verus-fraction-validation.tar.gz'
with archive.open('wb') as output:
 with gzip.GzipFile(fileobj=output,mode='wb',filename='',mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as tar:
   for p in sorted(files):
    data=p.read_bytes();info=tarfile.TarInfo(str(p.relative_to(OUT)));info.size=len(data);info.mode=0o644
    tar.addfile(info,io.BytesIO(data))
counts={}
for name in ['default-tests','all-tests']:
 text=(OUT/'initial-validation'/(name+'.log')).read_text()
 rows=re.findall(r'test result: ok\. (\d+) passed; 0 failed; (\d+) ignored;',text)
 counts[name]={'passed_executions':sum(int(a) for a,b in rows),'ignored':sum(int(b) for a,b in rows),
               'criterion_fixtures':len(re.findall('^Success$',text,re.M))}
report={
 'schema':1,'status':'in_progress_not_acceptance','baseline':BASELINE,'runtime_candidate':REVISION,
 'priority_order':['exactness','completeness','performance','memory use','binary size','code size'],
 'implementation':'Verified GCD quotient reduction at eight existing native normalization/cross-cancellation sites; positive-denominator caller proofs remain open.',
 'proof':{'verification_units':evidence['verification_results']['verified'],'production_contracts':len(evidence['scope']['verified_executable_contracts']),
          'model_theorems':len(evidence['scope']['verified_model_theorems']),'source_hashes':len(evidence['sources']),
          'open_obligation_groups':sum(r['status']!='complete' for r in evidence['scope']['obligations']),
          'no_cheating':True,'source_hashes_rechecked':True,'mutation_rejections':67,'assumption_bypass_rejected':True},
 'validation':checks,'test_counts':counts,'validation_source_path':str(REPO),
 'compiler':json.loads((ROOT/'run.json').read_text())['compiler'],
 'validation_environment':json.loads((ROOT/'run.json').read_text())['environment'] | {'CARGO_BUILD_JOBS':'4'},
 'fuzz':{'records':fuzz,'fixed_input_files':6492,'corpus_archive':'benchmarks/checkpoints/2026-09-17-verus-corpora.tar.gz',
         'address_sanitizer':True,'leak_sanitizer':'disabled after the previously observed ptrace limitation',
         'driver_repair':json.loads((OUT/'fuzz-driver-interruption.json').read_text()),
         'input_note':'Each copied input was checked against the frozen SHA-256 inventory. Different instrumentation may change libFuzzer initialization execution counts; input bytes are identical.'},
 'artifact':{'path':str(archive.relative_to(REPO)),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':len(files)},
 'pending':['Full implementation/caller/dependency proofs','Remaining release, documentation, WASM and seven-configuration coverage qualification',
            'Native benchmark and resource comparisons against the fixed pre-Verus baseline','Downstream qualification of this runtime revision',
            'Resolution of previous candidate performance and resource findings','Final source-bound acceptance'],
 'previous_runtime_evidence':'benchmarks/checkpoints/2026-09-17-verus-baseline.json',
 'previous_runtime_note':'The broad earlier evidence measures 598f059 and must not be relabeled as proof of parity for this newer runtime.'}
(DEST/'2026-09-17-verus-fraction.json').write_text(json.dumps(report,indent=2)+'\n')
print('Preserved',report['artifact'])
