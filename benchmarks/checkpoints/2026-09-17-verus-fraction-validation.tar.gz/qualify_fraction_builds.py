#!/usr/bin/env python3
"""Build the fraction-refinement candidate at the fixed comparison paths."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'source'
CONFIG = json.loads((ROOT / 'run.json').read_text())
REVISION = subprocess.check_output(['git','rev-parse','8c74849'],cwd=SOURCE,text=True).strip()
OUT = ROOT / 'fraction-candidate'
(OUT / 'bin').mkdir(exist_ok=True)
ENV = os.environ | CONFIG['environment'] | {'CARGO_BUILD_JOBS':'4','CCACHE_DISABLE':'1'}
RESULTS = []
BINARIES = {}
assert not subprocess.check_output(['git','status','--porcelain'],cwd=SOURCE,text=True)
subprocess.run(['git','checkout','--detach',REVISION],cwd=SOURCE,check=True)


def run(step, command, extra=None, archive=False, cwd=SOURCE):
    folder = OUT / 'validation'; folder.mkdir(exist_ok=True)
    start=time.time()
    with (folder/(step+'.stdout')).open('w') as out, (folder/(step+'.stderr')).open('w') as err:
        result=subprocess.run(command,cwd=cwd,env=ENV | (extra or {}),stdout=out,stderr=err)
    record={'revision':REVISION,'baseline':CONFIG['baseline'],'step':step,'command':command,'cwd':str(cwd),
            'environment':CONFIG['environment'] | {'CARGO_BUILD_JOBS':'4','CCACHE_DISABLE':'1'} | (extra or {}),
            'exit_code':result.returncode,'seconds':time.time()-start,
            'stdout':str(folder/(step+'.stdout')),'stderr':str(folder/(step+'.stderr'))}
    RESULTS.append(record)
    (OUT/'validation-results.json').write_text(json.dumps(RESULTS,indent=2)+'\n')
    print(step,result.returncode,round(record['seconds'],1),flush=True)
    if archive and result.returncode == 0:
        for line in (folder/(step+'.stdout')).read_text().splitlines():
            a=json.loads(line)
            if a.get('reason')!='compiler-artifact' or not a.get('executable') or a['target']['kind'] not in [['bench'],['bin'],['example']]:continue
            if step=='dispatch-build' and a['target']['name']!='dispatch_trace':continue
            path=Path(a['executable']); destination=OUT/'bin'/a['target']['name']
            shutil.copy2(path,destination)
            BINARIES[destination.name]={'sha256':hashlib.sha256(destination.read_bytes()).hexdigest(),
                'bytes':destination.stat().st_size,'features':a['features'],'target':a['target'],'build_step':step}
        (OUT/'binaries.json').write_text(json.dumps(BINARIES,indent=2)+'\n')
    return result.returncode


run('bench-build',['cargo','bench','--locked','--features','simple','--benches','--no-run','--message-format=json'],archive=True)
run('release-build',['cargo','build','--locked','--release','--all-features','--examples','--bins','--message-format=json'],archive=True)
run('dispatch-build',['cargo','bench','--locked','--features','dispatch-trace','--bench','dispatch_trace','--no-run','--message-format=json'],archive=True)
run('representation-probe-build',['cargo','build','--offline','--release','--message-format=json'],
    {'CARGO_TARGET_DIR':str(ROOT/'probe-target'),'CARGO_BUILD_JOBS':'2'},cwd=ROOT/'representation-probe')
if RESULTS[-1]['exit_code']==0:
    folder=OUT/'representation-probe';folder.mkdir(exist_ok=True)
    shutil.copy2(ROOT/'probe-target/release/hyperreal-representation-probe',folder/'probe')
    (folder/'binary.json').write_text(json.dumps({'revision':REVISION,'sha256':hashlib.sha256((folder/'probe').read_bytes()).hexdigest()},indent=2)+'\n')
for name,command,extra in [
    ('fmt',['cargo','fmt','--all','--','--check'],{}),
    ('clippy-default',['cargo','clippy','--locked','--all-targets','--','-D','warnings'],{}),
    ('doc-tests-default',['cargo','test','--locked','--doc'],{}),
    ('doc-tests-all',['cargo','test','--locked','--all-features','--doc'],{}),
    ('docs-all',['cargo','doc','--locked','--all-features','--no-deps'],{'RUSTDOCFLAGS':'-D warnings'}),
    ('fuzz-check',['cargo','check','--locked','--manifest-path','fuzz/Cargo.toml','--bins'],{}),
    ('wasm-default',['cargo','build','--locked','--release','--target','wasm32-unknown-unknown','--no-default-features','--lib'],{}),
    ('wasm-all',['cargo','build','--locked','--release','--target','wasm32-unknown-unknown','--all-features','--lib','--bins'],{}),
    ('coverage-matrix',['bash','scripts/coverage.sh'],{'CARGO_TARGET_DIR':str(ROOT/'coverage-target')}),
]:
    run(name,command,extra)
    if name=='wasm-all' and RESULTS[-1]['exit_code']==0:
        shutil.copy2(ROOT/'target/wasm32-unknown-unknown/release/hyperreal.wasm',OUT/'bin/hyperreal.wasm')
    if name=='coverage-matrix':
        report=ROOT/'coverage-target/html'
        if report.exists():shutil.copytree(report,OUT/'coverage-html',dirs_exist_ok=True)
status=subprocess.check_output(['git','status','--porcelain'],cwd=SOURCE,text=True)
(OUT/'validation-worktree-status.txt').write_text(status)
assert not status,status
raise SystemExit(any(r['exit_code'] for r in RESULTS))
