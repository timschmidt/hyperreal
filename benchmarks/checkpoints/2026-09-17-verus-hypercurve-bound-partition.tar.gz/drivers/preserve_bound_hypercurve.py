#!/usr/bin/env python3
"""Archive the completed current pinned partition against its unchanged baseline control."""
import gzip,hashlib,io,json,subprocess,tarfile
from pathlib import Path
Q=Path(__file__).resolve().parent;R=Path('/home/tim/Documents/GitHub/workspace/hyperreal');O=Q/'bound-composition-consumers/hypercurve-release';D=R/'benchmarks/checkpoints'
rows=json.loads((O/'runs.json').read_text());inputs=json.loads((O/'inputs.json').read_text());restoration=json.loads((O/'restoration.json').read_text());old=Q/'metadata-consumers/hypercurve-release';baseline_inputs=json.loads((old/'inputs.json').read_text());baseline=[r for r in json.loads((old/'runs.json').read_text()) if r['label']=='baseline']
assert len(rows)==len(baseline)==7 and restoration['pinned_hypercurve_clean'] and restoration['pinned_hypercurve_inputs_unchanged']
assert inputs['hypercurve_files']==baseline_inputs['hypercurve_files'] and inputs['compiler']==baseline_inputs['compiler'] and inputs['case_partition']==baseline_inputs['case_partition']
controls={r['step']:r for r in baseline};comparison=[]
for r in rows:
 b=controls[r['step']];assert r['command']==b['command'] and r['consumer_revision']==b['consumer_revision']
 comparison.append({'step':r['step'],'command':r['command'],'timeout_seconds':r['timeout_seconds'],'baseline_exit_code':b['exit_code'],'candidate_exit_code':r['exit_code']})
files=[(p,str(p.relative_to(Q))) for p in O.rglob('*') if p.is_file()]
for n in ['qualify_bound_composition_hypercurve.py','preserve_bound_hypercurve.py']:files.append((Q/n,'drivers/'+n))
archive=D/'2026-09-17-verus-hypercurve-bound-partition.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as tar:
   for p,n in sorted(files,key=lambda r:r[1]):
    data=p.read_bytes();info=tarfile.TarInfo(n);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
report={'schema':1,'status':'pinned_consumer_outcomes_preserved_not_acceptance','baseline':baseline_inputs['revisions']['baseline'],'candidate':inputs['revisions']['candidate'],'hypercurve_pin':inputs['hypercurve_pin'],'commands':7,'runs':rows,'comparison':comparison,'restoration':restoration,'baseline_evidence':'benchmarks/checkpoints/2026-09-17-verus-hypercurve-metadata-partition.json','limits':['Timeouts and failures remain unsuccessful outcomes; partial passes do not establish a complete release-suite pass.','Durations include concurrent validation and are not native timing comparisons.','Only the pinned temporary Hypercurve snapshot was used; the live concurrently edited checkout was never changed.','The earlier current consumer-matrix tar contained an incidental partial snapshot of this active phase, explicitly excluded from its completed-command counts. This checkpoint captures its final outcomes.','Native timings, full proof and baseline acceptance remain incomplete.'],'artifact':{'path':str(archive.relative_to(R)),'files':len(files),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}}
(D/'2026-09-17-verus-hypercurve-bound-partition.json').write_text(json.dumps(report,indent=2)+'\n');print(report['artifact']);print([(r['step'],r['baseline_exit_code'],r['candidate_exit_code']) for r in comparison])
