#!/usr/bin/env python3
import gzip,hashlib,io,json,tarfile
from pathlib import Path
Q=Path(__file__).resolve().parent;R=Path('/home/tim/Documents/GitHub/workspace/hyperreal');O=Q/'metadata-consumers/hypercurve-release';D=R/'benchmarks/checkpoints'
rows=json.loads((O/'runs.json').read_text());inputs=json.loads((O/'inputs.json').read_text());restoration=json.loads((O/'restoration.json').read_text())
assert len(rows)==14 and restoration['pinned_hypercurve_clean'] and restoration['pinned_hypercurve_inputs_unchanged']
for label in ['baseline','candidate']:
 selected=[r for r in rows if r['label']==label];assert len(selected)==7 and sum(r['exit_code']==124 for r in selected)==6 and sum(r['exit_code']==101 for r in selected)==1
 log=(O/label/'isolated-6.log').read_text();assert 'retained mixed fillet must re-enter the Boolean kernel' in log and 'reason: Predicate' in log
files=[(p,str(p.relative_to(Q))) for p in O.rglob('*') if p.is_file()]+[(Q/'qualify_metadata_hypercurve.py','drivers/qualify_metadata_hypercurve.py'),(Q/'preserve_metadata_hypercurve.py','drivers/preserve_metadata_hypercurve.py')]
archive=D/'2026-09-17-verus-hypercurve-metadata-partition.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as tar:
   for p,name in sorted(files,key=lambda pair:pair[1]):
    data=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
report={'schema':1,'status':'pinned_consumer_failures_preserved_not_acceptance','baseline':inputs['revisions']['baseline'],'candidate':inputs['revisions']['candidate'],'hypercurve_pin':inputs['hypercurve_pin'],'commands':14,'each_revision':{'remaining_suite_timeout_seconds':900,'isolated_case_timeouts':5,'isolated_case_timeout_seconds':120,'isolated_failure':'retained_rational_arc_and_analytic_parallel_fillet_exactly: Boolean RationalBezier predicate blocker','completed_passing_commands':0},'limits':['Timeouts and failures remain unsuccessful outcomes. Partial test passes do not establish a complete release-suite pass.','These runs concern cdc6d3a; qualification of the later certified-precision and bound-composition runtime is separate.','Durations include non-native validation under host load and are not performance comparisons.','Only the pinned temporary Hypercurve snapshot was used. The live concurrently edited checkout was never changed.'],'restoration':restoration,'artifact':{'path':str(archive.relative_to(R)),'bytes':archive.stat().st_size,'files':len(files),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}}
(D/'2026-09-17-verus-hypercurve-metadata-partition.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report['artifact']))
