#!/usr/bin/env python3
"""Qualify pinned Hypercurve cases with explicit per-case timeout outcomes.

Run only after native timing has finished and the consumer source/target are
idle. Only the existing pinned temporary consumer checkout is used.
"""
import hashlib, json, os, subprocess, time
from pathlib import Path

Q = Path(__file__).resolve().parent
C = json.loads((Q / 'run.json').read_text())
S = Q / 'consumer-source'
CURVE = Q / 'hypercurve'
O = Q / 'metadata-consumers/hypercurve-release'
REVISIONS = {'baseline': C['baseline'], 'candidate': 'cdc6d3a74fd2240f8037efe218c9ea424fd4e501'}
PIN = '8228394f174be2ae607694682defb167f030f540'
ENV = C['environment'] | {'CARGO_TARGET_DIR': str(Q / 'consumer-target'),
    'CCACHE_DISABLE': '1', 'CARGO_BUILD_JOBS': '4', 'CARGO_NET_OFFLINE': 'true',
    'HYPERCURVE_SKIP_BENCHMARK_REPORTS': '1'}
SLOW = [
    'bezier_offset::conversion_tests::selected_parallel_normal_circle_intersects_genuinely_analytic_parallel_in_one_fiber',
    'bezier_region::tests::independent_oblique_chord_pair_fillets_extend_on_infinite_supports',
    'bezier_region::tests::pair_native_boolean_algebraic_chord_corner_publishes_a_third_generation_fillet',
    'bezier_region::tests::selected_circle_and_analytic_parallel_extend_on_full_supports',
    'radical_parallel_cusp_offsets_exactly_under_both_policies',
    'retained_rational_arc_and_analytic_parallel_fillet_exactly',
]
def git(root, *args): return subprocess.check_output(['git', *args], cwd=root, text=True).strip()
def hashes(root):
    names = subprocess.check_output(['git', 'ls-files', '-z'], cwd=root).decode().split('\0')
    return {n: hashlib.sha256((root / n).read_bytes()).hexdigest() for n in names if n and (root / n).is_file()}

assert not git(S, 'status', '--porcelain') and not git(CURVE, 'status', '--porcelain')
assert git(CURVE, 'rev-parse', 'HEAD') == PIN
original = git(S, 'rev-parse', 'HEAD')
inputs = hashes(CURVE)
O.mkdir()
(O / 'inputs.json').write_text(json.dumps({'revisions': REVISIONS, 'hypercurve_pin': PIN,
    'hypercurve_files': inputs, 'compiler': C['compiler'], 'environment': ENV,
    'case_partition': {'remaining_suite_skips': SLOW, 'isolated_cases': SLOW},
    'limit': 'A timeout, ignored test or failed command is not a pass. Durations are not native timing comparisons.'}, indent=2) + '\n')
records = []
try:
    for label, revision in REVISIONS.items():
        subprocess.run(['git', 'checkout', '--detach', revision], cwd=S, check=True)
        common = ['cargo', 'test', '--locked', '--release', '--all-features']
        remaining = common + ['--no-fail-fast', '--', '--test-threads=2']
        for name in SLOW: remaining += ['--skip', name]
        jobs = [('remaining-suite', remaining, 900)]
        for index, name in enumerate(SLOW, 1):
            target = ['--lib'] if '::' in name else ['--test', 'hypercurve_analytic_parallel_region']
            jobs.append(('isolated-' + str(index), common + target + [name, '--', '--exact', '--nocapture', '--test-threads=1'], 120))
        for step, command, limit in jobs:
            folder = O / label; folder.mkdir(exist_ok=True)
            actual = ['timeout', '--signal=TERM', '--kill-after=10s', str(limit) + 's', *command]
            started = time.time()
            with (folder / (step + '.log')).open('w') as log:
                result = subprocess.run(actual, cwd=CURVE, env=os.environ | ENV, stdout=log, stderr=subprocess.STDOUT)
            records.append({'label': label, 'runtime_revision': revision, 'consumer_revision': PIN,
                'step': step, 'command': actual, 'cwd': str(CURVE), 'environment': ENV,
                'exit_code': result.returncode, 'timeout_seconds': limit, 'seconds': time.time() - started})
            (O / 'runs.json').write_text(json.dumps(records, indent=2) + '\n')
            print(label, step, result.returncode, round(time.time() - started, 1), flush=True)
finally:
    subprocess.run(['git', 'checkout', '--detach', original], cwd=S, check=True)
    assert not git(S, 'status', '--porcelain') and not git(CURVE, 'status', '--porcelain')
    assert hashes(CURVE) == inputs and git(CURVE, 'rev-parse', 'HEAD') == PIN
    (O / 'restoration.json').write_text(json.dumps({'hyperreal_revision': original,
        'pinned_hypercurve_clean': True, 'pinned_hypercurve_inputs_unchanged': True}, indent=2) + '\n')
raise SystemExit(any(row['exit_code'] for row in records))
