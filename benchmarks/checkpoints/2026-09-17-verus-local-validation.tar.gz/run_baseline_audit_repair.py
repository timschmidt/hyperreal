#!/usr/bin/env python3
"""Supplement the untouched baseline results with its missing API classification."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

ROOT = Path(__file__).resolve().parent
CONFIG = json.loads((ROOT / "run.json").read_text())
SOURCE = Path(CONFIG["source"])
ENV = os.environ | CONFIG["environment"]
DIRECTORY = ROOT / "baseline-audit-repair"
DIRECTORY.mkdir()
RESULTS = []
TEST = "tests/gmp_api_coverage.rs"
subprocess.run(["git", "checkout", "--detach", CONFIG["baseline"]], cwd=SOURCE, check=True)
original = (SOURCE / TEST).read_bytes()
repaired = subprocess.check_output(["git", "show", CONFIG["candidate"] + ":" + TEST], cwd=SOURCE)
assert repaired == original.replace(b'    "exact_rational",\n',
    b'    "exact_rational",\n    "exact_quadratic_normal_form",\n', 1)
(SOURCE / TEST).write_bytes(repaired)
patch = subprocess.check_output(["git", "diff", "--", TEST], cwd=SOURCE)
(DIRECTORY / "classification-only.patch").write_bytes(patch)
try:
    for name, command, extra in [
        ("tests-default", ["cargo", "test", "--locked", "--all-targets", "--no-fail-fast"], {}),
        ("tests-all", ["cargo", "test", "--locked", "--all-features", "--all-targets", "--no-fail-fast"], {}),
        ("coverage-matrix", ["bash", "scripts/coverage.sh"], {"CARGO_TARGET_DIR": str(ROOT / "coverage-target")}),
    ]:
        log = DIRECTORY / (name + ".log")
        started = time.time()
        with log.open("w") as output:
            result = subprocess.run(command, cwd=SOURCE, env=ENV | extra,
                stdout=output, stderr=subprocess.STDOUT)
        RESULTS.append({"name": name, "command": command, "environment_overrides": extra,
            "exit_code": result.returncode, "start_unix": started, "seconds": time.time() - started,
            "log": str(log), "sha256": hashlib.sha256(log.read_bytes()).hexdigest()})
        (DIRECTORY / "results.json").write_text(json.dumps({
            "production_revision": CONFIG["baseline"], "test_overlay": TEST,
            "overlay_sha256": hashlib.sha256(patch).hexdigest(),
            "classification": "Supplementary baseline with only the missing no-GMP-analog inventory entry; original failures retained separately",
            "results": RESULTS}, indent=2) + "\n")
        print("baseline-audit-repair", name, result.returncode, round(time.time() - started, 1), flush=True)
        if name == "coverage-matrix" and (ROOT / "coverage-target/html").exists():
            shutil.copytree(ROOT / "coverage-target/html", DIRECTORY / "coverage-html")
finally:
    (SOURCE / TEST).write_bytes(original)
    subprocess.run(["git", "checkout", "--detach", CONFIG["candidate"]], cwd=SOURCE, check=True)
raise SystemExit(any(r["exit_code"] for r in RESULTS))
