#!/usr/bin/env python3
"""Replay every saved corpus and run each existing sanitizer fuzz target."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

ROOT = Path(__file__).resolve().parent
CONFIG = json.loads((ROOT / "run.json").read_text())
SOURCE = ROOT / "fuzz-source"
ENV = os.environ | CONFIG["environment"] | {"CCACHE_DISABLE": "1"}
FUZZ_TARGET = ROOT / "fuzz-target"
TARGETS = ["rational_arithmetic", "real_exact", "real_elementary",
           "computable_approximation", "structural_representations", "string_parsing"]
RESULTS = []

for label in ["baseline", "candidate"]:
    subprocess.run(["git", "checkout", "--detach", CONFIG[label]], cwd=SOURCE, check=True)
    for target in TARGETS:
        folder = ROOT / label / "fuzz" / target
        folder.mkdir(parents=True)
        shutil.copytree(SOURCE / "fuzz/corpus" / target, folder / "corpus")
        (folder / "artifacts").mkdir()
        command = ["cargo", "+nightly", "fuzz", "run", target, str(folder / "corpus"),
            "--fuzz-dir", "fuzz", "--target-dir", str(FUZZ_TARGET), "--",
            "-runs=1000", "-timeout=10", "-seed=93537",
            "-max_len=" + ("256" if target == "string_parsing" else "64"),
            "-artifact_prefix=" + str(folder / "artifacts") + "/"]
        env = ENV.copy()
        for attempt in [1, 2]:
            started = time.time()
            log = folder / ("run.log" if attempt == 1 else "lsan-disabled-run.log")
            with log.open("w") as output:
                result = subprocess.run(command, cwd=SOURCE, env=env,
                    stdout=output, stderr=subprocess.STDOUT)
            contents = log.read_text()
            RESULTS.append({"label": label, "revision": CONFIG[label], "target": target,
                "command": command, "attempt": attempt, "exit_code": result.returncode,
                "start_unix": started, "seconds": time.time() - started, "log": str(log),
                "sha256": hashlib.sha256(log.read_bytes()).hexdigest(),
                "sanitizer": "address", "ASAN_OPTIONS": env.get("ASAN_OPTIONS"),
                "LSAN_OPTIONS": env.get("LSAN_OPTIONS")})
            (ROOT / "fuzz-results.json").write_text(json.dumps(RESULTS, indent=2) + "\n")
            print(label, target, attempt, result.returncode, round(time.time() - started, 1), flush=True)
            # Only suppress the unavailable ptrace-dependent leak checker after
            # its diagnostic is observed. Keep AddressSanitizer instrumentation.
            if result.returncode and attempt == 1 and "LeakSanitizer does not work under ptrace" in contents:
                env["ASAN_OPTIONS"] = env.get("ASAN_OPTIONS", "") + ":detect_leaks=0"
                continue
            break
    status = subprocess.check_output(["git", "status", "--porcelain"], cwd=SOURCE, text=True)
    (ROOT / label / "fuzz/worktree-status.txt").write_text(status)
    if status:
        raise RuntimeError("Fuzzing changed checkout sources: " + status)

latest = {(r["label"], r["target"]): r for r in RESULTS}
raise SystemExit(any(r["exit_code"] for r in latest.values()))
