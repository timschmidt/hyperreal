#!/usr/bin/env python3
"""Run the existing local validation matrix in the matched comparison checkout."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

ROOT = Path(__file__).resolve().parent
CONFIG = json.loads((ROOT / "run.json").read_text())
SOURCE = Path(CONFIG["source"])
ENV = os.environ | CONFIG["environment"]
RESULTS = []


def run(label, name, command, extra=None):
    directory = ROOT / label / "validation"
    directory.mkdir(exist_ok=True)
    log = directory / (name + ".log")
    started = time.time()
    with log.open("w") as output:
        result = subprocess.run(command, cwd=SOURCE, env=ENV | (extra or {}),
                                stdout=output, stderr=subprocess.STDOUT)
    RESULTS.append({"revision": CONFIG[label], "label": label, "name": name,
                    "command": command, "environment_overrides": extra or {},
                    "exit_code": result.returncode, "start_unix": started,
                    "seconds": time.time() - started, "log": str(log),
                    "sha256": hashlib.sha256(log.read_bytes()).hexdigest()})
    (ROOT / "validation.json").write_text(json.dumps(RESULTS, indent=2) + "\n")
    print(label, name, result.returncode, round(time.time() - started, 1), flush=True)
    return result.returncode


for label in ["baseline", "candidate"]:
    subprocess.run(["git", "checkout", "--detach", CONFIG[label]], cwd=SOURCE, check=True)
    checks = [
        ("fmt", ["cargo", "fmt", "--all", "--", "--check"], {}),
        ("check-default", ["cargo", "check", "--locked", "--all-targets"], {}),
        ("tests-default", ["cargo", "test", "--locked", "--all-targets"], {}),
        ("clippy-default", ["cargo", "clippy", "--locked", "--all-targets", "--", "-D", "warnings"], {}),
        ("check-all", ["cargo", "check", "--locked", "--all-features", "--all-targets"], {}),
        ("tests-all", ["cargo", "test", "--locked", "--all-features", "--all-targets"], {}),
        ("clippy-all", ["cargo", "clippy", "--locked", "--all-features", "--all-targets", "--", "-D", "warnings"], {}),
        ("doc-tests-default", ["cargo", "test", "--locked", "--doc"], {}),
        ("doc-tests-all", ["cargo", "test", "--locked", "--all-features", "--doc"], {}),
        ("rustdoc-all", ["cargo", "doc", "--locked", "--all-features", "--no-deps"], {"RUSTDOCFLAGS": "-D warnings"}),
        ("representation-matrix", ["bash", "scripts/representation_coverage.sh"], {}),
        ("fuzz-check", ["cargo", "check", "--locked", "--manifest-path", "fuzz/Cargo.toml", "--bins"], {"CCACHE_DISABLE": "1"}),
        ("wasm-default", ["cargo", "build", "--locked", "--release", "--target", "wasm32-unknown-unknown", "--no-default-features", "--lib"], {}),
        ("wasm-all", ["cargo", "build", "--locked", "--release", "--target", "wasm32-unknown-unknown", "--all-features", "--lib", "--bins"], {}),
        ("coverage-matrix", ["bash", "scripts/coverage.sh"], {"CARGO_TARGET_DIR": str(ROOT / "coverage-target")}),
    ]
    for name, command, extra in checks:
        run(label, name, command, extra)
        if name == "wasm-all":
            binary = Path(CONFIG["target"]) / "wasm32-unknown-unknown/release/hyperreal.wasm"
            if binary.exists():
                shutil.copy2(binary, ROOT / label / "bin/hyperreal.wasm")
        if name == "coverage-matrix":
            reports = ROOT / "coverage-target/html"
            if reports.exists():
                shutil.copytree(reports, ROOT / label / "coverage-html")
    status = subprocess.check_output(["git", "status", "--porcelain"], cwd=SOURCE, text=True)
    (ROOT / label / "validation/worktree-status.txt").write_text(status)
    if status:
        raise RuntimeError("Validation changed tracked or untracked sources: " + status)

raise SystemExit(any(r["exit_code"] for r in RESULTS))
