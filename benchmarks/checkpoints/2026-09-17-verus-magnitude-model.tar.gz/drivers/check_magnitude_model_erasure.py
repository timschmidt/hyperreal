import hashlib,json,os,subprocess
from pathlib import Path
q=Path(__file__).resolve().parent;repo=Path('/home/tim/Documents/GitHub/workspace/hyperreal');source=q/'source';out=q/'magnitude-model-proof'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()=='ee773bbf4a158bbf4b09134f99dff3a3e45421d8'
p=source/'src/verified/word.rs';original=p.read_bytes();p.write_bytes((repo/'src/verified/word.rs').read_bytes())
try:
 env=json.loads((q/'run.json').read_text())['environment']|{'CARGO_TARGET_DIR':str(q/'expansion-target'),'CARGO_NET_OFFLINE':'true','CARGO_BUILD_JOBS':'4','CCACHE_DISABLE':'1'}
 command=['cargo','+nightly','rustc','--locked','--lib','--no-default-features','--','-Zunpretty=expanded']
 with (out/'expanded-runtime.rs').open('w') as stdout,(out/'expanded-runtime.stderr').open('w') as stderr:
  r=subprocess.run(command,cwd=source,env=os.environ|env,stdout=stdout,stderr=stderr)
 assert r.returncode==0
 baseline=q/'magnitude-range-complete/expanded-runtime.rs';candidate=out/'expanded-runtime.rs'
 record={'runtime_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip(),'command':command,'cwd':str(source),'environment':env,'exit_code':r.returncode,'word_source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'baseline_sha256':hashlib.sha256(baseline.read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256(candidate.read_bytes()).hexdigest(),'byte_identical':baseline.read_bytes()==candidate.read_bytes(),'note':'Only production diff is ghost specification extraction. New verification-only magnitude module is outside normal Cargo compilation.'}
 (out/'erasure.json').write_text(json.dumps(record,indent=2)+'\n');assert record['byte_identical'];print(record)
finally:
 p.write_bytes(original)
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True)
