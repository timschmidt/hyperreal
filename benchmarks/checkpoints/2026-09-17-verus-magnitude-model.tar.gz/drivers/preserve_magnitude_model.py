#!/usr/bin/env python3
"""Retain the complete magnitude proof, rejection checks and runtime erasure."""
import gzip,hashlib,io,json,subprocess,tarfile
from pathlib import Path
Q=Path(__file__).resolve().parent;REPO=Path('/home/tim/Documents/GitHub/workspace/hyperreal');OUT=Q/'magnitude-model-proof';DEST=REPO/'benchmarks/checkpoints'
revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()
evidence=json.loads((REPO/'target/verification/evidence.json').read_text())
assert evidence['verification_results']['verified']==395 and evidence['verification_results']['success']
assert len(evidence['scope']['verified_model_theorems'])==71
for name,expected in evidence['sources'].items():
 data=subprocess.check_output(['git','show',revision+':'+name],cwd=REPO)
 assert hashlib.sha256(data).hexdigest()==expected,(revision,name)
assert (OUT/'rejections.log').read_text().count('Rejected incorrect ')==79
assert 'Rejected attempted assumption bypass' in (OUT/'rejections.log').read_text()
assert 'Ran 7 tests' in (OUT/'acceptance-tests.log').read_text() and '\nOK\n' in (OUT/'acceptance-tests.log').read_text()
erasure=json.loads((OUT/'erasure.json').read_text());assert erasure['byte_identical']
files=[(p,str(p.relative_to(OUT))) for p in OUT.rglob('*') if p.is_file()]
files.extend((REPO/'target/verification'/name,'official/'+name) for name in ['verus.json','verus.stderr','evidence.json'])
files.extend((Q/name,'drivers/'+name) for name in ['check_magnitude_model_erasure.py','preserve_magnitude_model.py'])
files.append((REPO/'verification/magnitude_model.rs','magnitude_model.rs'))
files.append((Q/'magnitude_model_draft.rs','initial-draft-final-state.rs'))
archive=DEST/'2026-09-17-verus-magnitude-model.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as zipped:
  with tarfile.open(fileobj=zipped,mode='w') as tar:
   for path,name in sorted(files,key=lambda row:row[1]):
    data=path.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
report={'schema':1,'status':'proof_milestone_not_acceptance','baseline':'a2da8e2b5de9a1a4653d3662f2f05cb6533fd7ef','proof_revision':revision,'runtime_revision':erasure['runtime_revision'],
 'verification':{'units':395,'executable_contracts':55,'model_theorems':71,'source_hashes':len(evidence['sources']),'source_hashes_match_commit':True,'entire_proof_target':True,'no_cheating':True},
 'new_model_theorems':[n for n in evidence['scope']['verified_model_theorems'] if n.startswith('magnitude_model::')],
 'rejections':{'incorrect_executables':77,'incorrect_magnitude_definitions':2,'assumption_bypass_rejected':True,'acceptance_guard_tests':7},'erasure':erasure,
 'limits':['All13full-implementation obligation groups remain open.','The rational magnitude model requires correct mathematical bit lengths and aligned comparisons; the BigUint caller and dependency refinement remain unproved.','These are proof-only changes; runtime equality is established by the matched normal-Rust expansion. Existing current-runtime timing, resource and consumer assessment items remain pending.','Initial typing, algebraic-proof and visibility failures are retained as failures, not qualifying evidence.'],
 'artifact':{'path':str(archive.relative_to(REPO)),'bytes':archive.stat().st_size,'files':len(files),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}}
(DEST/'2026-09-17-verus-magnitude-model.json').write_text(json.dumps(report,indent=2)+'\n');print(report['artifact'])
