import gzip,hashlib,io,json,re,tarfile
from pathlib import Path
Q=Path(__file__).resolve().parent;REPO=Path('/home/tim/Documents/GitHub/workspace/hyperreal');DEST=REPO/'benchmarks/checkpoints'
files=[];profiles=[]
for name in ['magnitude-peak-attribution','magnitude-peak-attribution-v2']:
 folder=Q/name;runs=json.loads((folder/'runs.json').read_text());assert len(runs)==2 and all(r['exit_code']==0 for r in runs)
 for p in folder.rglob('*'):
  if p.is_file():files.append((p,name+'/'+str(p.relative_to(folder))))
 for label in ['baseline','candidate']:
  p=folder/label/'massif.out';s=p.read_text();m=re.search(r'mem_heap_B=(\d+)\nmem_heap_extra_B=(\d+)\nmem_stacks_B=(\d+)\nheap_tree=peak',s);assert m
  values=list(map(int,m.groups()));profiles.append({'configuration':name,'label':label,'heap':values[0],'allocator_extra':values[1],'stack':values[2],'combined_peak':sum(values),'profile_sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
for name in ['profile_magnitude_peak_attribution.py','profile_magnitude_peak_attribution_v2.py','preserve_magnitude_peak.py']:files.append((Q/name,'drivers/'+name))
groups=json.loads((Q/'magnitude-peak-attribution-v2/immediate-groups.json').read_text());delta=[{'caller':n,'baseline_bytes':groups['baseline'].get(n,0),'candidate_bytes':groups['candidate'].get(n,0),'delta_bytes':groups['candidate'].get(n,0)-groups['baseline'].get(n,0)} for n in sorted(set(groups['baseline'])|set(groups['candidate']))];assert sum(r['delta_bytes'] for r in delta)==160
archive=DEST/'2026-09-17-verus-magnitude-peak.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as zipped:
  with tarfile.open(fileobj=zipped,mode='w') as tar:
   for p,n in sorted(files,key=lambda x:x[1]):
    data=p.read_bytes();info=tarfile.TarInfo(n);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
report={'schema':1,'status':'peak_attribution_not_acceptance','baseline':'a2da8e2b5de9a1a4653d3662f2f05cb6533fd7ef','candidate':'ee773bbf4a158bbf4b09134f99dff3a3e45421d8','native_timing':False,'profiles':profiles,'immediate_allocation_caller_groups':delta,
 'method':'Same executablepath/argv/cwd/environment. Bounded10snapshots,detailedfreq1000,depth24,zeropeakinaccuracy. Firstthreshold0.1profilegroupedsmallallocations;secondthreshold0profileattributesallpeakheapbytes.',
 'finding':'The160byteheapincrease decomposes into112bytes allocated throughApproximationCache::store and48bytes throughComputable::approx_signal. Allocatorbookkeeping increases16bytes;stackpeak isunchanged.',
 'limits':['Allocationcaller attribution doesnot byitself isolatewhichsourcechange changedlifetime.','Whole-processpeak includeswarmupandprocesscaches. Per-casemeasurements subtractthewarmedstartinglive-bytecount andarenotabsoluteprocesspeaks.','The176bytecombinedincrease remains a resourceassessmentitem. Full memoryparity isnotestablished.'],
 'artifact':{'path':str(archive.relative_to(REPO)),'bytes':archive.stat().st_size,'files':len(files),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}}
(DEST/'2026-09-17-verus-magnitude-peak.json').write_text(json.dumps(report,indent=2)+'\n');print(report['artifact'])
