#!/usr/bin/env python3
"""Attribute the already-reproduced peak delta using a bounded detailed trace."""
import hashlib,json,os,shutil,subprocess,time
from pathlib import Path
Q=Path(__file__).resolve().parent;CONFIG=json.loads((Q/'run.json').read_text());OUT=Q/'magnitude-peak-attribution-v2';RUNTIME=Q/'magnitude-profile-runtime'
OUT.mkdir();RUNTIME.mkdir(exist_ok=True);EXE=RUNTIME/'allocation_profile';PROFILE=RUNTIME/'massif.out';records=[]
for label in ['baseline','candidate']:
 source=Q/('baseline' if label=='baseline' else 'magnitude-range-complete')/'bin/allocation_profile';folder=OUT/label;folder.mkdir();shutil.copy2(source,EXE)
 command=['valgrind','--tool=massif','--stacks=yes','--time-unit=B','--detailed-freq=1000','--max-snapshots=10','--peak-inaccuracy=0','--threshold=0','--depth=24','--massif-out-file='+str(PROFILE),str(EXE),'64']
 started=time.time()
 with (folder/'run.log').open('w') as log:r=subprocess.run(command,cwd=RUNTIME,env=os.environ|CONFIG['environment'],stdout=log,stderr=subprocess.STDOUT)
 if PROFILE.exists():PROFILE.rename(folder/'massif.out')
 records.append({'label':label,'command':command,'cwd':str(RUNTIME),'environment':CONFIG['environment'],'exit_code':r.returncode,'native_timing':False,'seconds':time.time()-started,'binary_sha256':hashlib.sha256(EXE.read_bytes()).hexdigest()});(OUT/'runs.json').write_text(json.dumps(records,indent=2)+'\n');print(label,r.returncode,round(time.time()-started,1),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
 with (folder/'summary.txt').open('w') as log:subprocess.run(['ms_print',str(folder/'massif.out')],stdout=log,stderr=subprocess.STDOUT,check=True)
