use hyperreal::{MagnitudeBits, Rational, Real};
use num::BigInt;

fn main() {
    let exponent: i32 = std::env::args().nth(1).expect("exponent").parse().unwrap();
    assert!(exponent >= 0);
    let rational = Rational::from_bigint(BigInt::from(1) << exponent as usize);
    let actual = Real::new(rational).structural_facts().magnitude;
    let expected = Some(MagnitudeBits { msd: exponent, exact_msd: true });
    println!("exponent={exponent}, expected={expected:?}, actual={actual:?}");
    assert_eq!(actual, expected);
}
