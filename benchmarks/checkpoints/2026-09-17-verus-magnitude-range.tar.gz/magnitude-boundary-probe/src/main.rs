use hyperreal::{MagnitudeBits, Rational, Real};
use num::{BigInt, BigUint};

fn main() {
    let exponent: i64 = std::env::args().nth(1).expect("exponent").parse().unwrap();
    let kind = std::env::args().nth(2).unwrap_or_else(|| "plain".into());
    let rational = if exponent >= 0 {
        Rational::from_bigint(BigInt::from(1) << exponent as usize)
    } else {
        Rational::from_bigint_fraction(BigInt::from(1), BigUint::from(1_u8) << exponent.unsigned_abs() as usize).unwrap()
    };
    let (value, expected_exponent) = match kind.as_str() {
        "plain" => (Real::new(rational), exponent),
        "pi" => (Real::new(rational) * Real::pi(), exponent + 1),
        _ => panic!("unknown kind"),
    };
    let actual = value.structural_facts().magnitude;
    let expected = i32::try_from(expected_exponent).ok().map(|msd| MagnitudeBits { msd, exact_msd: true });
    println!("exponent={exponent}, kind={kind}, expected={expected:?}, actual={actual:?}");
    assert_eq!(actual, expected);
}
