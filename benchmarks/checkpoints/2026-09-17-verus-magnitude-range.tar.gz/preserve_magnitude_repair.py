#!/usr/bin/env python3
"""Archive the magnitude-range repair, baseline counterexamples and proofs."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

Q = Path(__file__).resolve().parent
REPO = Path('/home/tim/Documents/GitHub/workspace/hyperreal')
DEST = REPO / 'benchmarks/checkpoints'
TRIAL = Q / 'bit-length-proof-trial'
PROBE = Q / 'magnitude-boundary-probe'
qualification = json.loads((TRIAL / 'qualification.json').read_text())
proof = json.loads((TRIAL / 'official-proof/evidence.json').read_text())
checks = json.loads((TRIAL / 'root-validation/runs.json').read_text())
fuzz = json.loads((Q / 'magnitude-range-fuzz/runs.json').read_text())
builds = json.loads((Q / 'magnitude-range-candidate/builds.json').read_text())
debug = json.loads((PROBE / 'pinned/runs.json').read_text())
fixed = json.loads((PROBE / 'fixed/runs.json').read_text())
release = json.loads((PROBE / 'release-comparison/runs.json').read_text())
assert all(r['exit_code'] == 0 for r in checks + fuzz + builds + fixed)
assert len(checks) == 5 and len(fuzz) == 6 and sum(r['corpus_files'] for r in fuzz) == 6492
assert [r['exit_code'] for r in debug] == [0, 101, 0, 101]
assert [r['exit_code'] for r in release] == [0, 101, 101, 0, 0, 0]
assert len(fixed) == 5 and 'actual=Some(MagnitudeBits { msd: 2147483647, exact_msd: true })' in (PROBE / 'fixed-max.stdout').read_text()
mutations = (TRIAL / 'all-mutations.log').read_text()
assert mutations.count('Rejected incorrect') == 77 and mutations.count('Rejected attempted assumption bypass') == 1
assert proof['verification_results']['verified'] == 375 and proof['verification_results']['success']
for name, digest in proof['sources'].items():
    assert hashlib.sha256((REPO / name).read_bytes()).hexdigest() == digest, name
for run in release:
    if run['label'] == 'fixed':
        assert all(hashlib.sha256((REPO / name).read_bytes()).hexdigest() == digest for name, digest in run['source_sha256'].items())
files = set()
for folder in [TRIAL, PROBE, Q / 'magnitude-range-fuzz', Q / 'magnitude-range-candidate',
               Q / 'unit-scale-facts-experiment/reuse']:
    for path in folder.rglob('*'):
        if path.is_file() and not {'bin', 'corpus', 'target'}.intersection(path.relative_to(folder).parts) and path.name != 'probe':
            files.add(path)
files.update(Q / name for name in ['qualify_magnitude_root.py', 'replay_magnitude_corpora.py',
    'build_magnitude_candidate.py', 'probe_magnitude_boundaries.py', 'probe_release_magnitude_boundaries.py',
    'preserve_magnitude_repair.py', 'qualify_unit_scale_facts.py', 'rational_magnitude_oracle_draft.rs',
    'run.json', 'saved-corpora.json'])
files.add(Q / 'unit-scale-facts-experiment/reuse-comparison.patch')
archive = DEST / '2026-09-17-verus-magnitude-range.tar.gz'
with archive.open('wb') as output:
    with gzip.GzipFile(fileobj=output, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for path in sorted(files):
                data = path.read_bytes()
                info = tarfile.TarInfo(str(path.relative_to(Q)))
                info.size = len(data)
                info.mode = 0o644
                tar.addfile(info, io.BytesIO(data))
report = {'schema': 1, 'status': 'exactness_repair_not_final_acceptance',
    'baseline': qualification['baseline'], 'candidate': qualification['revision'],
    'problem': 'Bit lengths were narrowed before subtraction, and real binade indices were added without checking their combined range. Debug builds could panic; release builds could certify an incorrect exponent.',
    'repair': 'Retain full-width bit lengths and alignment shifts, reuse the shifted comparison for the binary-scale certificate, and apply the computable offset before checked i32 conversion. Return no magnitude when the final exponent cannot fit.',
    'verification_units': 375, 'production_contracts': 55, 'model_theorems': 66, 'open_groups': 13,
    'no_cheating': True, 'source_hashes': proof['sources'], 'validation': checks,
    'test_metrics': qualification['tests'], 'mutation_rejections': 77, 'assumption_bypass_rejected': True,
    'frozen_asan_inputs': 6492, 'fuzz_runs': fuzz, 'matched_builds': builds,
    'baseline_debug_probes': debug, 'fixed_additional_debug_probes': fixed, 'release_probes': release,
    'fixed_initial_debug_probe': {'exponent': 2147483647, 'exit_code': 0, 'stdout': 'magnitude-boundary-probe/fixed-max.stdout'},
    'limits': [
        'The full source, caller and dependency proof remains incomplete. The integer range calculation is proved; BigUint refinement and complete real-magnitude semantics remain open.',
        'The first exploratory probe resolved newer num dependencies. It is retained separately; the baseline/current comparisons use the repository pins, including num-bigint 0.4.6.',
        'Large boundary probes allocate roughly 256 MiB for each value. Their recorded durations are correctness-run metadata, not native performance measurements.',
        'The initial mutation invocation stopped before verification because formatting changed a textual anchor. Its failure is retained; the corrected full run rejects all 77 defects and the assumption bypass.',
        'The earlier comparison-reuse overlay passed its smaller tests but retained the range defect. Its records are preserved as an unadopted intermediate, not final qualification.',
        'Matched executables are built. Full native timing, resource/size/coverage and current downstream qualification remain pending.',
        'Live Hypercurve was neither edited nor used for these checks.'],
    'artifact': {'path': str(archive.relative_to(REPO)), 'bytes': archive.stat().st_size,
                 'files': len(files), 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()}}
(DEST / '2026-09-17-verus-magnitude-range.json').write_text(json.dumps(report, indent=2) + '\n')
print(report['artifact'])
