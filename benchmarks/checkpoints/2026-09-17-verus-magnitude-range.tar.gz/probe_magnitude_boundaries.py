#!/usr/bin/env python3
"""Repeat the large-magnitude diagnostic on pinned source and dependency inputs."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

Q = Path(__file__).resolve().parent
REPO = Path('/home/tim/Documents/GitHub/workspace/hyperreal')
SOURCE = Q / 'consumer-source'
PROBE = Q / 'magnitude-boundary-probe'
OUT = PROBE / 'pinned'
OUT.mkdir()
initial = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=SOURCE, text=True).strip()
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=SOURCE, text=True)
ENV = json.loads((Q / 'run.json').read_text())['environment'] | {
    'CARGO_TARGET_DIR': str(Q / 'boundary-target'), 'CARGO_BUILD_JOBS': '2', 'CCACHE_DISABLE': '1'}
records = []
try:
    for label, revision in [('baseline', 'a2da8e2b5de9a1a4653d3662f2f05cb6533fd7ef'),
                            ('candidate', 'da3a6fdac3809f76c6434742f7f84bafb9b666b9')]:
        subprocess.run(['git', 'checkout', '--detach', revision], cwd=SOURCE, check=True)
        shutil.copy2(SOURCE / 'Cargo.lock', PROBE / 'Cargo.lock')
        for exponent in [31, 2147483647]:
            command = ['cargo', 'run', '--offline', '--', str(exponent)]
            start = time.time()
            with (OUT / f'{label}-{exponent}.stdout').open('w') as output, (OUT / f'{label}-{exponent}.stderr').open('w') as error:
                result = subprocess.run(command, cwd=PROBE, env=os.environ | ENV, stdout=output, stderr=error)
            record = {'label': label, 'revision': revision, 'exponent': exponent, 'command': command,
                      'cwd': str(PROBE), 'environment': ENV, 'exit_code': result.returncode,
                      'seconds': time.time() - start,
                      'source_sha256': hashlib.sha256((SOURCE / 'src/rational/arithmetic/queries_conversion.rs').read_bytes()).hexdigest(),
                      'lock_sha256': hashlib.sha256((PROBE / 'Cargo.lock').read_bytes()).hexdigest()}
            records.append(record)
            pending = OUT / 'runs.next.json'
            pending.write_text(json.dumps(records, indent=2) + '\n')
            pending.replace(OUT / 'runs.json')
            shutil.copy2(PROBE / 'Cargo.lock', OUT / f'{label}-{exponent}.Cargo.lock')
            print(label, exponent, result.returncode, round(time.time() - start, 1), flush=True)
finally:
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=SOURCE, text=True)
    subprocess.run(['git', 'checkout', '--detach', initial], cwd=SOURCE, check=True)
