#!/usr/bin/env python3
"""Compare release magnitude certificates on the fixed baseline and current fix."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

Q = Path(__file__).resolve().parent
REPO = Path('/home/tim/Documents/GitHub/workspace/hyperreal')
SOURCE = Q / 'consumer-source'
PROBE = Q / 'magnitude-boundary-probe'
OUT = PROBE / 'release-comparison'
OUT.mkdir()
initial = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=SOURCE, text=True).strip()
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=SOURCE, text=True)
original_manifest = (PROBE / 'Cargo.toml').read_bytes()
original_lock = (PROBE / 'Cargo.lock').read_bytes()
ENV = json.loads((Q / 'run.json').read_text())['environment'] | {
    'CARGO_TARGET_DIR': str(Q / 'boundary-target'), 'CARGO_BUILD_JOBS': '2', 'CCACHE_DISABLE': '1'}
names = ['src/verified/word.rs', 'src/rational/arithmetic/queries_conversion.rs',
         'src/rational/arithmetic/tests.rs', 'src/real/arithmetic/facts.rs', 'src/real/arithmetic/tests.rs']
originals = {}
records = []
try:
    (PROBE / 'Cargo.toml').write_text(original_manifest.decode().replace(str(REPO), '../consumer-source'))
    for label, revision in [('baseline', 'a2da8e2b5de9a1a4653d3662f2f05cb6533fd7ef'), ('fixed', 'd9c7d3f')]:
        subprocess.run(['git', 'checkout', '--detach', revision], cwd=SOURCE, check=True)
        if label == 'fixed':
            originals = {name: (SOURCE / name).read_bytes() for name in names}
            for name in names:
                (SOURCE / name).write_bytes((REPO / name).read_bytes())
            (OUT / 'fixed-change.patch').write_bytes(subprocess.check_output(['git', 'diff'], cwd=SOURCE))
        shutil.copy2(SOURCE / 'Cargo.lock', PROBE / 'Cargo.lock')
        for exponent, kind in [(2147483647, 'plain'), (2147483648, 'plain'), (-2147483649, 'pi')]:
            command = ['cargo', 'run', '--offline', '--release', '--', str(exponent), kind]
            start = time.time()
            with (OUT / f'{label}-{exponent}-{kind}.stdout').open('w') as output, (OUT / f'{label}-{exponent}-{kind}.stderr').open('w') as error:
                result = subprocess.run(command, cwd=PROBE, env=os.environ | ENV, stdout=output, stderr=error)
            records.append({'label': label, 'revision': revision, 'exponent': exponent, 'kind': kind,
                'command': command, 'cwd': str(PROBE), 'environment': ENV, 'exit_code': result.returncode,
                'seconds': time.time() - start, 'probe_sha256': hashlib.sha256((PROBE / 'src/main.rs').read_bytes()).hexdigest(),
                'source_sha256': {name: hashlib.sha256((SOURCE / name).read_bytes()).hexdigest() for name in names if (SOURCE / name).is_file()},
                'lock_sha256': hashlib.sha256((PROBE / 'Cargo.lock').read_bytes()).hexdigest()})
            pending = OUT / 'runs.next.json'
            pending.write_text(json.dumps(records, indent=2) + '\n')
            pending.replace(OUT / 'runs.json')
            shutil.copy2(PROBE / 'Cargo.lock', OUT / f'{label}.Cargo.lock')
            print(label, exponent, kind, result.returncode, round(time.time() - start, 1), flush=True)
finally:
    for name, data in originals.items():
        (SOURCE / name).write_bytes(data)
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=SOURCE, text=True)
    subprocess.run(['git', 'checkout', '--detach', initial], cwd=SOURCE, check=True)
    (PROBE / 'Cargo.toml').write_bytes(original_manifest)
    (PROBE / 'Cargo.lock').write_bytes(original_lock)
