#!/usr/bin/env python3
"""Qualify checked magnitude metadata, without running native timings."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

Q = Path(__file__).resolve().parent
REPO = Path('/home/tim/Documents/GitHub/workspace/hyperreal')
OUT = Q / 'bit-length-proof-trial/root-validation'
OUT.mkdir()
ENV = json.loads((Q / 'run.json').read_text())['environment'] | {
    'CARGO_TARGET_DIR': str(Q / 'kernel-target'), 'CARGO_BUILD_JOBS': '4',
    'CCACHE_DISABLE': '1', 'CARGO_NET_OFFLINE': 'true'}
names = subprocess.check_output(['git', 'ls-files', '-z', 'src', 'tests', 'benches', 'Cargo.toml', 'Cargo.lock'], cwd=REPO).decode().split('\0')
inputs = {name: hashlib.sha256((REPO / name).read_bytes()).hexdigest() for name in names if name}
(OUT / 'inputs.json').write_text(json.dumps(inputs, indent=2) + '\n')
(OUT / 'change.patch').write_bytes(subprocess.check_output(['git', 'diff'], cwd=REPO))
records = []
for step, command in [
    ('fmt', ['cargo', 'fmt', '--all', '--', '--check']),
    ('default-all-targets', ['cargo', 'test', '--locked', '--offline', '--all-targets', '--no-fail-fast']),
    ('all-features-all-targets', ['cargo', 'test', '--locked', '--offline', '--all-features', '--all-targets', '--no-fail-fast']),
    ('representations', ['bash', 'scripts/representation_coverage.sh']),
    ('clippy-all', ['cargo', 'clippy', '--locked', '--offline', '--all-features', '--all-targets', '--', '-D', 'warnings']),
]:
    start = time.time()
    with (OUT / (step + '.stdout')).open('w') as output, (OUT / (step + '.stderr')).open('w') as error:
        result = subprocess.run(command, cwd=REPO, env=os.environ | ENV, stdout=output, stderr=error)
    records.append({'step': step, 'command': command, 'cwd': str(REPO), 'environment': ENV,
                    'exit_code': result.returncode, 'seconds': time.time() - start})
    temporary = OUT / 'runs.next.json'
    temporary.write_text(json.dumps(records, indent=2) + '\n')
    temporary.replace(OUT / 'runs.json')
    print(step, result.returncode, round(time.time() - start, 1), flush=True)
assert all(hashlib.sha256((REPO / name).read_bytes()).hexdigest() == digest for name, digest in inputs.items())
raise SystemExit(any(r['exit_code'] for r in records))
