    #[test]
    fn rational_magnitude_certificate_matches_exact_intervals() {
        fn check(numerator: BigUint, denominator: BigUint, sign: Sign) {
            let expected = num::BigRational::new(BigInt::from(numerator.clone()), BigInt::from(denominator.clone()));
            let value = Rational::from_parts_raw_unreduced(
                if numerator.is_zero() { NoSign } else { sign }, numerator, denominator,
            );
            // The qualifier switches this expression to the proposed combined
            // helper only after checking the same oracle on the reference.
            let actual = value.msd_exact().map(|msd| (msd, value.power_of_two_shift().is_some()));
            if expected.is_zero() {
                assert_eq!(actual, None);
                return;
            }
            let (msd, power_of_two) = actual.expect("nonzero magnitude is known");
            let lower = if msd >= 0 {
                num::BigRational::from_integer(BigInt::one() << msd as usize)
            } else {
                num::BigRational::new(BigInt::one(), BigInt::one() << msd.unsigned_abs() as usize)
            };
            assert!(lower <= expected);
            assert!(expected < &lower + &lower);
            assert_eq!(power_of_two, expected == lower);
        }
        for n in 0_u8..=20 {
            for d in 1_u8..=20 {
                for sign in [Plus, Minus] {
                    check(BigUint::from(n), BigUint::from(d), sign);
                }
            }
        }
        for bits in [129_usize, 257, 1025, 2048] {
            let common = (BigUint::one() << bits) + 7_u8;
            for (n, d) in [(1_u8, 1_u8), (2, 1), (1, 2), (3, 2), (2, 3), (1, 3)] {
                for shift in [-513_i32, -65, -1, 0, 1, 65, 513] {
                    let mut numerator = &common * n;
                    let mut denominator = &common * d;
                    if shift >= 0 {
                        numerator <<= shift as usize;
                    } else {
                        denominator <<= shift.unsigned_abs() as usize;
                    }
                    for sign in [Plus, Minus] {
                        check(numerator.clone(), denominator.clone(), sign);
                    }
                }
            }
        }
    }
