#!/usr/bin/env python3
"""Archive completed magnitude qualification and all measured resource changes."""
import gzip,hashlib,io,json,re,subprocess,tarfile
from pathlib import Path
Q=Path(__file__).resolve().parent;REPO=Path('/home/tim/Documents/GitHub/workspace/hyperreal');OUT=Q/'magnitude-range-complete';DEST=REPO/'benchmarks/checkpoints'
inputs=json.loads((OUT/'inputs.json').read_text());checks=json.loads((OUT/'validation-results.json').read_text())
assert len(checks)==12 and all(r['exit_code']==0 for r in checks)
assert not (OUT/'validation-worktree-status.txt').read_text()
profiles=json.loads((OUT/'profiles.json').read_text());assert all(r['exit_code']==0 for r in profiles)
matched=json.loads((OUT/'matched-profiles/runs.json').read_text());assert len(matched)==4 and all(r['exit_code']==0 for r in matched)
matched_comparison=json.loads((OUT/'matched-profiles/comparison.json').read_text())
resource=json.loads((OUT/'resource-comparison.json').read_text())
coverage=re.search(r'^TOTAL\s+(\d+)\s+(\d+)\s+(\d+)\s+([\d.]+)%$',(OUT/'validation/coverage-matrix.stdout').read_text(),re.M);assert coverage
def inventory(revision):
 names=subprocess.check_output(['git','ls-tree','-r','--name-only',revision],cwd=REPO,text=True).splitlines();groups={}
 for name in names:
  if not name.endswith(('.rs','.py','.sh')):continue
  if name.startswith('src/verified/'):group='production_kernels_with_proof_annotations_and_models'
  elif name.startswith('verification/'):group='proof_models_and_verification_checks'
  elif name.startswith('tests/') or name.endswith('/tests.rs'):group='dedicated_tests'
  elif name.startswith('src/'):group='other_production_source_including_inline_tests'
  elif name.startswith('benches/'):group='benchmarks'
  elif name.startswith('examples/'):group='examples'
  elif name.startswith('fuzz/'):group='fuzz_harnesses'
  else:group='other_validation_and_tools'
  data=subprocess.check_output(['git','show',revision+':'+name],cwd=REPO)
  row=groups.setdefault(group,{'files':0,'bytes':0,'lines':0});row['files']+=1;row['bytes']+=len(data);row['lines']+=len(data.splitlines())
 return {'revision':revision,'groups':groups,'total':{k:sum(r[k] for r in groups.values()) for k in ['files','bytes','lines']}}
source={'baseline':inventory(inputs['baseline']),'runtime_candidate':inventory(inputs['revision']),
 'current_proof':inventory(inputs['revision']),'note':'Groups are disjoint file categories. Production files can contain inline tests or ghost annotations; expanded ordinary Rust is reported separately and does not count as removal of proof source.'}
(OUT/'source-counts.json').write_text(json.dumps(source,indent=2)+'\n')
files=[]
for p in OUT.rglob('*'):
 if not p.is_file():continue
 relative=p.relative_to(OUT)
 if relative.parts[0]=='bin':continue
 if relative.parts[0]=='matched-profiles' and p.name.endswith('.gz'):continue
 files.append((p,str(relative)))
for name in ['qualify_magnitude_builds.py','profile_magnitude.py','compare_magnitude_resources.py','profile_magnitude_matched.py','preserve_magnitude_resources.py']:
 files.append((Q/name,'drivers/'+name))
archive=DEST/'2026-09-17-verus-magnitude-resources.tar.gz'
with archive.open('wb') as output:
 with gzip.GzipFile(fileobj=output,mode='wb',filename='',mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as tar:
   for p,name in sorted(files,key=lambda x:x[1]):
    data=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
report={'schema':1,'status':'qualification_milestone_not_acceptance','baseline':inputs['baseline'],'candidate':inputs['revision'],
 'validation':checks,'coverage':{'executable_lines':int(coverage[1]),'covered_lines':int(coverage[2]),'uncovered_lines':int(coverage[3]),'line_coverage_percent':float(coverage[4]),'is_formal_proof_coverage':False},
 'resources':resource,'matched_massif':matched_comparison,'source_counts':source,
 'expanded_runtime':json.loads((OUT/'expanded-runtime-counts.json').read_text()),
 'limits':['Current native benchmark screen and follow-ups remain pending; no whole-repository performance parity is claimed.',
  'Allocation counts decrease in twelve representations, per-case measured peaks do not increase and retained bytes are unchanged. The exact matched whole-process peak is 176 bytes higher in both pairs, and remains an explicit resource assessment item.',
  'Native executable and WebAssembly size increases are retained, not silently accepted. Dispatch traces differ as symbolic cloning reuses nodes and caches; trace equality is not a semantic correctness requirement.',
  'Full implementation/caller/dependency proofs, current downstream qualification and final source-bound acceptance remain pending.'],
 'artifact':{'path':str(archive.relative_to(REPO)),'bytes':archive.stat().st_size,'files':len(files),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}}
(DEST/'2026-09-17-verus-magnitude-resources.json').write_text(json.dumps(report,indent=2)+'\n')
print(report['artifact']);print(report['coverage'])
