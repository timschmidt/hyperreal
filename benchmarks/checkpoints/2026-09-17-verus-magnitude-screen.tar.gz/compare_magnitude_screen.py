#!/usr/bin/env python3
"""Summarize every completed screen row without turning a screen into acceptance."""
import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
INVENTORY = json.loads((ROOT / "inventory.json").read_text())["baseline"]
RUNS = json.loads((ROOT / "magnitude-range-screen/runs.json").read_text())
assert len(RUNS) == 18 and all(r["exit_code"] == 0 for r in RUNS)
ROWS = []
RAW = {"runs.json": RUNS}
for suite, count in INVENTORY.items():
    sides = {}
    for label in ["baseline", "candidate"]:
        data = {}
        for path in sorted((ROOT / "magnitude-range-screen" / suite / label / "criterion").glob("**/new/benchmark.json")):
            benchmark = json.loads(path.read_text())
            identity = benchmark["full_id"]
            assert identity not in data, (suite, label, identity)
            estimates = json.loads((path.parent / "estimates.json").read_text())
            data[identity] = estimates
            for file in path.parent.glob("*.json"):
                RAW[str(file.relative_to(ROOT / "magnitude-range-screen"))] = json.loads(file.read_text())
        assert len(data) == (2 if suite == "adversarial_library" else count), (suite, label, len(data), count)
        sides[label] = data
    assert sides["baseline"].keys() == sides["candidate"].keys(), suite
    for name in sorted(sides["baseline"]):
        baseline = sides["baseline"][name]["median"]
        candidate = sides["candidate"][name]["median"]
        ROWS.append({"suite": suite, "case": name,
            "median_change_percent": 100 * (candidate["point_estimate"] / baseline["point_estimate"] - 1),
            "baseline_median": baseline, "candidate_median": candidate,
            "positive_nonoverlapping_run_intervals": candidate["confidence_interval"]["lower_bound"] > baseline["confidence_interval"]["upper_bound"]})
ROWS.sort(key=lambda row: row["median_change_percent"], reverse=True)
ARCHIVE = ROOT / "magnitude-range-screen/raw.json.gz"
ARCHIVE.write_bytes(gzip.compress(json.dumps(RAW, sort_keys=True, separators=(",", ":")).encode(), mtime=0))
REPORT = {"status": "screen_only_not_acceptance", "rows": ROWS, "suites": len(INVENTORY),
    "total_rows": len(ROWS), "runs": RUNS, "raw_archive": str(ARCHIVE),
    "raw_sha256": hashlib.sha256(ARCHIVE.read_bytes()).hexdigest(),
    "interpretation": "One short pair per suite. Individual run confidence intervals only identify follow-up candidates; they are not a confidence interval for a repeated-pair effect. External comparator rows are preserved too."}
(ROOT / "magnitude-range-screen/comparison.json").write_text(json.dumps(REPORT, indent=2) + "\n")
print("Screened", len(ROWS), "matching cases across", len(INVENTORY), "suites")
print("Positive nonoverlapping within-run intervals:", sum(r["positive_nonoverlapping_run_intervals"] for r in ROWS))
for row in ROWS[:12]:
    print(f"{row['median_change_percent']:+.2f}% {row['suite']} {row['case']}")
