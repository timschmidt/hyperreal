#!/usr/bin/env python3
"""Preserve the source-bound width proof and cold precision counterexamples."""
import gzip,hashlib,io,json,subprocess,tarfile
from pathlib import Path
Q=Path(__file__).resolve().parent;R=Path('/home/tim/Documents/GitHub/workspace/hyperreal');D=R/'benchmarks/checkpoints'
def archive(slug,files):
 p=D/(slug+'.tar.gz')
 with p.open('wb') as raw:
  with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as zipped:
   with tarfile.open(fileobj=zipped,mode='w') as tar:
    for source,name in sorted(files,key=lambda x:x[1]):
     data=source.read_bytes(); info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
 return {'path':str(p.relative_to(R)),'bytes':p.stat().st_size,'files':len(files),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
e=json.loads((R/'target/verification/evidence.json').read_text());assert e['verification_results']['verified']==402 and e['verification_results']['success']
assert len(e['scope']['verified_model_theorems'])==75
for name,expected in e['sources'].items():
 assert hashlib.sha256(subprocess.check_output(['git','show',revision+':'+name],cwd=R)).hexdigest()==expected,(revision,name)
previous='f7e256c';runtime='ee773bbf4a158bbf4b09134f99dff3a3e45421d8'
assert not subprocess.check_output(['git','diff','--name-only',previous,revision,'--','src','Cargo.toml','Cargo.lock','build.rs'],cwd=R)
O=Q/'bit-length-bridge-proof';test=(O/'acceptance-tests.log').read_text();assert 'Ran 7 tests' in test and '\nOK\n' in test
files=[(p,'proof/'+str(p.relative_to(O))) for p in O.rglob('*') if p.is_file()]
files += [(R/'target/verification'/n,'official/'+n) for n in ['verus.json','verus.stderr','evidence.json']]
files += [(R/'verification/bit_length_model.rs','bit_length_model.rs'),(Q/'bit_length_bridge_draft.rs','initial-draft.rs'),(Q/'bit_length_bridge_trial.rs','initial-trial.rs'),(Path(__file__),'preserve.py')]
report={'schema':1,'status':'proof_milestone_not_acceptance','baseline':'a2da8e2b5de9a1a4653d3662f2f05cb6533fd7ef','proof_revision':revision,'runtime_revision':runtime,
 'verification':{'units':402,'executable_contracts':55,'model_theorems':75,'source_hashes':len(e['sources']),'source_hashes_match_commit':True,'entire_proof_target':True,'no_cheating':True,'acceptance_guard_tests':7},
 'new_model_theorems':[n for n in e['scope']['verified_model_theorems'] if n.startswith('bit_length_model::')],
 'runtime_identity':{'all_src_and_cargo_inputs_unchanged_from':previous,'expanded_runtime_evidence':'benchmarks/checkpoints/2026-09-17-verus-magnitude-model.json','expanded_sha256':'99986a4a43a85aa6eef35d6cd13399704037d0ceb42b3cd8b685b6266855dd22','fresh_runtime_build':False},
 'limits':['All 13 full-implementation obligation groups remain open.','This connects mathematical limb and leading-zero models to bit widths; actual BigUint storage, digit import, machine-width metadata and comparison callers remain unproved.','The previous 79 mutation guards and assumption-bypass record applies to unchanged kernel/magnitude inputs; no new mutation run is claimed for this module.','Native timing, resource and consumer assessments remain pending.'],
 'artifact':archive('2026-09-17-verus-bit-length-model',files)}
(D/'2026-09-17-verus-bit-length-model.json').write_text(json.dumps(report,indent=2)+'\n');print(report['artifact'])
P=Q/'precision-boundary-probe';O=P/'observations';runs=json.loads((O/'runs.json').read_text());assert len(runs)==24
assert sum(r['case']=='build' and r['exit_code']==0 for r in runs)==4
assert sum(r['exit_code']==101 for r in runs)==4
assert json.loads((O/'restoration.json').read_text())['clean']
inputs=json.loads((O/'inputs.json').read_text())
for name,h in inputs['files'].items():assert hashlib.sha256((P/name).read_bytes()).hexdigest()==h
files=[(p,str(p.relative_to(P))) for p in O.rglob('*') if p.is_file()]
files += [(P/n,n) for n in ['Cargo.toml','Cargo.lock','src/main.rs']]
files += [(Q/'probe_precision_boundaries.py','probe_precision_boundaries.py'),(Path(__file__),'preserve.py')]
report={'schema':1,'status':'confirmed_counterexamples_not_qualification','inputs':inputs,'runs':runs,
 'findings':['Both fixed baseline and current runtime panic in debug on cold pi().approx(i32::MAX): p+1 overflows while looking up the Tau cache.','Both revisions panic in debug on zero().approx(i32::MIN): -p overflows before scaling the exact zero.','The other controls and release cases return the checked allowed values. Release success for these cases does not establish correct precision arithmetic generally.'],
 'native_timing':False,'restoration':json.loads((O/'restoration.json').read_text()),'artifact':archive('2026-09-17-verus-precision-counterexamples',files)}
(D/'2026-09-17-verus-precision-counterexamples.json').write_text(json.dumps(report,indent=2)+'\n');print(report['artifact'])
