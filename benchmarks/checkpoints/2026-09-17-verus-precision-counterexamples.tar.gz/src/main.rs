use hyperreal::Computable;
use num::{BigInt, Zero};

fn main() {
    let case = std::env::args().nth(1).expect("case");
    let (value, precision, zero) = match case.as_str() {
        "pi-control" => (Computable::pi(), 32, false),
        "pi-max" => (Computable::pi(), i32::MAX, false),
        "tau-max" => (Computable::tau(), i32::MAX, false),
        "zero-control" => (Computable::zero(), -32, true),
        "zero-min" => (Computable::zero(), i32::MIN, true),
        _ => panic!("unknown case"),
    };
    let result = value.approx(precision);
    println!("case={case}, precision={precision}, value={result}");
    if zero { assert_eq!(result, BigInt::zero()); }
    else { assert!(result >= BigInt::zero() && result <= BigInt::from(1)); }
}
