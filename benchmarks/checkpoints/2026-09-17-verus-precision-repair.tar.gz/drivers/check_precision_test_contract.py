#!/usr/bin/env python3
import hashlib,json,os,subprocess,time
from pathlib import Path
Q=Path(__file__).resolve().parent;R=Path('/home/tim/Documents/GitHub/workspace/hyperreal');S=Q/'source';O=Q/'precision-repair-test-contract';O.mkdir()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=S,text=True)
E=json.loads((Q/'run.json').read_text())['environment']|{'CARGO_TARGET_DIR':str(Q/'target'),'CARGO_BUILD_JOBS':'4','CARGO_NET_OFFLINE':'true','CCACHE_DISABLE':'1'}
files=sorted(set(subprocess.check_output(['git','diff','--name-only','ee773bb','--','src','tests'],cwd=R,text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard','src','tests'],cwd=R,text=True).splitlines()))
original={n:(S/n).read_bytes() if (S/n).exists() else None for n in files};records=[]
inputs={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in files}
(O/'inputs.json').write_text(json.dumps({'overlays':inputs,'note':'The cold constant regression accepts both integers permitted by the public one-unit error contract. Earlier whole-suite replay used the stronger zero-only assertion and passed. Library runtime is unchanged.','environment':E},indent=2)+'\n')
(O/'precision_limits.rs').write_bytes((R/'tests/precision_limits.rs').read_bytes())
try:
 for n in files:(S/n).write_bytes((R/n).read_bytes())
 for features in [[],['--all-features']]:
  for release in [[],['--release']]:
   command=['cargo','test','--locked',*features,*release,'--test','precision_limits'];start=time.time()
   with (O/(str(len(records))+'.log')).open('w') as log:r=subprocess.run(command,cwd=S,env=os.environ|E,stdout=log,stderr=subprocess.STDOUT)
   records.append({'command':command,'exit_code':r.returncode,'seconds':time.time()-start});(O/'runs.json').write_text(json.dumps(records,indent=2)+'\n');print(command,r.returncode,flush=True)
   if r.returncode:raise RuntimeError('Cold precision contract check failed')
finally:
 for n,b in original.items():
  if b is None:(S/n).unlink()
  else:(S/n).write_bytes(b)
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=S,text=True)
 (O/'restoration.json').write_text(json.dumps({'clean':True},indent=2)+'\n')
