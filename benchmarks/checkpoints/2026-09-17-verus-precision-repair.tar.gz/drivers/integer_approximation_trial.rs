#![feature(proc_macro_hygiene)]
#[path = "/home/tim/Documents/GitHub/workspace/hyperreal/src/verified/mod.rs"]
mod verified;
#[path = "/home/tim/Documents/GitHub/workspace/hyperreal/verification/magnitude_model.rs"]
mod magnitude_model;
#[path = "integer_approximation_model_draft.rs"]
mod integer_approximation_model;
