use vstd::prelude::*;
verus! {
fn approximation_scale_plan(precision: i32) -> (plan: (bool, u32))
    ensures
        plan.0 == (precision > 0),
        if precision <= 0 { plan.1 as int == -(precision as int) }
        else { plan.1 as int == precision as int - 1 },
{
    if precision <= 0 {
        (false, (-(precision as i64)) as u32)
    } else {
        (true, (precision - 1) as u32)
    }
}
}
