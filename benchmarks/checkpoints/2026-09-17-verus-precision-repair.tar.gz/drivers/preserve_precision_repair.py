#!/usr/bin/env python3
"""Retain source-bound precision repair proofs and correctness counterexamples."""
import gzip,hashlib,io,json,re,subprocess,tarfile
from pathlib import Path
Q=Path(__file__).resolve().parent;R=Path('/home/tim/Documents/GitHub/workspace/hyperreal');D=R/'benchmarks/checkpoints'
revision=subprocess.check_output(['git','rev-parse','7b95cac'],cwd=R,text=True).strip()
def committed_hash(name):return hashlib.sha256(subprocess.check_output(['git','show',revision+':'+name],cwd=R)).hexdigest()
e=json.loads((R/'target/verification/evidence.json').read_text());assert e['verification_results']['verified']==410 and e['verification_results']['success']
assert len(e['scope']['verified_executable_contracts'])==56 and len(e['scope']['verified_model_theorems'])==78
assert all(committed_hash(n)==h for n,h in e['sources'].items())
P=Q/'integer-approximation-proof';s=(P/'rejections.log').read_text();assert s.count('Rejected incorrect ')==83 and 'Rejected attempted assumption bypass' in s
assert 'Ran 7 tests' in (P/'acceptance-tests.log').read_text() and '\nOK\n' in (P/'acceptance-tests.log').read_text()
root=Q/'precision-repair-root';runs=json.loads((root/'runs.json').read_text());assert len(runs)==9
assert all(r['exit_code']==0 for r in runs if r['label']=='candidate')
counts={}
for name in ['default-all-targets','all-features-all-targets']:
 s=(root/('candidate-'+name+'.log')).read_text();counts[name]={'passed_test_executions_including_children':sum(map(int,re.findall(r'test result: ok\. (\d+) passed',s))),'benchmark_fixture_replays':len(re.findall(r'^Success$',s,re.M))}
assert counts['default-all-targets']=={'passed_test_executions_including_children':795,'benchmark_fixture_replays':1271}
assert counts['all-features-all-targets']=={'passed_test_executions_including_children':898,'benchmark_fixture_replays':1447}
for folder in ['precision-repair-focused','precision-repair-root','precision-repair-test-contract']:
 i=json.loads((Q/folder/'inputs.json').read_text())
 for name,h in i['overlays'].items():
  if folder=='precision-repair-root' and name=='tests/precision_limits.rs':continue
  assert committed_hash(name)==h,(folder,name)
 assert json.loads((Q/folder/'restoration.json').read_text())['clean']
contract=Q/'precision-repair-test-contract';assert all(r['exit_code']==0 for r in json.loads((contract/'runs.json').read_text()))
probe=Q/'precision-full-range-probe';pr=json.loads((probe/'observations/runs.json').read_text());assert len(pr)==32
assert sum(r['exit_code']==0 and r['case']=='build' for r in pr)==4
assert all(r['exit_code']==0 for r in pr if r['label']=='candidate')
assert sum(r['exit_code']==101 for r in pr if r['label']=='baseline')==6
pi=json.loads((probe/'observations/inputs.json').read_text())
assert all(committed_hash(n)==h for n,h in pi['candidate_overlays'].items())
assert all(hashlib.sha256((probe/n).read_bytes()).hexdigest()==h for n,h in pi['files'].items())
assert json.loads((probe/'observations/restoration.json').read_text())['clean']
files=[]
for name in ['integer-approximation-proof','precision-repair-focused','precision-repair-root','precision-repair-test-contract','precision-full-range-probe']:
 folder=Q/name
 files += [(p,str(p.relative_to(Q))) for p in folder.rglob('*') if p.is_file()]
files += [(R/'target/verification'/n,'official/'+n) for n in ['evidence.json','verus.json','verus.stderr']]
for name in ['preserve_precision_repair.py','qualify_precision_patch.py','qualify_precision_root.py','check_precision_test_contract.py','probe_full_precision_range.py','precision_scale_plan_trial.rs','precision_scale_plan_trial.json','precision_scale_plan_trial.stderr','integer_approximation_model_draft.rs','integer_approximation_trial.rs']:
 files.append((Q/name,'drivers/'+name))
for name in ['verification/integer_approximation_model.rs','tests/precision_limits.rs']:
 files.append((R/name,'committed/'+name))
p=D/'2026-09-17-verus-precision-repair.tar.gz'
with p.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as zipped:
  with tarfile.open(fileobj=zipped,mode='w') as tar:
   for source,name in sorted(files,key=lambda x:x[1]):
    data=source.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
report={'schema':1,'status':'exactness_repair_qualification_in_progress','baseline':'a2da8e2b5de9a1a4653d3662f2f05cb6533fd7ef','candidate':revision,
 'verification':{'units':410,'executable_contracts':56,'model_theorems':78,'source_hashes':len(e['sources']),'source_hashes_match_commit':True,'entire_proof_target':True,'no_cheating':True,'open_obligation_groups':13},
 'negative_guards':{'incorrect_executable_mutations':79,'incorrect_model_mutations':4,'assumption_bypass_rejected':True,'acceptance_guard_tests':7},
 'counterexamples':{'baseline_debug':['cold pi at i32::MAX panics in related-cache precision addition','zero, one and negative one at i32::MIN panic in precision negation'],'baseline_release':['one and negative one at i32::MIN incorrectly return zero'],'fixed_candidate':'All seven cold-process cases pass in debug and release, including positive/negative exact values with 2147483649 bits and 2147483648 trailing zero bits.','raw_processes':pr},
 'root_correctness':counts,'root_validation':runs,
 'focused_validation':json.loads((Q/'precision-repair-focused/runs.json').read_text()),
 'cold_contract_validation':json.loads((contract/'runs.json').read_text()),
 'binding_notes':['All library overlay hashes match the committed repair. Unchanged files derive from the pinned EE runtime.','The original complete root replay used a zero-only assertion for cold Pi/Tau. The committed test admits both integers allowed by the public one-unit error contract and passes in default/all-features debug/release; its exact source and replays are retained.','The first external probe had four compiler failures because it called a private constructor. Those logs are retained separately; the corrected public-constructor probe supplies the counterexamples and repair evidence.','Two failed model-proof trials are preserved as failures; the official source-bound 410-unit run is the qualifying proof.'],
 'limits':['This proves the executable precision plan and mathematical signed rounding/cache coarsening. BigInt operations, caller refinement, constant identities, cache concurrency and all 13 complete-implementation groups remain open.','Other kernels still contain unresolved precision arithmetic; this repair does not establish all-kernel support at every precision.','Remaining build/coverage/fuzz/resource/native-timing and pinned-consumer qualification for this runtime is in progress. Earlier runtime benchmark flags remain unresolved; no acceptance is claimed.'],
 'artifact':{'path':str(p.relative_to(R)),'bytes':p.stat().st_size,'files':len(files),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}}
(D/'2026-09-17-verus-precision-repair.json').write_text(json.dumps(report,indent=2)+'\n');print(report['artifact']);print(counts)
