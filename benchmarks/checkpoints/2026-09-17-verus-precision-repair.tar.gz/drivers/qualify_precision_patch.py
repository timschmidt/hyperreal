#!/usr/bin/env python3
import hashlib,json,os,subprocess,time
from pathlib import Path
Q=Path(__file__).resolve().parent; R=Path('/home/tim/Documents/GitHub/workspace/hyperreal'); S=Q/'source';O=Q/'precision-repair-focused';O.mkdir()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=S,text=True)
files=subprocess.check_output(['git','diff','--name-only','HEAD','--','src'],cwd=R,text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard','src'],cwd=R,text=True).splitlines()
original={n:(S/n).read_bytes() if (S/n).exists() else None for n in files}
E=json.loads((Q/'run.json').read_text())['environment']|{'CARGO_TARGET_DIR':str(Q/'target'),'CARGO_BUILD_JOBS':'4','CARGO_NET_OFFLINE':'true','CCACHE_DISABLE':'1'}
commands=[['cargo','test','--locked','--lib','precision_boundary_tests'],['cargo','test','--locked','--release','--lib','precision_boundary_tests'],['cargo','clippy','--locked','--all-features','--all-targets','--','-D','warnings']]
records=[]
(O/'inputs.json').write_text(json.dumps({'source_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip(),'root_parent':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'overlays':{n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in files},'environment':E},indent=2)+'\n')
try:
 for n in files:
  (S/n).parent.mkdir(parents=True,exist_ok=True);(S/n).write_bytes((R/n).read_bytes());p=O/'overlay'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((R/n).read_bytes())
 for i,command in enumerate(commands):
  start=time.time()
  with (O/(str(i)+'.log')).open('w') as f:r=subprocess.run(command,cwd=S,env=os.environ|E,stdout=f,stderr=subprocess.STDOUT)
  records.append({'command':command,'exit_code':r.returncode,'seconds':time.time()-start});(O/'runs.json').write_text(json.dumps(records,indent=2)+'\n');print(i,r.returncode,round(time.time()-start,2),flush=True)
  if r.returncode:raise RuntimeError('Qualification step failed; inspect retained log')
finally:
 for n,b in original.items():
  if b is None:(S/n).unlink()
  else:(S/n).write_bytes(b)
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=S,text=True)
 (O/'restoration.json').write_text(json.dumps({'clean':True,'source_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()},indent=2)+'\n')
