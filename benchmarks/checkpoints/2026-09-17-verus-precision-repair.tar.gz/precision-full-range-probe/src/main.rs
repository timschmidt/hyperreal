use hyperreal::Computable;
use num::{BigInt, Zero};
fn main() {
    let case = std::env::args().nth(1).expect("case");
    let (value, precision, sign) = match case.as_str() {
        "pi-control" => (Computable::pi(), 32, 0),
        "pi-max" => (Computable::pi(), i32::MAX, 0),
        "tau-max" => (Computable::tau(), i32::MAX, 0),
        "zero-control" => (Computable::zero(), -32, 0),
        "zero-min" => (Computable::zero(), i32::MIN, 0),
        "one-min" => (Computable::one(), i32::MIN, 1),
        "negative-one-min" => (Computable::rational((-1).into()), i32::MIN, -1),
        _ => panic!("unknown case"),
    };
    let result = value.approx(precision);
    println!("case={case}, precision={precision}, sign={:?}, bits={}, trailing_zeros={:?}", result.sign(), result.bits(), result.trailing_zeros());
    if sign == 0 { assert_eq!(result, BigInt::zero()); }
    else {
        assert_eq!(result.bits(), 2_147_483_649);
        assert_eq!(result.trailing_zeros(), Some(2_147_483_648));
        assert_eq!(result > BigInt::zero(), sign > 0);
    }
}
