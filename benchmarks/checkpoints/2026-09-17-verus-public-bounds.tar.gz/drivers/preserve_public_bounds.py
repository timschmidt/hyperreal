#!/usr/bin/env python3
"""Preserve the actual public metadata adapters and their proof evidence."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

Q = Path(__file__).resolve().parent
R = Path('/home/tim/Documents/GitHub/workspace/hyperreal')
O = Q / 'public-bound-proof'
D = R / 'benchmarks/checkpoints'
def digest(data): return hashlib.sha256(data).hexdigest()
def git(*args): return subprocess.check_output(['git', *args], cwd=R, text=True).strip()
revision = git('rev-parse', 'HEAD')
e = json.loads((R / 'target/verification/evidence.json').read_text())
assert e['verification_results']['verified'] == 546 and e['verification_results']['success']
assert len(e['scope']['verified_executable_contracts']) == 90
assert len(e['scope']['verified_model_theorems']) == 102
for name, expected in e['sources'].items():
    assert digest(subprocess.check_output(['git', 'show', revision + ':' + name], cwd=R)) == expected, name
assert (O / 'rejections.log').read_text().count('Rejected incorrect') == 35
assert (O / 'cache-rejections.log').read_text().count('Rejected incorrect') == 13
assert 'Ran 10 tests' in (O / 'acceptance-tests.log').read_text()
assert '\nOK\n' in (O / 'acceptance-tests.log').read_text()
assert not (O / 'fmt.log').read_text()
for path in [*sorted((R / 'src/verified').glob('*.rs')), R / 'src/structural.rs',
             *[R / 'verification' / n for n in ['magnitude_model.rs', 'integer_approximation_model.rs',
                 'real_approximation_model.rs', 'test_structural_rejections.py']]]:
    assert path.read_bytes() == subprocess.check_output(['git', 'show', '4a162ed:' + str(path.relative_to(R))], cwd=R)
erasure = Q / 'public-bound-erasure'
expanded = (erasure / 'candidate-expanded-runtime.log').read_bytes()
assert expanded == (Q / 'computable-metadata-complete/expanded-runtime.rs').read_bytes()
assert all(row['exit_code'] == 0 for row in json.loads((erasure / 'runs.json').read_text()))
assert json.loads((erasure / 'restoration.json').read_text())['clean']
for name, expected in json.loads((erasure / 'inputs.json').read_text())['overlays'].items():
    assert digest((R / name).read_bytes()) == expected
files = [(p, str(p.relative_to(Q))) for folder in [O, erasure] for p in folder.rglob('*') if p.is_file()]
for name in ['evidence.json', 'verus.json', 'verus.stderr', 'dependencies.json',
             'dependencies-build.stdout', 'dependencies-build.stderr']:
    files.append((R / 'target/verification' / name, 'official/' + name))
for package in e['dependencies']['packages']:
    source = Path(package['manifest_path']).parent
    for name, expected in e['dependencies']['sources'][package['id']].items():
        p = source / name
        assert digest(p.read_bytes()) == expected
        files.append((p, 'dependency-sources/' + package['name'] + '-' + package['version'] + '/' + name))
for name in git('show', '--pretty=format:', '--name-only', revision).splitlines():
    files.append((R / name, 'committed/' + name))
for name in ['preserve_public_bounds.py', 'check_public_bound_erasure.py']:
    files.append((Q / name, 'drivers/' + name))
archive = D / '2026-09-17-verus-public-bounds.tar.gz'
with archive.open('wb') as raw:
    with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for p, name in sorted(files, key=lambda item: item[1]):
                data = p.read_bytes()
                info = tarfile.TarInfo(name)
                info.size = len(data)
                info.mode = 0o644
                tar.addfile(info, io.BytesIO(data))
report = {
    'schema': 1, 'status': 'public_bound_adapter_milestone_not_complete',
    'baseline': git('rev-parse', 'a2da8e2'), 'proof_revision': revision,
    'runtime_reference': git('rev-parse', 'cdc6d3a'),
    'verification': {'units': 546, 'executable_contracts': 90, 'functions': 82, 'constants': 8,
        'model_theorems': 102, 'source_hashes': len(e['sources']), 'source_hashes_match_commit': True,
        'no_cheating': True, 'entire_proof_target': True, 'open_obligation_groups': 13},
    'new_contracts': ['BoundInfo::magnitude_bits', 'public_sign', 'private_sign'],
    'new_refinements': ['Public magnitude export preserves valid nonzero and exact-binade certificates.',
        'Both sign conversions preserve their real-number denotation.'],
    'negative_guards': {'bound_mutations_rejected': 35, 'cache_mutations_rejected': 13,
        'acceptance_and_dependency_identity_tests': 10,
        'reused_guards': [
            {'count': 85, 'artifact': 'benchmarks/checkpoints/2026-09-17-verus-real-approximation-model.json'},
            {'count': 21, 'artifact': 'benchmarks/checkpoints/2026-09-17-verus-public-carriers.json'}],
        'note': 'The prior guarded inputs are unchanged. No fresh combined 154-mutation or assumption-bypass run is claimed.'},
    'ordinary_runtime': {'byte_identical_expansion_to_runtime_reference': True,
        'expanded_sha256': digest(expanded), 'lines': len(expanded.splitlines()),
        'checks': json.loads((erasure / 'runs.json').read_text()),
        'format_check': 'cargo fmt --all -- --check passed',
        'note': 'Only proof annotations changed in production; method bodies and types are unchanged.'},
    'failed_attempts': ['Invoking unittest by package path failed the acceptance-script sibling import. '
        'The documented direct script invocation passes all ten tests; both logs are retained.'],
    'limits': ['Denotation lemmas require valid incoming certificates. Production callers and certificate producers remain open.',
        'Inexact magnitude metadata is exported unchanged; no real-binade or error bound is asserted for it.',
        'All thirteen whole-implementation proof groups and baseline acceptance remain incomplete.'],
    'artifact': {'path': str(archive.relative_to(R)), 'bytes': archive.stat().st_size,
        'files': len(files), 'sha256': digest(archive.read_bytes())},
}
(D / '2026-09-17-verus-public-bounds.json').write_text(json.dumps(report, indent=2) + '\n')
print(report['verification'])
print(report['artifact'])
