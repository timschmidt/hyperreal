#!/usr/bin/env python3
"""Retain public carrier contracts, failed trials and normal-build identity."""
import gzip,hashlib,io,json,subprocess,tarfile
from pathlib import Path
Q=Path(__file__).resolve().parent;R=Path('/home/tim/Documents/GitHub/workspace/hyperreal')
O=Q/'public-carrier-proof';D=R/'benchmarks/checkpoints'
def digest(data):return hashlib.sha256(data).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=R,text=True).strip()
revision=git('rev-parse','HEAD');e=json.loads((R/'target/verification/evidence.json').read_text())
assert e['verification_results']['verified']==540 and e['verification_results']['success']
assert len(e['scope']['verified_executable_contracts'])==87 and len(e['scope']['verified_model_theorems'])==99
for name,h in e['sources'].items():assert digest(subprocess.check_output(['git','show',revision+':'+name],cwd=R))==h,name
assert (O/'rejections.log').read_text().count('Rejected incorrect public carrier:')==21
assert 'Traceback' not in (O/'rejections.log').read_text()
assert 'Ran 10 tests' in (O/'acceptance-tests.log').read_text() and '\nOK\n' in (O/'acceptance-tests.log').read_text()
assert not (O/'fmt.log').read_text()
unchanged=list((R/'src/verified').glob('*.rs'))+[R/'src/computable/node'/n for n in ['bounds.rs','representation.rs']]
unchanged += [R/'verification'/n for n in ['magnitude_model.rs','integer_approximation_model.rs','real_approximation_model.rs',
    'computable_bounds.rs','bound_denotation.rs','computable_cache.rs','cache_encoding_model.rs','test_bound_rejections.py','test_cache_rejections.py']]
for path in unchanged:assert path.read_bytes()==subprocess.check_output(['git','show','9418f85:'+str(path.relative_to(R))],cwd=R)
erasure=Q/'public-carrier-final-erasure';expanded=(erasure/'candidate-expanded-runtime.log').read_bytes()
assert expanded==(Q/'computable-metadata-complete/expanded-runtime.rs').read_bytes()
assert expanded==(Q/'public-carrier-erasure/candidate-expanded-runtime.log').read_bytes()
assert all(row['exit_code']==0 for row in json.loads((erasure/'runs.json').read_text()))
assert json.loads((erasure/'restoration.json').read_text())['clean']
for name,h in json.loads((erasure/'inputs.json').read_text())['overlays'].items():assert digest((R/name).read_bytes())==h
files=[(p,str(p.relative_to(Q))) for folder in [O,Q/'public-carrier-erasure',erasure] for p in folder.rglob('*') if p.is_file()]
for name in ['evidence.json','verus.json','verus.stderr','dependencies.json','dependencies-build.stdout','dependencies-build.stderr']:
    files.append((R/'target/verification'/name,'official/'+name))
for package in e['dependencies']['packages']:
    source=Path(package['manifest_path']).parent
    for name,h in e['dependencies']['sources'][package['id']].items():
        p=source/name;assert digest(p.read_bytes())==h
        files.append((p,'dependency-sources/'+package['name']+'-'+package['version']+'/'+name))
for name in ['src/structural.rs','verification/lib.rs','verification/scope.json','verification/README.md',
             'verification/test_structural_rejections.py','verification/test_rejections.py']:
    files.append((R/name,'committed/'+name))
for name in ['preserve_public_carriers.py','check_public_carrier_erasure.py','check_public_carrier_final_erasure.py']:
    files.append((Q/name,'drivers/'+name))
archive=D/'2026-09-17-verus-public-carriers.tar.gz'
with archive.open('wb') as raw:
    with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as compressed:
        with tarfile.open(fileobj=compressed,mode='w') as tar:
            for p,name in sorted(files,key=lambda item:item[1]):
                data=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
report={
    'schema':1,'status':'public_carrier_contract_milestone_not_complete',
    'baseline':'a2da8e2b5de9a1a4653d3662f2f05cb6533fd7ef','proof_revision':revision,'runtime_reference':git('rev-parse','cdc6d3a'),
    'verification':{'units':540,'executable_contracts':87,'functions':79,'constants':8,'model_theorems':99,
        'source_hashes':len(e['sources']),'source_hashes_match_commit':True,'no_cheating':True,'entire_proof_target':True,'open_obligation_groups':13},
    'new_contracts':{'certificate_accessors':6,'mask_operations':5,'mask_constants':7,
        'constant_symbols':'The pinned verifier reports the seven associated constants under structural::impl&%3. The source-bound scope inventory checks these exact symbols.'},
    'negative_guards':{'new_public_carrier_mutations_rejected':21,'acceptance_and_dependency_identity_tests':10,
        'reused_guards':[{'count':85,'artifact':'benchmarks/checkpoints/2026-09-17-verus-real-approximation-model.json'},
            {'count':25,'artifact':'benchmarks/checkpoints/2026-09-17-verus-bound-mapping.json'},
            {'count':13,'artifact':'benchmarks/checkpoints/2026-09-17-verus-cache-codecs.json'}],
        'note':'The prior guarded inputs are unchanged. No fresh combined 144-mutation or assumption-bypass run is claimed.'},
    'ordinary_runtime':{'byte_identical_expansion_to_runtime_reference':True,'expanded_sha256':digest(expanded),'lines':len(expanded.splitlines()),
        'checks':json.loads((erasure/'runs.json').read_text()),'format_check':'cargo fmt --all -- --check passed',
        'note':'The actual public method bodies, constant initializers and private field visibility are unchanged. Initial and final annotations erase to the same ordinary Rust as cdc6d3a.'},
    'experiments':[
        'Publishing a default spec constant exposed a private constructor and failed verification. A direct closed attribute was not supported in that position; neither attempt was accepted.',
        'Executable constant contracts preserve private representation and verify the exact fixed bit-shift expressions. A redundant proof-only constant reader was removed because exec constants cannot be read in that proof context.',
        'Decimal constant postconditions required bit-vector reasoning; the final contracts use equivalent exact fixed-bit expressions without changing runtime initializers.',
        'The first successful 540-unit Verus run was rejected by the inventory gate because associated constants have internal impl symbols. The final inventory matches the pinned verifier output; no gate exception was added.'
    ],
    'limits':[
        'Accessors preserve every known answer and unknown state; the mathematical soundness of the certificate-producing algorithms remains open.',
        'Dependency masks support every u16, including bits outside the named families. These contracts do not prove correctness of dependency classification or scheduling callers.',
        'The public/private sign conversion adapters and BoundInfo magnitude export remain separate obligations, as do unchecked generated trait implementations.',
        'All thirteen whole-implementation proof groups and baseline acceptance remain incomplete.'
    ],
    'artifact':{'path':str(archive.relative_to(R)),'bytes':archive.stat().st_size,'files':len(files),'sha256':digest(archive.read_bytes())},
}
(D/'2026-09-17-verus-public-carriers.json').write_text(json.dumps(report,indent=2)+'\n')
print(report['verification']);print(report['artifact'])
