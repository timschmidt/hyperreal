#!/usr/bin/env python3
"""Archive exact-real model proofs, rejection guards, and unchanged runtime identity."""
import gzip,hashlib,io,json,subprocess,tarfile
from pathlib import Path
Q=Path(__file__).resolve().parent;R=Path('/home/tim/Documents/GitHub/workspace/hyperreal');O=Q/'real-approximation-proof';D=R/'benchmarks/checkpoints'
revision=subprocess.check_output(['git','rev-parse','49f2b8f'],cwd=R,text=True).strip();runtime=subprocess.check_output(['git','rev-parse','7b95cac'],cwd=R,text=True).strip()
e=json.loads((R/'target/verification/evidence.json').read_text());assert e['verification_results']['success'] and e['verification_results']['verified']==431
assert len(e['scope']['verified_executable_contracts'])==56 and len(e['scope']['verified_model_theorems'])==87
for name,h in e['sources'].items():assert hashlib.sha256(subprocess.check_output(['git','show',revision+':'+name],cwd=R)).hexdigest()==h,name
assert not subprocess.check_output(['git','diff','--name-only',runtime,revision,'--','src','tests','Cargo.toml','Cargo.lock','build.rs'],cwd=R)
s=(O/'rejections.log').read_text();assert s.count('Rejected incorrect ')==85 and 'Rejected attempted assumption bypass' in s
assert 'Ran 7 tests' in (O/'acceptance-tests.log').read_text() and '\nOK\n' in (O/'acceptance-tests.log').read_text()
files=[(p,'trials/'+str(p.relative_to(O))) for p in O.rglob('*') if p.is_file()]
files += [(R/'target/verification'/n,'official/'+n) for n in ['evidence.json','verus.json','verus.stderr']]
files += [(Q/n,'drivers/'+n) for n in ['preserve_real_approximation_model.py','real_approximation_model_draft.rs','real_approximation_trial.rs','real_cast_trial.rs']]
files.append((R/'verification/real_approximation_model.rs','committed/real_approximation_model.rs'))
p=D/'2026-09-17-verus-real-approximation-model.tar.gz'
with p.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as zipped:
  with tarfile.open(fileobj=zipped,mode='w') as tar:
   for source,name in sorted(files,key=lambda x:x[1]):
    data=source.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
report={'schema':1,'status':'proof_milestone_not_acceptance','baseline':'a2da8e2b5de9a1a4653d3662f2f05cb6533fd7ef','proof_revision':revision,'runtime_revision':runtime,
 'verification':{'units':431,'production_contracts':56,'model_theorems':87,'source_hashes':len(e['sources']),'all_source_hashes_match_commit':True,'entire_proof_target':True,'no_cheating':True,'open_obligation_groups':13},
 'new_model_theorems':[n for n in e['scope']['verified_model_theorems'] if n.startswith('real_approximation_model::')],
 'negative_guards':{'incorrect_executables':79,'incorrect_models':6,'assumption_bypass_rejected':True,'acceptance_guard_tests':7},
 'runtime_identity':{'source_and_cargo_inputs_unchanged_from':runtime,'tests_unchanged':True,'fresh_runtime_build':False,'expanded_runtime_sha256':'96fff475be69d3f42577159e47aa1eff33d94af7744e5a245f4b20e226b41285','runtime_evidence':'benchmarks/checkpoints/2026-09-17-verus-precision-resources.json'},
 'limits':['These are compositional mathematical results over exact real numbers and input approximation error bounds. They do not establish those bounds for the production expression graph.','BigInt operations, caller precision arithmetic, constant/transcendental denotations, domain validity, abort behavior, concurrency and convergence remain unproved. All 13 full-implementation obligation groups remain open.','Initial missing integer-to-real algebraic bridges and product-negation rewrites produced failed proof trials; these are retained as failures. The official 431-unit source-bound proof supplies qualifying evidence.','Current native timing and broader pinned-consumer assessment remain pending; the resource differences remain unresolved.'],
 'artifact':{'path':str(p.relative_to(R)),'bytes':p.stat().st_size,'files':len(files),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}}
(D/'2026-09-17-verus-real-approximation-model.json').write_text(json.dumps(report,indent=2)+'\n');print(report['artifact'])
