use vstd::prelude::*;
verus! {
proof fn cast_product(a: int, b: int)
    ensures (a * b) as real == a as real * b as real,
{
    assert((a * b) as real == a as real * b as real) by (nonlinear_arith);
}
proof fn negate(v: real, a: int, u: real)
    requires u > 0real, -u <= a as real * u - v <= u,
    ensures -u <= (-a) as real * u + v <= u,
{
    assert(-u <= (-a) as real * u + v <= u) by (nonlinear_arith)
        requires u > 0real, -u <= a as real * u - v <= u;
}
}
