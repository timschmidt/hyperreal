#!/usr/bin/env python3
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

ROOT = Path(__file__).resolve().parent
CONFIG = json.loads((ROOT / 'run.json').read_text())
ENV = os.environ | CONFIG['environment'] | {'CARGO_TARGET_DIR': str(ROOT / 'probe-target'), 'CARGO_BUILD_JOBS': '2'}
RECORDS = []
try:
    for label in ['baseline', 'candidate']:
        subprocess.run(['git', 'checkout', '--detach', CONFIG[label]], cwd=ROOT / 'source', check=True)
        folder = ROOT / label / 'representation-probe'
        folder.mkdir(exist_ok=True)
        command = ['cargo', 'build', '--offline', '--release', '--message-format=json']
        started = time.time()
        with (folder / 'build.stdout').open('w') as out, (folder / 'build.stderr').open('w') as err:
            result = subprocess.run(command, cwd=ROOT / 'representation-probe', env=ENV, stdout=out, stderr=err)
        if result.returncode:
            raise SystemExit(result.returncode)
        destination = folder / 'probe'
        shutil.copy2(ROOT / 'probe-target/release/hyperreal-representation-probe', destination)
        RECORDS.append({'label': label, 'revision': CONFIG[label], 'command': command,
                        'seconds': time.time() - started,
                        'exit_code': result.returncode, 'binary_sha256': hashlib.sha256(destination.read_bytes()).hexdigest()})
        # Record only task-controlled environment values, not inherited private configuration.
        RECORDS[-1]['environment'] = CONFIG['environment'] | {'CARGO_TARGET_DIR': str(ROOT / 'probe-target'), 'CARGO_BUILD_JOBS': '2'}
        (ROOT / 'representation-probe-builds.json').write_text(json.dumps(RECORDS, indent=2) + '\n')
        print(label, result.returncode, round(time.time() - started, 1), flush=True)
finally:
    subprocess.run(['git', 'checkout', '--detach', CONFIG['candidate']], cwd=ROOT / 'source', check=True)
