#!/usr/bin/env python3
"""Instruction-count diagnostics; profiler elapsed times are not native timings."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent
RUNTIME = ROOT / 'probe-runtime'
RUNTIME.mkdir(exist_ok=True)
RECORDS = []
for case in ['pi_pow_clone', 'pi_clone', 'tan_pi_cached']:
    for iterations in [1000, 10000]:
        for label in ['baseline', 'candidate']:
            folder = ROOT / label / 'representation-probe' / case / str(iterations)
            folder.mkdir(parents=True, exist_ok=True)
            executable = RUNTIME / 'probe'
            shutil.copy2(ROOT / label / 'representation-probe/probe', executable)
            command = ['valgrind', '--tool=callgrind', '--error-exitcode=81',
                       '--callgrind-out-file=' + str(RUNTIME / 'callgrind.out'),
                       str(executable), case, str(iterations)]
            with (folder / 'callgrind.log').open('w') as output:
                result = subprocess.run(command, cwd=RUNTIME, stdout=output, stderr=subprocess.STDOUT)
            if result.returncode:
                raise SystemExit(result.returncode)
            profile = folder / 'callgrind.out'
            (RUNTIME / 'callgrind.out').rename(profile)
            summary = [line for line in profile.read_text().splitlines() if line.startswith('summary:')]
            assert len(summary) == 1
            instructions = int(summary[0].split()[1])
            RECORDS.append({'label': label, 'case': case, 'iterations': iterations,
                            'instructions': instructions, 'exit_code': result.returncode,
                            'command': command, 'binary_sha256': hashlib.sha256(executable.read_bytes()).hexdigest(),
                            'profile': str(profile), 'log': str(folder / 'callgrind.log')})
            (ROOT / 'representation-probe-profiles.json').write_text(json.dumps(RECORDS, indent=2) + '\n')
            print(label, case, iterations, instructions, flush=True)
