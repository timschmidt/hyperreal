#!/usr/bin/env python3
"""Longer alternating repeats for every positive nonoverlapping screen flag."""
import hashlib,json,os,re,shutil,subprocess,time
from pathlib import Path
Q=Path(__file__).resolve().parent;CONFIG=json.loads((Q/'run.json').read_text())
SCREEN=json.loads((Q/'clone-shared-v3-screen/comparison.json').read_text())
REVISION=json.loads((Q/'clone-shared-v3-screen/config.json').read_text())['revisions']['candidate']
OUT=Q/'clone-shared-v3-confirmations';OUT.mkdir();RUNTIME=Q/'clone-shared-v3-confirmation-runtime';RUNTIME.mkdir();CRITERION=RUNTIME/'criterion'
ENV=CONFIG['environment'] | {'CRITERION_HOME':str(CRITERION),'LC_ALL':'C'}
cases={}
for row in SCREEN['rows']:
 if row['positive_nonoverlapping_run_intervals']:
  cases.setdefault(row['suite'],[]).append(row['case'])
# Retain all flagged comparator rows too; never normalize away their movement.
for suite in cases:cases[suite]=sorted(set(cases[suite]))
(OUT/'config.json').write_text(json.dumps({'baseline':CONFIG['baseline'],'candidate':REVISION,'cases':cases,
 'selection':'Every positive nonoverlapping within-run median interval in the full screen, including external comparators.',
 'environment':ENV,'compiler':CONFIG['compiler'],'cwd':str(Q/'source'),
 'limits':['Four alternating pairs are follow-up evidence, not final acceptance.','Host frequency, thermal conditions, ASLR and unrelated user activity are uncontrolled.']},indent=2)+'\n')
records=[]
for suite,names in cases.items():
 pattern='^(?:'+'|'.join(re.escape(n) for n in names)+')$';executable=RUNTIME/suite
 for pair in range(1,5):
  for label in (['baseline','candidate'] if pair%2 else ['candidate','baseline']):
   folder=OUT/suite/str(pair)/label;folder.mkdir(parents=True);assert not CRITERION.exists()
   source=Q/('baseline' if label=='baseline' else 'clone-shared-v3')/'bin'/suite;shutil.copy2(source,executable)
   command=['taskset','-c','2',str(executable),'--bench',pattern,'--warm-up-time','0.3','--measurement-time','1','--sample-size','30','--nresamples','100000','--noplot']
   start=time.time();before=os.getloadavg()
   with (folder/'run.log').open('w') as log:r=subprocess.run(command,cwd=Q/'source',env=os.environ | ENV,stdout=log,stderr=subprocess.STDOUT)
   if CRITERION.exists():CRITERION.rename(folder/'criterion')
   record={'suite':suite,'pair':pair,'label':label,'revision':CONFIG['baseline'] if label=='baseline' else REVISION,
    'command':command,'start_unix':start,'seconds':time.time()-start,'exit_code':r.returncode,'directory':str(folder),
    'load_before':before,'load_after':os.getloadavg(),'binary_sha256':hashlib.sha256(executable.read_bytes()).hexdigest()}
   records.append(record);(OUT/'runs.json').write_text(json.dumps(records,indent=2)+'\n');print(suite,pair,label,r.returncode,round(record['seconds'],1),flush=True)
   if r.returncode:raise SystemExit(r.returncode)
