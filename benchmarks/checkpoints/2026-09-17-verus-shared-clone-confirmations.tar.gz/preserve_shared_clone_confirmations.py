#!/usr/bin/env python3
"""Preserve all longer repeats, including comparator movement and regressions."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

Q = Path(__file__).resolve().parent
REPO = Path('/home/tim/Documents/GitHub/workspace/hyperreal')
OUT = Q / 'clone-shared-v3-confirmations'
DEST = REPO / 'benchmarks/checkpoints'
comparison = json.loads((OUT / 'comparison.json').read_text())
config = comparison['config']
runs = json.loads((OUT / 'runs.json').read_text())
assert len(runs) == 64 and all(r['exit_code'] == 0 for r in runs)
assert len(comparison['rows']) == 236
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=Q / 'source', text=True)
identity = json.loads((Q / 'clone-shared-v3-screen/workload-identity.json').read_text())
for path, digest in identity['files'].items():
    assert hashlib.sha256((Q / 'source' / path).read_bytes()).hexdigest() == digest
for run in runs:
    side = 'baseline' if run['label'] == 'baseline' else 'clone-shared-v3'
    binary = json.loads((Q / side / 'binaries.json').read_text())[run['suite']]
    assert run['binary_sha256'] == binary['sha256']
(OUT / 'workload-identity.json').write_text(json.dumps(identity, indent=2) + '\n')
files = {p for p in OUT.rglob('*') if p.is_file()}
files.update(Q / name for name in ['confirm_shared_clone_screen.py',
    'summarize_shared_clone_confirmations.py', 'preserve_shared_clone_confirmations.py', 'run.json'])
archive = DEST / '2026-09-17-verus-shared-clone-confirmations.tar.gz'
with archive.open('wb') as output:
    with gzip.GzipFile(fileobj=output, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for path in sorted(files):
                data = path.read_bytes()
                info = tarfile.TarInfo(str(path.relative_to(Q)))
                info.size = len(data)
                info.mode = 0o644
                tar.addfile(info, io.BytesIO(data))
rows = [{key: value for key, value in row.items() if key != 'pairs'} |
        {'paired_mean_changes_percent': [p['mean_change_percent'] for p in row['pairs']]}
        for row in comparison['rows']]
report = {'schema': 1, 'status': 'follow_up_not_acceptance',
    'baseline': config['baseline'], 'candidate': config['candidate'], 'runs': len(runs),
    'pairs_per_case': 4, 'cases': len(rows), 'suites': len(config['cases']),
    'all_pairs_slower_cases': sum(row['all_pairs_slower'] for row in rows),
    'interval_method': comparison['interval_method'], 'rows': rows,
    'workload_sha256': identity['files'], 'limits': config['limits'] + [
        'All 236 positive nonoverlapping interval screen flags were followed up, including external comparators.',
        'Persistent individual regressions require investigation; no aggregate improvement establishes acceptance.',
        'Inputs with no screen flag were measured in the preceding full screen, not repeated in this selected follow-up.',
        'The unit-scale metadata shortcut and cancellation kernel drafts were not built or timed in this batch.',
        'Full proof coverage, resource assessment and downstream qualification remain incomplete.'],
    'artifact': {'path': str(archive.relative_to(REPO)), 'bytes': archive.stat().st_size,
                 'files': len(files), 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()}}
(DEST / '2026-09-17-verus-shared-clone-confirmations.json').write_text(json.dumps(report, indent=2) + '\n')
print(report['artifact'])
print('Rows slower in all four pairs:', report['all_pairs_slower_cases'])
