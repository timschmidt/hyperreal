#!/usr/bin/env python3
"""Retain paired estimates for every confirmed screen flag, without acceptance."""
import itertools,json,statistics
from pathlib import Path
Q=Path(__file__).resolve().parent;OUT=Q/'clone-shared-v3-confirmations'
config=json.loads((OUT/'config.json').read_text());runs=json.loads((OUT/'runs.json').read_text())
assert len(runs)==8*len(config['cases']) and all(r['exit_code']==0 for r in runs)
rows=[]
for suite,names in config['cases'].items():
 values={}
 for pair in range(1,5):
  values[pair]={}
  for label in ['baseline','candidate']:
   folder=OUT/suite/str(pair)/label/'criterion'
   found={json.loads(p.read_text())['full_id']:json.loads((p.parent/'estimates.json').read_text()) for p in folder.glob('**/new/benchmark.json')}
   assert set(found)==set(names),(suite,pair,label,set(found)^set(names))
   values[pair][label]=found
 for name in names:
  pairs=[]
  for pair in range(1,5):
   b=values[pair]['baseline'][name];c=values[pair]['candidate'][name]
   pairs.append({'pair':pair,'baseline_estimates':b,'candidate_estimates':c,
    'mean_change_percent':100*(c['mean']['point_estimate']/b['mean']['point_estimate']-1),
    'median_change_percent':100*(c['median']['point_estimate']/b['median']['point_estimate']-1)})
  changes=[p['mean_change_percent'] for p in pairs]
  bootstrap=sorted(statistics.median(v) for v in itertools.product(changes,repeat=4))
  def quantile(p):
   ix=p*(len(bootstrap)-1);low=int(ix);fraction=ix-low
   return bootstrap[low]*(1-fraction)+bootstrap[min(low+1,len(bootstrap)-1)]*fraction
  rows.append({'suite':suite,'case':name,'pairs':pairs,'median_paired_mean_change_percent':statistics.median(changes),
   'all_pairs_slower':all(v>0 for v in changes),'paired_median_interval':{'confidence_level':0.95,'lower_bound':quantile(.025),'upper_bound':quantile(.975)}})
rows.sort(key=lambda r:r['median_paired_mean_change_percent'],reverse=True)
report={'status':'follow_up_not_acceptance','config':config,'rows':rows,
 'interval_method':'Exact percentile bootstrap over four complete round pairs; median of within-round mean percentage changes. Small sample and uncontrolled host conditions limit inference.'}
(OUT/'comparison.json').write_text(json.dumps(report,indent=2)+'\n')
print('Confirmed',len(rows),'screen flags across',len(config['cases']),'suites')
print('All four pairs slower:',sum(r['all_pairs_slower'] for r in rows))
for r in rows[:25]:print(round(r['median_paired_mean_change_percent'],2),r['all_pairs_slower'],r['case'],[round(p['mean_change_percent'],2) for p in r['pairs']])
