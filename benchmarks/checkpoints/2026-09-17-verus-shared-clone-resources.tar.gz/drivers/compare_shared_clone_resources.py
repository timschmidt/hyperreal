#!/usr/bin/env python3
"""Compare every resource row and final artifact to the pre-Verus baseline."""
import csv,hashlib,io,json,re,subprocess,tempfile
from pathlib import Path
Q=Path(__file__).resolve().parent;OUT=Q/'shared-clone-candidate';BASE=Q/'baseline'
inputs=json.loads((OUT/'inputs.json').read_text())
def allocations(path):
 text=path.read_text();header=text.index('representation,iterations,')
 rows=list(csv.DictReader(io.StringIO(text[header:])));assert len(rows)==20
 return {r['representation']:{k:int(v) for k,v in r.items() if k!='representation'} for r in rows}
ba=allocations(BASE/'memory.csv');ca=allocations(OUT/'profiles/allocations.log');assert ba.keys()==ca.keys()
rows=[{'representation':name,'baseline':ba[name],'candidate':ca[name],
 'delta':{k:ca[name][k]-ba[name][k] for k in ba[name]}} for name in ba]
def massif(path):
 snapshots=re.findall(r'mem_heap_B=(\d+)\nmem_heap_extra_B=(\d+)\nmem_stacks_B=(\d+)',path.read_text())
 assert snapshots;values=[list(map(int,s)) for s in snapshots]
 return {k:max(v[i] for v in values) for i,k in enumerate(['heap','extra','stack'])} | {'combined_peak':max(sum(v) for v in values)}
def instructions(path):
 matches=re.findall(r'^summary: (\d+)$',path.read_text(),re.M);assert len(matches)==1
 return int(matches[0])
def size(path,temporary):
 output=subprocess.check_output(['size',str(path)],text=True);parts=output.splitlines()[1].split()
 result={k:int(v) for k,v in zip(['text','data','bss','section_total'],parts[:4])}
 result['file_bytes']=path.stat().st_size;result['sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
 headers=subprocess.check_output(['readelf','-W','-l',str(path)],text=True)
 loads=[line.split() for line in headers.splitlines() if line.lstrip().startswith('LOAD ')]
 assert loads
 result['loadable_file_bytes']=sum(int(row[4],16) for row in loads)
 result['loadable_memory_bytes']=sum(int(row[5],16) for row in loads)
 stripped=Path(temporary)/path.name
 subprocess.run(['strip','--strip-all','-o',str(stripped),str(path)],check=True)
 result['stripped_bytes']=stripped.stat().st_size;stripped.unlink()
 return result
sizes=[]
with tempfile.TemporaryDirectory(dir=OUT,prefix='strip-') as temporary:
 for p in sorted((OUT/'bin').iterdir()):
  if p.suffix=='.wasm':continue
  b=size(BASE/'bin'/p.name,temporary);c=size(p,temporary)
  sizes.append({'target':p.name,'baseline':b,'candidate':c,
   'delta':{k:c[k]-b[k] for k in b if k!='sha256'}})
dispatch={label:hashlib.sha256((folder/'dispatch_trace.md').read_bytes()).hexdigest() for label,folder in [('baseline',BASE),('candidate',OUT)]}
report={'schema':1,'baseline':inputs['baseline'],'candidate':inputs['revision'],'native_timing':False,
 'allocation_rows':rows,'massif':{'baseline':massif(BASE/'profiles/massif.out'),'candidate':massif(OUT/'profiles/massif.out')},
 'callgrind_instructions':{'baseline':instructions(BASE/'profiles/callgrind.out'),'candidate':instructions(OUT/'profiles/callgrind.out')},
 'dispatch_sha256':dispatch,'dispatch_matches_baseline':dispatch['baseline']==dispatch['candidate'],'native_sizes':sizes,
 'wasm_bytes':{label:(folder/'bin/hyperreal.wasm').stat().st_size for label,folder in [('baseline',BASE),('candidate',OUT)]},
 'limits':['The twenty-form representation workload does not establish full memory parity.','Profiler elapsed times are not native timing comparisons.','Binary and code size are lower priority than exactness, completeness, performance and memory; differences still require assessment.']}
(OUT/'resource-comparison.json').write_text(json.dumps(report,indent=2)+'\n')
for r in rows:print(r['representation'],{k:v for k,v in r['delta'].items() if v})
print('Massif:',report['massif']);print('Callgrind:',report['callgrind_instructions']);print('Wasm:',report['wasm_bytes'])
print('Dispatch equal:',report['dispatch_matches_baseline'])
for r in sizes:print(r['target'],'text delta',r['delta']['text'],'stripped delta',r['delta']['stripped_bytes'])
