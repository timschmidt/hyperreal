#!/usr/bin/env python3
"""Collect resource diagnostics separately from native timing."""
import hashlib,json,os,subprocess,time
from pathlib import Path
Q=Path(__file__).resolve().parent;OUT=Q/'shared-clone-candidate';CONFIG=json.loads((Q/'run.json').read_text())
REVISION=json.loads((OUT/'inputs.json').read_text())['revision'];ENV=CONFIG['environment'];records=[]
folder=OUT/'profiles';folder.mkdir();binary=OUT/'bin/allocation_profile'
commands=[
 ('allocations',[str(binary),'64']),
 ('callgrind',['valgrind','--tool=callgrind','--callgrind-out-file='+str(folder/'callgrind.out'),str(binary),'64']),
 ('massif',['valgrind','--tool=massif','--stacks=yes','--time-unit=B','--detailed-freq=1','--massif-out-file='+str(folder/'massif.out'),str(binary),'64']),
 ('memcheck',['valgrind','--tool=memcheck','--error-exitcode=99','--leak-check=full','--show-leak-kinds=definite,indirect','--errors-for-leak-kinds=definite,indirect',str(binary),'64']),
 ('heaptrack',['heaptrack','--output',str(folder/'heaptrack'),str(binary),'64']),
 ('dispatch',[str(OUT/'bin/dispatch_trace')]),
 ('sections',['size','-A',*[str(p) for p in sorted((OUT/'bin').iterdir()) if p.suffix!='.wasm']]),
]
for name,command in commands:
 env=os.environ | ENV
 if name=='dispatch':env.pop('HYPERREAL_SKIP_BENCHMARK_REPORTS',None)
 start=time.time()
 with (folder/(name+'.log')).open('w') as log:r=subprocess.run(command,cwd=OUT,env=env,stdout=log,stderr=subprocess.STDOUT)
 record={'revision':REVISION,'baseline':CONFIG['baseline'],'name':name,'command':command,'exit_code':r.returncode,
  'seconds':time.time()-start,'cwd':str(OUT),'environment':{k:env.get(k) for k in ENV},'native_timing':False,
  'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest() if name not in ['dispatch','sections'] else None}
 records.append(record);(OUT/'profiles.json').write_text(json.dumps(records,indent=2)+'\n');print(name,r.returncode,round(record['seconds'],1),flush=True)
if (folder/'heaptrack.zst').exists():
 with (folder/'heaptrack-summary.txt').open('w') as log:r=subprocess.run(['heaptrack_print',str(folder/'heaptrack.zst')],stdout=log,stderr=subprocess.STDOUT)
 records.append({'name':'heaptrack-summary','exit_code':r.returncode});(OUT/'profiles.json').write_text(json.dumps(records,indent=2)+'\n')
raise SystemExit(any(r['exit_code'] for r in records))
