#!/usr/bin/env python3
"""Check the small whole-process peak change at one path with exact peak tracking."""
import hashlib,json,os,shutil,subprocess,time
from pathlib import Path
Q=Path(__file__).resolve().parent;CONFIG=json.loads((Q/'run.json').read_text());OUT=Q/'shared-clone-candidate/matched-profiles-v2';OUT.mkdir()
RUNTIME=Q/'shared-clone-profile-runtime';RUNTIME.mkdir(exist_ok=True);EXE=RUNTIME/'allocation_profile';PROFILE=RUNTIME/'massif.out'
ENV=CONFIG['environment'];records=[]
for pair in range(1,3):
 for label in (['baseline','candidate'] if pair==1 else ['candidate','baseline']):
  folder=OUT/str(pair)/label;folder.mkdir(parents=True)
  source=Q/('baseline' if label=='baseline' else 'shared-clone-candidate')/'bin/allocation_profile';shutil.copy2(source,EXE)
  command=['valgrind','--tool=massif','--stacks=yes','--time-unit=B','--detailed-freq=1000','--max-snapshots=100','--peak-inaccuracy=0','--threshold=100.0','--depth=1','--massif-out-file='+str(PROFILE),str(EXE),'64']
  start=time.time()
  with (folder/'run.log').open('w') as log:r=subprocess.run(command,cwd=RUNTIME,env=os.environ | ENV,stdout=log,stderr=subprocess.STDOUT)
  if PROFILE.exists():PROFILE.rename(folder/'massif.out')
  records.append({'pair':pair,'label':label,'command':command,'cwd':str(RUNTIME),'environment':ENV,'exit_code':r.returncode,
   'seconds':time.time()-start,'native_timing':False,'binary_sha256':hashlib.sha256(EXE.read_bytes()).hexdigest()})
  (OUT/'runs.json').write_text(json.dumps(records,indent=2)+'\n');print(pair,label,r.returncode,round(time.time()-start,1),flush=True)
  if r.returncode:raise SystemExit(r.returncode)
