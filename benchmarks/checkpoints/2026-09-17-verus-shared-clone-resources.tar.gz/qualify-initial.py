#!/usr/bin/env python3
"""Complete the adopted clone candidate's non-timing build/check matrix."""
import hashlib,json,os,shutil,subprocess,time
from pathlib import Path

Q=Path(__file__).resolve().parent; SOURCE=Q/'source'; OUT=Q/'shared-clone-candidate'
CONFIG=json.loads((Q/'run.json').read_text())
REVISION=subprocess.check_output(['git','rev-parse','561e36a'],cwd=SOURCE,text=True).strip()
ENV=CONFIG['environment'] | {'CARGO_BUILD_JOBS':'4','CCACHE_DISABLE':'1','CARGO_NET_OFFLINE':'true'}
assert not subprocess.check_output(['git','status','--porcelain'],cwd=SOURCE,text=True)
OUT.mkdir();(OUT/'bin').mkdir();(OUT/'validation').mkdir()
subprocess.run(['git','checkout','--detach',REVISION],cwd=SOURCE,check=True)
tracked=subprocess.check_output(['git','ls-files','-z'],cwd=SOURCE).decode().split('\0')
inputs={p:hashlib.sha256((SOURCE/p).read_bytes()).hexdigest() for p in tracked if p and not p.startswith('benchmarks/checkpoints/')}
(OUT/'inputs.json').write_text(json.dumps({'revision':REVISION,'baseline':CONFIG['baseline'],'compiler':CONFIG['compiler'],'files':inputs},indent=2)+'\n')
records=[];binaries={}
for name,metadata in json.loads((Q/'clone-shared-v3/binaries.json').read_text()).items():
 source=Q/'clone-shared-v3/bin'/name
 assert hashlib.sha256(source.read_bytes()).hexdigest()==metadata['sha256']
 shutil.copy2(source,OUT/'bin'/name)
 binaries[name]=metadata | {'build_step':'previously qualified runtime-equivalent clone-shared-v3 overlay'}
def run(step,command,extra=None,archive=False):
 start=time.time();folder=OUT/'validation';environment=ENV | (extra or {})
 with (folder/(step+'.stdout')).open('w') as out,(folder/(step+'.stderr')).open('w') as err:
  result=subprocess.run(command,cwd=SOURCE,env=os.environ | environment,stdout=out,stderr=err)
 record={'revision':REVISION,'baseline':CONFIG['baseline'],'step':step,'command':command,'cwd':str(SOURCE),
  'environment':environment,'exit_code':result.returncode,'seconds':time.time()-start}
 records.append(record);(OUT/'validation-results.json').write_text(json.dumps(records,indent=2)+'\n')
 print(step,result.returncode,round(record['seconds'],1),flush=True)
 if archive and result.returncode==0:
  for line in (folder/(step+'.stdout')).read_text().splitlines():
   a=json.loads(line)
   if a.get('reason')!='compiler-artifact' or not a.get('executable') or a['target']['kind'] not in [['bench'],['bin'],['example']]:continue
   if step=='dispatch-build' and a['target']['name']!='dispatch_trace':continue
   source=Path(a['executable']);dest=OUT/'bin'/a['target']['name'];shutil.copy2(source,dest)
   binaries[dest.name]={'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'bytes':dest.stat().st_size,
    'features':a['features'],'target':a['target'],'build_step':step}
  (OUT/'binaries.json').write_text(json.dumps(binaries,indent=2)+'\n')
 return result.returncode

run('release-build',['cargo','build','--locked','--release','--all-features','--examples','--bins','--message-format=json'],archive=True)
run('dispatch-build',['cargo','bench','--locked','--features','dispatch-trace','--bench','dispatch_trace','--no-run','--message-format=json'],archive=True)
for step,command,extra in [
 ('check-default',['cargo','check','--locked','--all-targets'],{}),
 ('clippy-default',['cargo','clippy','--locked','--all-targets','--','-D','warnings'],{}),
 ('doc-tests-default',['cargo','test','--locked','--doc'],{}),
 ('doc-tests-all',['cargo','test','--locked','--all-features','--doc'],{}),
 ('docs-all',['cargo','doc','--locked','--all-features','--no-deps'],{'RUSTDOCFLAGS':'-D warnings'}),
 ('fuzz-check',['cargo','check','--locked','--manifest-path','fuzz/Cargo.toml','--bins'],{}),
 ('wasm-default',['cargo','build','--locked','--release','--target','wasm32-unknown-unknown','--no-default-features','--lib'],{}),
 ('wasm-all',['cargo','build','--locked','--release','--target','wasm32-unknown-unknown','--all-features','--lib','--bins'],{}),
 ('coverage-matrix',['bash','scripts/coverage.sh'],{'CARGO_TARGET_DIR':str(Q/'coverage-target')}),
 ('expanded-runtime',['cargo','+nightly','rustc','--locked','--lib','--no-default-features','--','-Zunpretty=expanded'],{'CARGO_TARGET_DIR':str(Q/'expansion-target')}),
]:
 run(step,command,extra)
 if step=='wasm-all' and records[-1]['exit_code']==0:
  wasm=Q/'target/wasm32-unknown-unknown/release/hyperreal.wasm';shutil.copy2(wasm,OUT/'bin/hyperreal.wasm')
  binaries['hyperreal.wasm']={'sha256':hashlib.sha256(wasm.read_bytes()).hexdigest(),'bytes':wasm.stat().st_size,'build_step':step}
  (OUT/'binaries.json').write_text(json.dumps(binaries,indent=2)+'\n')
 if step=='coverage-matrix' and (Q/'coverage-target/html').exists():
  shutil.copytree(Q/'coverage-target/html',OUT/'coverage-html')
 if step=='expanded-runtime' and records[-1]['exit_code']==0:
  expanded=OUT/'expanded-runtime.rs';shutil.copy2(OUT/'validation/expanded-runtime.stdout',expanded)
  count=json.loads(subprocess.check_output(['tokei','--output','json',str(expanded)],text=True))
  (OUT/'expanded-runtime-counts.json').write_text(json.dumps({'revision':REVISION,'command':command,'exit_code':0,
   'sha256':hashlib.sha256(expanded.read_bytes()).hexdigest(),'bytes':expanded.stat().st_size,
   'lines':len(expanded.read_text().splitlines()),'tokei':count},indent=2)+'\n')
status=subprocess.check_output(['git','status','--porcelain'],cwd=SOURCE,text=True)
(OUT/'validation-worktree-status.txt').write_text(status);assert not status,status
assert all(hashlib.sha256((SOURCE/p).read_bytes()).hexdigest()==h for p,h in inputs.items())
raise SystemExit(any(r['exit_code'] for r in records))
