#!/usr/bin/env python3
"""Preserve the complete original-harness timing screen and its workload identity."""
import gzip,hashlib,io,json,subprocess,tarfile
from pathlib import Path
Q=Path(__file__).resolve().parent;REPO=Path('/home/tim/Documents/GitHub/workspace/hyperreal');OUT=Q/'clone-shared-v3-screen';DEST=REPO/'benchmarks/checkpoints'
config=json.loads((OUT/'config.json').read_text());comparison=json.loads((OUT/'comparison.json').read_text())
assert comparison['total_rows']==1449 and comparison['suites']==9
assert len(comparison['runs'])==18 and all(r['exit_code']==0 for r in comparison['runs'])
assert not subprocess.check_output(['git','status','--porcelain'],cwd=Q/'source',text=True)
names=subprocess.check_output(['git','ls-files','-z','benches','promoted_slow_offenders.txt','slow_performers.txt','benchmarks.md','Cargo.lock'],cwd=Q/'source').decode().split('\0')
inputs={p:hashlib.sha256((Q/'source'/p).read_bytes()).hexdigest() for p in names if p}
for revision in config['revisions'].values():
 for p,h in inputs.items():assert hashlib.sha256(subprocess.check_output(['git','show',revision+':'+p],cwd=REPO)).hexdigest()==h,(revision,p)
(OUT/'workload-identity.json').write_text(json.dumps({'checked_after_runs':True,'files':inputs,
 'identity':'Unmodified tracked workload files match both fixed baseline and candidate revisions. All runs use report suppression and the same checkout path.'},indent=2)+'\n')
files={p for p in OUT.rglob('*') if p.is_file() and p.name!='raw.json.gz'}
files.update(Q/name for name in ['screen_shared_clone_v3.py','compare_shared_clone_v3_screen.py','preserve_shared_clone_screen.py','run.json'])
archive=DEST/'2026-09-17-verus-shared-clone-screen.tar.gz'
with archive.open('wb') as output:
 with gzip.GzipFile(fileobj=output,mode='wb',filename='',mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as tar:
   for p in sorted(files):
    data=p.read_bytes();info=tarfile.TarInfo(str(p.relative_to(Q)));info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
flags=[r for r in comparison['rows'] if r['positive_nonoverlapping_run_intervals']]
report={'schema':1,'status':'screen_only_not_acceptance','baseline':config['revisions']['baseline'],'candidate':config['revisions']['candidate'],
 'matching_rows':comparison['total_rows'],'suites':comparison['suites'],'positive_interval_flags':len(flags),'flags':flags,
 'workload_sha256':inputs,'limits':[comparison['interpretation'],*config['limits'],
  'All positive nonoverlapping screen flags, including external comparator rows, are scheduled for longer alternating repeats. None is dismissed by a suite average.'],
 'artifact':{'path':str(archive.relative_to(REPO)),'bytes':archive.stat().st_size,'files':len(files),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}}
(DEST/'2026-09-17-verus-shared-clone-screen.json').write_text(json.dumps(report,indent=2)+'\n');print(report['artifact']);print('Flagged rows',len(flags))
