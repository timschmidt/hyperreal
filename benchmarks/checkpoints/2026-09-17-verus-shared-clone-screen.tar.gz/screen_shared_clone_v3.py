#!/usr/bin/env python3
"""Run all nine Criterion inventories at identical paths against the fixed baseline."""
import hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
Q=Path(__file__).resolve().parent;CONFIG=json.loads((Q/'run.json').read_text())
if len(sys.argv)!=2:raise SystemExit('usage: screen_shared_clone_v3.py CANDIDATE_COMMIT')
REVISIONS={'baseline':CONFIG['baseline'],'candidate':sys.argv[1]}
BINARIES={'baseline':Q/'baseline/bin','candidate':Q/'clone-shared-v3/bin'}
OUT=Q/'clone-shared-v3-screen';OUT.mkdir();RUNTIME=Q/'clone-shared-v3-screen-runtime';RUNTIME.mkdir();CRITERION=RUNTIME/'criterion'
ENV=CONFIG['environment'] | {'CRITERION_HOME':str(CRITERION),'LC_ALL':'C'}
SUITES=['float_convert','borrowed_ops','real_representations','scalar_micro','numerical_micro','library_perf','gmp_api','adversarial_transcendentals','adversarial_library']
metadata=json.loads((Q/'clone-shared-v3/binaries.json').read_text())
(OUT/'config.json').write_text(json.dumps({'revisions':REVISIONS,'environment':ENV,'compiler':CONFIG['compiler'],'suites':SUITES,
 'cwd':str(Q/'source'),'patch_sha256':hashlib.sha256((Q/'clone-shared-v3/change.patch').read_bytes()).hexdigest(),
 'limits':['One short pair per complete suite; this identifies follow-ups and does not establish acceptance','Host frequency, temperature, ASLR and unrelated user activity remain uncontrolled']},indent=2)+'\n')
records=[]
for index,suite in enumerate(SUITES):
 for label in (['baseline','candidate'] if index%2==0 else ['candidate','baseline']):
  folder=OUT/suite/label;folder.mkdir(parents=True);assert not CRITERION.exists()
  executable=RUNTIME/suite;shutil.copy2(BINARIES[label]/suite,executable)
  checksum=hashlib.sha256(executable.read_bytes()).hexdigest()
  if label=='candidate':assert checksum==metadata[suite]['sha256']
  command=['taskset','-c','2',str(executable),'--bench','--warm-up-time','0.1','--measurement-time','0.2','--sample-size','10','--nresamples','10000','--noplot']
  start=time.time();before=os.getloadavg()
  with (folder/'run.log').open('w') as log:r=subprocess.run(command,cwd=Q/'source',env=os.environ | ENV,stdout=log,stderr=subprocess.STDOUT)
  if CRITERION.exists():CRITERION.rename(folder/'criterion')
  record={'suite':suite,'label':label,'revision':REVISIONS[label],'command':command,'start_unix':start,'seconds':time.time()-start,
   'exit_code':r.returncode,'load_before':before,'load_after':os.getloadavg(),'binary_sha256':checksum,'directory':str(folder)}
  records.append(record);(OUT/'runs.json').write_text(json.dumps(records,indent=2)+'\n');print(suite,label,r.returncode,round(record['seconds'],1),flush=True)
  if r.returncode:raise SystemExit(r.returncode)
