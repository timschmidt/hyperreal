#!/usr/bin/env python3
"""Retain the successful clone refinement, tests, proof and focused timings."""
import gzip,hashlib,io,itertools,json,re,statistics,subprocess,tarfile
from pathlib import Path

Q=Path(__file__).resolve().parent;REPO=Path('/home/tim/Documents/GitHub/workspace/hyperreal');DEST=REPO/'benchmarks/checkpoints'
REVISION=subprocess.check_output(['git','rev-parse','561e36a'],cwd=REPO,text=True).strip()
validation=json.loads((Q/'clone-shared-v3/validation.json').read_text())
fuzz=json.loads((Q/'clone-shared-v3-fuzz/runs.json').read_text())
assert len(validation)==10 and all(r['exit_code']==0 for r in validation)
assert len(fuzz)==6 and all(r['exit_code']==0 for r in fuzz) and sum(r['corpus_files'] for r in fuzz)==6492
hashes=next(r['source_sha256'] for r in validation if r['step']=='tests-default')
for p,h in hashes.items():assert hashlib.sha256(subprocess.check_output(['git','show',REVISION+':'+p],cwd=REPO)).hexdigest()==h,p
proof=json.loads((Q/'clone-shared-v3/proof/evidence.json').read_text())
for p,h in proof['sources'].items():assert hashlib.sha256(subprocess.check_output(['git','show',REVISION+':'+p],cwd=REPO)).hexdigest()==h,p
for name,count in [('clone-shared-v3-native',54),('clone-shared-v3-criterion',12)]:
 runs=json.loads((Q/name/'runs.json').read_text());assert len(runs)==count and all(r['exit_code']==0 for r in runs)
native=json.loads((Q/'clone-shared-v3-native/comparison.json').read_text())['comparisons']
criterion=json.loads((Q/'clone-shared-v3-criterion/comparison.json').read_text())['comparisons']
def paired_interval(values):
 # Enumerate all 6**6 bootstrap samples of complete baseline/candidate round pairs.
 medians=sorted(statistics.median(v) for v in itertools.product(values,repeat=len(values)))
 def quantile(p):
  index=p*(len(medians)-1);lower=int(index);f=index-lower
  return medians[lower]*(1-f)+medians[min(lower+1,len(medians)-1)]*f
 return {'confidence_level':0.95,'lower_bound':quantile(0.025),'upper_bound':quantile(0.975),
  'method':'Exact percentile bootstrap over six paired rounds, median of within-round Criterion mean percentage changes; host effects and temporal correlation remain uncontrolled.'}
timing=[]
for r in criterion:
 values=[p['mean_change_percent'] for p in r['pairs']]
 timing.append({'case':r['case'],'median_paired_mean_change_percent':r['median_paired_mean_change_percent'],
  'paired_mean_change_percent':values,'paired_median_interval':paired_interval(values)})
(Q/'clone-shared-v3-criterion/paired-summary.json').write_text(json.dumps(timing,indent=2)+'\n')
tests={}
for step in ['tests-default','tests-all']:
 log=(Q/'clone-shared-v3/validation'/(step+'.stdout')).read_text()
 counts=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',log)
 assert counts
 tests[step]={'passed':sum(int(x[0]) for x in counts),'failed':sum(int(x[1]) for x in counts),
  'ignored':sum(int(x[2]) for x in counts),'criterion_fixture_assertions':len(re.findall(r'^Success$',log,re.M))}
files={Q/name for name in ['run.json','saved-corpora.json','qualify_shared_clone_v3.py','replay_shared_clone_v3_corpora.py',
 'time_shared_clone_v3_probes.py','time_shared_clone_v3_criterion.py','summarize_native_probes.py','summarize_cache_criterion.py','preserve_shared_clone.py']}
for name in ['clone-shared-v3-native','clone-shared-v3-criterion']:
 files.update(p for p in (Q/name).rglob('*') if p.is_file())
files.update(p for p in (Q/'clone-shared-v3').rglob('*') if p.is_file() and 'bin' not in p.relative_to(Q/'clone-shared-v3').parts and p.name!='probe')
files.update(p for p in (Q/'clone-shared-v3-fuzz').rglob('*') if p.is_file() and 'corpus' not in p.relative_to(Q/'clone-shared-v3-fuzz').parts)
files.add(Q/'clone-shared-fix/change.patch')
archive=DEST/'2026-09-17-verus-shared-clone.tar.gz'
with archive.open('wb') as output:
 with gzip.GzipFile(fileobj=output,mode='wb',filename='',mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as tar:
   for p in sorted(files):
    data=p.read_bytes();info=tarfile.TarInfo(str(p.relative_to(Q)));info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
report={'schema':1,'status':'validated_runtime_milestone_not_acceptance','candidate':REVISION,
 'baseline':'a2da8e2b5de9a1a4653d3662f2f05cb6533fd7ef','overlay_base':'8c7484915da3f39d6a6754c7411277b2809cb467',
 'overlay_patch_sha256':hashlib.sha256((Q/'clone-shared-v3/change.patch').read_bytes()).hexdigest(),
 'source_sha256':hashes,'validation':validation,'tests':tests,'fuzz':fuzz,
 'proof':{'verification_units':363,'production_contracts':52,'model_theorems':65,'open_obligation_groups':13,
  'source_hashes_checked':len(proof['sources']),'no_cheating':True},
 'native':[{'case':r['case'],'label':r['label'],'median_paired_change_percent':r['median_paired_change_percent'],
  'paired_cycles_change_percent':[p['change_percent']['cycles:u'] for p in r['pairs']]} for r in native],
 'criterion':timing,
 'findings':['Real clones reuse the existing Arc-backed Computable graph, with the original missing-payload certificate fallback. The atomic cache accessor is inlined.',
  'The repeated original Criterion clone and cached-conversion cases improve against the immutable pre-Verus baseline. Auxiliary hardware-counter probes support these focused findings.',
  'The previously rejected variants and their semantic/formatting failures are retained separately in the square-root metadata checkpoint. This variant includes both repairs.',
  'Changed runtime source hashes match the successful isolated test/fuzz/build variant. Intervening mathematical proof additions erase from ordinary Rust; erasure evidence is retained in prior proof checkpoints.'],
 'limits':['Focused timings do not establish whole-repository parity. The complete benchmark screen, resource checks and downstream qualification remain pending at this checkpoint.',
  'The unchanged external comparator rows show host variability and are retained. Six paired rounds and bootstrap intervals cannot eliminate uncontrolled host frequency, temperature, ASLR or unrelated activity.',
  'Full implementation, caller, dependency and completeness proof obligations remain open; no 100% verification or final acceptance is claimed.'],
 'artifact':{'path':str(archive.relative_to(REPO)),'bytes':archive.stat().st_size,'files':len(files),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}}
(DEST/'2026-09-17-verus-shared-clone.json').write_text(json.dumps(report,indent=2)+'\n')
print(report['artifact']);print(tests)
