#!/usr/bin/env python3
"""Replay frozen baseline corpora with ASan on the corrected clone experiment."""
import hashlib,json,os,subprocess,tarfile,time
from pathlib import Path
Q=Path(__file__).resolve().parent;REPO=Path('/home/tim/Documents/GitHub/workspace/hyperreal');SOURCE=Q/'fuzz-source';OUT=Q/'clone-shared-v3-fuzz'
CONFIG=json.loads((Q/'run.json').read_text());INVENTORY=json.loads((Q/'saved-corpora.json').read_text())
ENV=CONFIG['environment'] | {'CCACHE_DISABLE':'1','CARGO_BUILD_JOBS':'2','ASAN_OPTIONS':'detect_leaks=0'}
assert not subprocess.check_output(['git','status','--porcelain'],cwd=SOURCE,text=True)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip()=='8c7484915da3f39d6a6754c7411277b2809cb467'
OUT.mkdir();names=['src/verified/word.rs','src/computable/node/bounds.rs','src/computable/node/tests.rs','src/computable/format.rs','src/real/arithmetic/classification.rs','src/real/arithmetic/representation.rs']
originals={name:(SOURCE/name).read_bytes() for name in names};records=[]
try:
 for name in names[:4]:(SOURCE/name).write_bytes((REPO/name).read_bytes())
 subprocess.run(['git','apply',str(Q/'clone-shared-fix/change.patch')],cwd=SOURCE,check=True)
 (OUT/'change.patch').write_bytes(subprocess.check_output(['git','diff'],cwd=SOURCE))
 hashes={name:hashlib.sha256((SOURCE/name).read_bytes()).hexdigest() for name in names}
 for target,files in INVENTORY.items():
  folder=OUT/target;(folder/'corpus').mkdir(parents=True);(folder/'artifacts').mkdir()
  with tarfile.open(REPO/'benchmarks/checkpoints/2026-09-17-verus-corpora.tar.gz') as archive:
   for name,digest in files.items():
    data=archive.extractfile(target+'/'+name).read();assert hashlib.sha256(data).hexdigest()==digest
    (folder/'corpus'/name).write_bytes(data)
  command=['cargo','+nightly','fuzz','run',target,str(folder/'corpus'),'--fuzz-dir','fuzz','--target-dir',str(Q/'fuzz-target'),'--','-runs=0','-timeout=10','-seed=93537','-artifact_prefix='+str(folder/'artifacts')+'/']
  start=time.time()
  with (folder/'run.log').open('w') as log:r=subprocess.run(command,cwd=SOURCE,env=os.environ | ENV,stdout=log,stderr=subprocess.STDOUT)
  records.append({'target':target,'command':command,'cwd':str(SOURCE),'environment':ENV,'source_sha256':hashes,'corpus_files':len(files),
    'exit_code':r.returncode,'seconds':time.time()-start,'sanitizer':'address','leak_checker_note':'LSan disabled for the previously observed ptrace limitation; ASan remains enabled.'})
  (OUT/'runs.json').write_text(json.dumps(records,indent=2)+'\n');print(target,r.returncode,round(time.time()-start,1),flush=True)
finally:
 for name,data in originals.items():(SOURCE/name).write_bytes(data)
 status=subprocess.check_output(['git','status','--porcelain'],cwd=SOURCE,text=True);(OUT/'restored-status.txt').write_text(status);assert not status,status
raise SystemExit(any(r['exit_code'] for r in records))
