#!/usr/bin/env python3
"""Balanced original Criterion call sites for the cache accessor experiment."""
import hashlib,json,os,shutil,subprocess,time
from pathlib import Path
Q=Path(__file__).resolve().parent; CONFIG=json.loads((Q/'run.json').read_text())
OUT=Q/'clone-shared-v3-criterion';OUT.mkdir()
RUNTIME=Q/'matched-clone-shared-v3-runtime';RUNTIME.mkdir()
CRITERION=RUNTIME/'criterion'
BINARIES={'baseline':Q/'baseline/bin/real_representations','shared':Q/'clone-shared-v3/bin/real_representations'}
REVISIONS={'baseline':CONFIG['baseline'],'shared':'8c7484915da3f39d6a6754c7411277b2809cb467+sqrt-bounds-display-shared-clone-and-inline'}
ORDERS=[['baseline','shared'],['shared','baseline']]*3
PATTERN=r'^real_representation_prepared/(hyperreal_clone/(pi_pow|pi)|mpfr192_clone/pi_pow|hyperreal_cached_f64/tan_pi|mpfr192_f64/tan_pi)$'
ENV=CONFIG['environment'] | {'CRITERION_HOME':str(CRITERION),'LC_ALL':'C'}
DIGESTS={label:hashlib.sha256(path.read_bytes()).hexdigest() for label,path in BINARIES.items()}
assert DIGESTS['shared']==json.loads((Q/'clone-shared-v3/binaries.json').read_text())['real_representations']['sha256']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=Q/'source',text=True)
command=['taskset','-c','2',str(RUNTIME/'real_representations'),'--bench',PATTERN,'--warm-up-time','1','--measurement-time','3','--sample-size','50','--nresamples','100000','--noplot']
(OUT/'config.json').write_text(json.dumps({'revisions':REVISIONS,'orders':ORDERS,'pattern':PATTERN,'binary_sha256':DIGESTS,'command':command,
 'environment':ENV,'cwd':str(Q/'source'),'compiler':CONFIG['compiler'],'overlay':json.loads((Q/'clone-shared-v3/probe.json').read_text()),
 'limits':['Original Criterion call sites and identical paths across variants; focused comparisons do not qualify all workloads','Host frequency, temperature, ASLR and unrelated user activity uncontrolled']},indent=2)+'\n')
records=[]
for number,order in enumerate(ORDERS,1):
 for label in order:
  folder=OUT/str(number)/label;folder.mkdir(parents=True)
  assert not CRITERION.exists()
  binary=RUNTIME/'real_representations';shutil.copy2(BINARIES[label],binary)
  assert hashlib.sha256(binary.read_bytes()).hexdigest()==DIGESTS[label]
  start=time.time();before=os.getloadavg()
  with (folder/'run.log').open('w') as log:
   result=subprocess.run(command,cwd=Q/'source',env=os.environ | ENV,stdout=log,stderr=subprocess.STDOUT)
  if CRITERION.exists():CRITERION.rename(folder/'criterion')
  record={'round':number,'label':label,'revision':REVISIONS[label],'binary_sha256':DIGESTS[label],'exit_code':result.returncode,
   'start_unix':start,'seconds':time.time()-start,'load_before':before,'load_after':os.getloadavg(),'directory':str(folder)}
  records.append(record);(OUT/'runs.json').write_text(json.dumps(records,indent=2)+'\n')
  print(number,label,result.returncode,round(record['seconds'],1),flush=True)
  if result.returncode:raise SystemExit(result.returncode)
