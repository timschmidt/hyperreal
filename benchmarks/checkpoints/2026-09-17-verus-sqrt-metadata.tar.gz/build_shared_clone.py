#!/usr/bin/env python3
"""Build an isolated shared computable clone plus inline cache accessor experiment."""
import hashlib,json,os,shutil,subprocess,time
from pathlib import Path
Q=Path(__file__).resolve().parent;SOURCE=Q/'source';OUT=Q/'clone-shared-fix'
CONFIG=json.loads((Q/'run.json').read_text());ENV=CONFIG['environment'] | {'CARGO_BUILD_JOBS':'4','CCACHE_DISABLE':'1'}
assert not subprocess.check_output(['git','status','--porcelain'],cwd=SOURCE,text=True)
OUT.mkdir();(OUT/'bin').mkdir()
paths=[SOURCE/'src/real/arithmetic/classification.rs',SOURCE/'src/real/arithmetic/representation.rs']
originals={p:p.read_text() for p in paths}
classification=originals[paths[0]]
needle='    pub(super) fn get(&self) -> PrimitiveApproxCache {'
assert classification.count(needle)==1
classification=classification.replace(needle,'    #[inline]\n'+needle)
old_comment = """        // Exact symbolic classes are small certificates for a computable value.
        // Cloning a cold `Real` in dense algebra should copy the certificate and
        // rebuild this lightweight wrapper instead of duplicating a larger
        // Computable payload whose cache is usually empty.
"""
assert classification.count(old_comment)==1
classification=classification.replace(old_comment,"""        // Materialize a missing computable payload from its exact symbolic
        // certificate. Existing immutable payloads can be shared by cloning.
""")
representation=originals[paths[1]]
start=representation.index('        // `Computable` caches are accelerators, not semantic state.')
end=representation.index('        let computable =',start)
representation=representation[:start]+"""        // Computable clones share immutable nodes and synchronized caches.
        // Reuse the payload when present, retaining the certificate fallback
        // for exact symbols whose payload has not been materialized.
"""+representation[end:]
needle='Some(self.class.computable_certificate())'
assert representation.count(needle)==1
representation=representation.replace(needle,'Some(self.computable_clone())')
records=[];binaries={}
try:
 paths[0].write_text(classification);paths[1].write_text(representation)
 (OUT/'change.patch').write_bytes(subprocess.check_output(['git','diff','--',*[str(p.relative_to(SOURCE)) for p in paths]],cwd=SOURCE))
 for step,command,cwd,extra in [
  ('probe-build',['cargo','build','--offline','--release','--message-format=json'],Q/'representation-probe',{'CARGO_TARGET_DIR':str(Q/'probe-target'),'CARGO_BUILD_JOBS':'2'}),
  ('bench-build',['cargo','bench','--locked','--offline','--features','simple','--benches','--no-run','--message-format=json'],SOURCE,{}),
 ]:
  start=time.time()
  with (OUT/(step+'.stdout')).open('w') as out,(OUT/(step+'.stderr')).open('w') as err:
   result=subprocess.run(command,cwd=cwd,env=os.environ | ENV | extra,stdout=out,stderr=err)
  record={'runtime_base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip(),
    'patch_sha256':hashlib.sha256((OUT/'change.patch').read_bytes()).hexdigest(),'step':step,'command':command,'cwd':str(cwd),'environment':ENV | extra,
    'exit_code':result.returncode,'seconds':time.time()-start}
  records.append(record);(OUT/'builds.json').write_text(json.dumps(records,indent=2)+'\n')
  print(step,result.returncode,round(record['seconds'],1),flush=True)
  if result.returncode:raise SystemExit(result.returncode)
  if step=='probe-build':
   shutil.copy2(Q/'probe-target/release/hyperreal-representation-probe',OUT/'probe')
   (OUT/'probe.json').write_text(json.dumps({'sha256':hashlib.sha256((OUT/'probe').read_bytes()).hexdigest(),'build':record},indent=2)+'\n')
  else:
   for line in (OUT/(step+'.stdout')).read_text().splitlines():
    a=json.loads(line)
    if a.get('reason')!='compiler-artifact' or not a.get('executable') or a['target']['kind']!=['bench']:continue
    dest=OUT/'bin'/a['target']['name'];shutil.copy2(a['executable'],dest)
    binaries[dest.name]={'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'bytes':dest.stat().st_size,'features':a['features'],'target':a['target']}
   (OUT/'binaries.json').write_text(json.dumps(binaries,indent=2)+'\n')
finally:
 for path,text in originals.items():path.write_text(text)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=SOURCE,text=True)
