#!/usr/bin/env python3
"""Preserve the signed-exponent proof, selected root tests and rejected experiments."""
import gzip,hashlib,io,json,tarfile,subprocess
from pathlib import Path
Q=Path(__file__).resolve().parent;REPO=Path('/home/tim/Documents/GitHub/workspace/hyperreal');DEST=REPO/'benchmarks/checkpoints'
evidence=json.loads((Q/'floor-half-proof/evidence.json').read_text())
assert all(hashlib.sha256((REPO/p).read_bytes()).hexdigest()==h for p,h in evidence['sources'].items())
selected=[r for r in json.loads((Q/'clone-shared-v3/validation.json').read_text()) if r['step'] in ['sqrt-facts','sqrt-format','sqrt-semantics']]
assert len(selected)==3 and all(r['exit_code']==0 for r in selected)
for r in selected:assert all(hashlib.sha256((REPO/p).read_bytes()).hexdigest()==h for p,h in r['source_sha256'].items())
rejections=(Q/'floor-half-proof/rejections.log').read_text();assert rejections.count('Rejected incorrect ')==69 and 'Rejected attempted assumption bypass' in rejections
files={Q/name for name in ['run.json','build_shared_clone.py','validate_shared_clone.py','qualify_shared_clone_v2.py','qualify_shared_clone_v3.py','preserve_sqrt_metadata.py']}
files.update(p for p in (Q/'floor-half-proof').rglob('*') if p.is_file())
for name in ['clone-shared-fix','clone-shared-v2']:
 for p in (Q/name).rglob('*'):
  if p.is_file() and p.name!='probe' and 'bin' not in p.relative_to(Q/name).parts:files.add(p)
for r in selected:
 for suffix in ['stdout','stderr']:files.add(Q/'clone-shared-v3/validation'/(r['step']+'.'+suffix))
archive=DEST/'2026-09-17-verus-sqrt-metadata.tar.gz'
with archive.open('wb') as output:
 with gzip.GzipFile(fileobj=output,mode='wb',filename='',mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as tar:
   for p in sorted(files):
    data=p.read_bytes();info=tarfile.TarInfo(str(p.relative_to(Q)));info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
report={'schema':1,'status':'proof_and_correctness_milestone_not_acceptance',
 'commit':subprocess.check_output(['git','rev-parse','43ab484'],cwd=REPO,text=True).strip(),'baseline':'a2da8e2b5de9a1a4653d3662f2f05cb6533fd7ef',
 'verification_units':363,'production_contracts':52,'model_theorems':65,'open_obligation_groups':13,'source_hashes_checked':111,'no_cheating':True,
 'changes':['floor_half verifies exact floor division by two for all i32 inputs, including negative odd exponents.',
  'Square-root metadata retains exactness of an exact input binade and floors negative exponents.',
  'Fixed-decimal formatting clamps its working MSD to at least zero, keeping the absolute precision request bounded even when a tiny exact MSD is already known.'],
 'selected_root_validation':selected,'mutation_rejections':69,'assumption_bypass_rejected':True,
 'experiment_failures':[
  {'variant':'shared-clone-v1','qualification':json.loads((Q/'clone-shared-fix/validation.json').read_text()),
   'finding':'Both ordinary all-target commands fail adversarial_semantics on pi*sqrt2 forms. Named Sqrt2 retains an exact MSD while the generic sqrt drops exact_msd. These commands stopped early; remaining targets did not all run.'},
  {'variant':'shared-clone-v2','qualification':json.loads((Q/'clone-shared-v2/validation.json').read_text()),
   'finding':'With sqrt metadata repaired, full default/all-feature target runs fail only disp_tiny_computable_has_bounded_demand. A newly known tiny MSD causes fixed-decimal Display to request excessive relative precision. This motivated the committed absolute-demand fix.'}],
 'limits':['The square-root binade identity and surrounding metadata invariants are not a complete Verus refinement proof; only the signed exponent kernel is newly verified.',
  'The shared-computable-clone and inline-cache overlay remains isolated and unadopted at this checkpoint.',
  'Full empirical qualification of the new runtime against the fixed baseline and the complete source/caller/dependency proof remain pending.'],
 'artifact':{'path':str(archive.relative_to(REPO)),'bytes':archive.stat().st_size,'files':len(files),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}}
(DEST/'2026-09-17-verus-sqrt-metadata.json').write_text(json.dumps(report,indent=2)+'\n');print(report['artifact'])
