#!/usr/bin/env python3
"""Validate square-root metadata first, then the combined shared-clone candidate."""
import hashlib,json,os,shutil,subprocess,time
from pathlib import Path
Q=Path(__file__).resolve().parent;REPO=Path('/home/tim/Documents/GitHub/workspace/hyperreal');SOURCE=Q/'source';OUT=Q/'clone-shared-v2'
CONFIG=json.loads((Q/'run.json').read_text());ENV=CONFIG['environment'] | {'CARGO_BUILD_JOBS':'4','CCACHE_DISABLE':'1'}
assert not subprocess.check_output(['git','status','--porcelain'],cwd=SOURCE,text=True)
OUT.mkdir();(OUT/'validation').mkdir();(OUT/'bin').mkdir()
names=['src/verified/word.rs','src/computable/node/bounds.rs','src/computable/node/tests.rs','src/real/arithmetic/classification.rs','src/real/arithmetic/representation.rs']
originals={name:(SOURCE/name).read_bytes() for name in names};records=[];binaries={}
def run(name,command,cwd=SOURCE,extra=None):
 start=time.time();folder=OUT/'validation'
 with (folder/(name+'.stdout')).open('w') as out,(folder/(name+'.stderr')).open('w') as err:
  result=subprocess.run(command,cwd=cwd,env=os.environ | ENV | (extra or {}),stdout=out,stderr=err)
 record={'step':name,'command':command,'cwd':str(cwd),'environment':ENV | (extra or {}),'runtime_base':'8c7484915da3f39d6a6754c7411277b2809cb467',
  'source_sha256':{p:hashlib.sha256((SOURCE/p).read_bytes()).hexdigest() for p in names},'exit_code':result.returncode,'seconds':time.time()-start}
 records.append(record);(OUT/'validation.json').write_text(json.dumps(records,indent=2)+'\n')
 print(name,result.returncode,round(record['seconds'],1),flush=True)
 return result.returncode
try:
 for name in names[:3]:(SOURCE/name).write_bytes((REPO/name).read_bytes())
 (OUT/'sqrt-only.patch').write_bytes(subprocess.check_output(['git','diff'],cwd=SOURCE))
 code=run('sqrt-facts',['cargo','test','--locked','--offline','--lib','rational_square_roots_retain_exact_magnitude_facts'])
 code|=run('sqrt-semantics',['cargo','test','--locked','--offline','--test','adversarial_semantics'])
 if code:raise SystemExit(1)
 subprocess.run(['git','apply',str(Q/'clone-shared-fix/change.patch')],cwd=SOURCE,check=True)
 (OUT/'change.patch').write_bytes(subprocess.check_output(['git','diff'],cwd=SOURCE))
 for name,command in [
  ('fmt',['cargo','fmt','--all','--','--check']),
  ('tests-default',['cargo','test','--locked','--offline','--all-targets','--no-fail-fast']),
  ('tests-all',['cargo','test','--locked','--offline','--all-features','--all-targets','--no-fail-fast']),
  ('representation-matrix',['bash','scripts/representation_coverage.sh']),
  ('clippy-all',['cargo','clippy','--locked','--offline','--all-features','--all-targets','--','-D','warnings']),
 ]:run(name,command)
 if any(r['exit_code'] for r in records):raise SystemExit(1)
 if run('bench-build',['cargo','bench','--locked','--offline','--features','simple','--benches','--no-run','--message-format=json']):raise SystemExit(1)
 for line in (OUT/'validation/bench-build.stdout').read_text().splitlines():
  a=json.loads(line)
  if a.get('reason')!='compiler-artifact' or not a.get('executable') or a['target']['kind']!=['bench']:continue
  dest=OUT/'bin'/a['target']['name'];shutil.copy2(a['executable'],dest)
  binaries[dest.name]={'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'bytes':dest.stat().st_size,'features':a['features'],'target':a['target']}
 (OUT/'binaries.json').write_text(json.dumps(binaries,indent=2)+'\n')
 if run('probe-build',['cargo','build','--offline','--release','--message-format=json'],Q/'representation-probe',{'CARGO_TARGET_DIR':str(Q/'probe-target'),'CARGO_BUILD_JOBS':'2'}):raise SystemExit(1)
 shutil.copy2(Q/'probe-target/release/hyperreal-representation-probe',OUT/'probe')
 (OUT/'probe.json').write_text(json.dumps({'sha256':hashlib.sha256((OUT/'probe').read_bytes()).hexdigest(),'patch_sha256':hashlib.sha256((OUT/'change.patch').read_bytes()).hexdigest(),'build':records[-1]},indent=2)+'\n')
finally:
 for name,data in originals.items():(SOURCE/name).write_bytes(data)
 status=subprocess.check_output(['git','status','--porcelain'],cwd=SOURCE,text=True);(OUT/'restored-status.txt').write_text(status);assert not status,status
