#!/usr/bin/env python3
"""Run existing correctness checks on the isolated shared-clone experiment."""
import hashlib,json,os,subprocess,time
from pathlib import Path
Q=Path(__file__).resolve().parent;SOURCE=Q/'source';OUT=Q/'clone-shared-fix';CONFIG=json.loads((Q/'run.json').read_text())
ENV=CONFIG['environment'] | {'CARGO_BUILD_JOBS':'4','CCACHE_DISABLE':'1'}
assert not subprocess.check_output(['git','status','--porcelain'],cwd=SOURCE,text=True)
paths=[SOURCE/'src/real/arithmetic/classification.rs',SOURCE/'src/real/arithmetic/representation.rs'];originals={p:p.read_bytes() for p in paths}
folder=OUT/'validation';folder.mkdir();records=[]
try:
 subprocess.run(['git','apply',str(OUT/'change.patch')],cwd=SOURCE,check=True)
 for name,command in [
  ('fmt',['cargo','fmt','--all','--','--check']),
  ('tests-default',['cargo','test','--locked','--offline','--all-targets']),
  ('tests-all',['cargo','test','--locked','--offline','--all-features','--all-targets']),
  ('representation-matrix',['bash','scripts/representation_coverage.sh']),
  ('clippy-all',['cargo','clippy','--locked','--offline','--all-features','--all-targets','--','-D','warnings']),
 ]:
  start=time.time()
  with (folder/(name+'.stdout')).open('w') as out,(folder/(name+'.stderr')).open('w') as err:
   result=subprocess.run(command,cwd=SOURCE,env=os.environ | ENV,stdout=out,stderr=err)
  record={'step':name,'command':command,'cwd':str(SOURCE),'environment':ENV,'runtime_base':'8c7484915da3f39d6a6754c7411277b2809cb467',
   'patch_sha256':hashlib.sha256((OUT/'change.patch').read_bytes()).hexdigest(),'exit_code':result.returncode,'seconds':time.time()-start}
  records.append(record);(OUT/'validation.json').write_text(json.dumps(records,indent=2)+'\n')
  print(name,result.returncode,round(record['seconds'],1),flush=True)
finally:
 for path,data in originals.items():path.write_bytes(data)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=SOURCE,text=True)
raise SystemExit(any(r['exit_code'] for r in records))
