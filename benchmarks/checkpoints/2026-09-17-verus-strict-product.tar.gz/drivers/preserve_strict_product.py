#!/usr/bin/env python3
"""Preserve strict product/separation theorems and their exact-source guards."""
import gzip,hashlib,io,json,subprocess,tarfile
from pathlib import Path
Q=Path(__file__).resolve().parent;R=Path('/home/tim/Documents/GitHub/workspace/hyperreal');O=Q/'strict-product-proof';D=R/'benchmarks/checkpoints';identity=json.loads((O/'runtime-identity.json').read_text());REV=identity['proof_revision']
e=json.loads((O/'official/evidence.json').read_text());assert e['verification_results']['verified']==610 and e['verification_results']['success']
for n,h in e['sources'].items():assert hashlib.sha256(subprocess.check_output(['git','show',REV+':'+n],cwd=R)).hexdigest()==h,n
log=(O/'guards.log').read_text();assert log.count('Rejected incorrect')==10 and 'Rejected attempted assumption bypass' in log
assert 'Ran 10 tests' in (O/'acceptance-tests.log').read_text() and '\nOK\n' in (O/'acceptance-tests.log').read_text();assert identity['all_production_and_manifest_bytes_unchanged']
files=[(p,str(p.relative_to(Q))) for p in O.rglob('*') if p.is_file()]
for package in e['dependencies']['packages']:
 source=Path(package['manifest_path']).parent
 for n,h in e['dependencies']['sources'][package['id']].items():
  p=source/n;assert hashlib.sha256(p.read_bytes()).hexdigest()==h;files.append((p,'dependency-sources/'+package['name']+'-'+package['version']+'/'+n))
for n in ['preserve_strict_product.py','run_strict_product_guards.py']:files.append((Q/n,'drivers/'+n))
archive=D/'2026-09-17-verus-strict-product.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as tar:
   for p,n in sorted(files,key=lambda r:r[1]):
    data=p.read_bytes();info=tarfile.TarInfo(n);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
report={'schema':1,'status':'conditional_strict_error_model_milestone_not_implementation_proof','baseline':'a2da8e2b5de9a1a4653d3662f2f05cb6533fd7ef','proof_revision':REV,'runtime_reference':identity['runtime_reference'],
 'verification':{'units':610,'production_contracts':94,'model_theorems':118,'source_hashes':len(e['sources']),'all_match_commit':True,'no_cheating':True,'entire_target':True,'open_obligation_groups':13},
 'changes':['Asymmetric pre-rounding product error is strictly below half a unit when the sampled other operand lies inside its open magnitude bound.','The complete asymmetric mathematical schedule then has error strictly below one unit after rounding.','Two strict one-unit operand approximations separated by at least two integers certify strict real ordering.','Explicit exact-zero and positive/negative halfway checks retain the signed-rounding convention and stabilize its mutation diagnostics.'],
 'guards':{'fresh_product_and_order_mutations_rejected':10,'new_cases':3,'attempted_assumption_bypass_rejected':True,'acceptance_and_dependency_tests':10,'full_combined_suite_rerun':False,'failed_preparations_preserved':'One mutation run reached a resource limit. An initial compute proof could not unfold the opaque power definition. Both failed logs are retained; the final proof and all ten arithmetic rejections pass with no resource-limit acceptance.'},
 'runtime':{'all_production_manifest_lock_bytes_unchanged':True,'proof_only_change':True},
 'limits':['Every input error and magnitude condition remains an explicit mathematical premise. All production callers must still establish it.','The order theorem deliberately requires strict input bounds; inclusive one-unit bounds alone do not certify the two-integer comparison gap. No empirical wrong-order counterexample is asserted here.','BigInt operations, graph and cache denotations, finite precision arithmetic and other open obligations remain unverified.','The frozen runtime allocation experiment remains unadopted and separately measured. Baseline acceptance remains pending.'],
 'artifact':{'path':str(archive.relative_to(R)),'files':len(files),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}}
(D/'2026-09-17-verus-strict-product.json').write_text(json.dumps(report,indent=2)+'\n');print(report['artifact'])
