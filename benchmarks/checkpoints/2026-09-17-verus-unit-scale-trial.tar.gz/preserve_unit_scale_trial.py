#!/usr/bin/env python3
"""Retain the unadopted unit-only shortcut, including its non-unit regressions."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile

Q = Path(__file__).resolve().parent
REPO = Path('/home/tim/Documents/GitHub/workspace/hyperreal')
DEST = REPO / 'benchmarks/checkpoints'
EXPERIMENT = Q / 'unit-scale-facts-experiment'
OUT = Q / 'unit-scale-facts-timings'
comparison = json.loads((OUT / 'comparison.json').read_text())
runs = json.loads((OUT / 'runs.json').read_text())
checks = json.loads((EXPERIMENT / 'bounded/validation.json').read_text())
assert len(runs) == 18 and all(r['exit_code'] == 0 for r in runs)
assert len(comparison['rows']) == 17
assert all(r['exit_code'] == 0 for r in checks)
assert not (EXPERIMENT / 'bounded/restored-status.txt').read_text()
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=Q / 'source', text=True)
metrics = {}
for step in ['tests-default', 'tests-all']:
    content = (EXPERIMENT / 'bounded/validation' / (step + '.stdout')).read_text()
    results = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', content)
    metrics[step] = {'test_executions': sum(int(a) for a, b, c in results),
                     'ignored': sum(int(c) for a, b, c in results),
                     'criterion_fixtures': len(re.findall(r'^Success$', content, re.M))}
files = set()
for folder in [OUT, EXPERIMENT / 'bounded', EXPERIMENT / 'bounded-invalid-oracle']:
    files.update(path for path in folder.rglob('*') if path.is_file() and 'bin' not in path.relative_to(folder).parts)
files.update(Q / name for name in ['time_unit_scale_facts.py', 'qualify_unit_scale_facts.py', 'preserve_unit_scale_trial.py', 'run.json'])
files.update(EXPERIMENT / name for name in ['bounded-check.patch', 'plan.json'])
archive = DEST / '2026-09-17-verus-unit-scale-trial.tar.gz'
with archive.open('wb') as output:
    with gzip.GzipFile(fileobj=output, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for path in sorted(files):
                data = path.read_bytes()
                info = tarfile.TarInfo(str(path.relative_to(Q)))
                info.size = len(data)
                info.mode = 0o644
                tar.addfile(info, io.BytesIO(data))
report = {'schema': 1, 'status': 'unadopted_nonunit_regressions',
    'baseline': 'a2da8e2b5de9a1a4653d3662f2f05cb6533fd7ef',
    'runtime_base': '561e36a6df4a91e9ede58a74eaea64dad0370238',
    'candidate': 'runtime base plus bounded-check.patch and the two magnitude-oracle tests',
    'runs': len(runs), 'cases': len(comparison['rows']), 'orders': comparison['config']['orders'],
    'rows': comparison['rows'], 'interval_method': comparison['interval_method'],
    'validation': checks, 'test_metrics': metrics,
    'decision': 'Keep unadopted: unit-scaled queries improve, while tau and the non-unit dense expression regress. Improvements do not dismiss those individual regressions.',
    'limits': comparison['config']['limits'] + [
        'The initial oracle failed to compile because its integer argument types did not match the existing API. Corrected tests and all subsequent checks pass; both attempts are retained.',
        'No formal proof of the surrounding real-magnitude semantics is claimed.',
        'The qualifier driver was subsequently extended for a separate, unbuilt comparison-reuse experiment; recorded patches, source hashes, commands and raw outputs identify this completed bounded trial.',
        'The production cancellation kernel remains a separate runtime; this experiment does not qualify it.'],
    'artifact': {'path': str(archive.relative_to(REPO)), 'bytes': archive.stat().st_size,
                 'files': len(files), 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()}}
(DEST / '2026-09-17-verus-unit-scale-trial.json').write_text(json.dumps(report, indent=2) + '\n')
print(report['artifact'])
