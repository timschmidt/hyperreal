#!/usr/bin/env python3
"""Qualify a unit-scale shortcut in isolation, after native timing has ended."""
import hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
Q=Path(__file__).resolve().parent;SOURCE=Q/'source';CONFIG=json.loads((Q/'run.json').read_text())
if len(sys.argv)!=2 or sys.argv[1] not in ['comparison','bounded','reuse']:raise SystemExit('usage: qualify_unit_scale_facts.py comparison|bounded|reuse')
variant=sys.argv[1];BASE='561e36a6df4a91e9ede58a74eaea64dad0370238';ROOT=Q/'unit-scale-facts-experiment';OUT=ROOT/variant
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip()==BASE
assert not subprocess.check_output(['git','status','--porcelain'],cwd=SOURCE,text=True)
OUT.mkdir();(OUT/'validation').mkdir();(OUT/'bin').mkdir()
names=['src/real/arithmetic/facts.rs','src/rational/arithmetic/queries_conversion.rs','src/real/arithmetic/tests.rs','src/rational/arithmetic/tests.rs']
originals={n:(SOURCE/n).read_bytes() for n in names};records=[];binaries={}
ENV=CONFIG['environment'] | {'CARGO_BUILD_JOBS':'4','CCACHE_DISABLE':'1','CARGO_NET_OFFLINE':'true'}
def record_json(name,value):
 path=OUT/name;temporary=path.with_suffix(path.suffix+'.next');temporary.write_text(json.dumps(value,indent=2)+'\n');temporary.replace(path)
def run(step,command):
 start=time.time();folder=OUT/'validation'
 with (folder/(step+'.stdout')).open('w') as out,(folder/(step+'.stderr')).open('w') as err:
  result=subprocess.run(command,cwd=SOURCE,env=os.environ | ENV,stdout=out,stderr=err)
 record={'step':step,'command':command,'cwd':str(SOURCE),'environment':ENV,'runtime_base':BASE,
  'source_sha256':{n:hashlib.sha256((SOURCE/n).read_bytes()).hexdigest() for n in names},'exit_code':result.returncode,'seconds':time.time()-start}
 records.append(record);record_json('validation.json',records);print(step,result.returncode,round(record['seconds'],1),flush=True)
 return result.returncode
test='''
    #[test]
    fn radical_magnitude_facts_follow_signed_binary_scales() {
        for (radicand, root_msd) in [(2, 0), (3, 0), (5, 1), (7, 1)] {
            let root = Real::from(radicand).sqrt().unwrap();
            for shift in -8_i32..=8 {
                let scale = if shift >= 0 {
                    Rational::new(1_i64 << shift)
                } else {
                    Rational::fraction(1, 1_u64 << -shift).unwrap()
                };
                for scale in [scale.clone(), -scale] {
                    let expected_sign = if scale.sign() == Sign::Minus {
                        RealSign::Negative
                    } else {
                        RealSign::Positive
                    };
                    let value = &root * &Real::new(scale);
                    let facts = value.structural_facts();
                    assert_eq!(facts.sign, Some(expected_sign));
                    assert_eq!(facts.magnitude, Some(MagnitudeBits {
                        msd: root_msd + shift,
                        exact_msd: true,
                    }));
                }
            }
        }
    }

    #[test]
    fn radical_magnitude_facts_preserve_lazy_and_wide_scales() {
        let root = Real::from(2).sqrt().unwrap();
        for common_bits in [0_usize, 129, 257, 1025] {
            let common = (BigUint::from(1_u8) << common_bits) + 1_u8;
            for (numerator, denominator, msd, exact_msd) in [
                (1_u8, 1_u8, 0, true),
                (2, 1, 1, true),
                (1, 2, -1, true),
                (3, 2, 0, false),
                (2, 3, -1, false),
                (5, 4, 0, false),
            ] {
                for sign in [Sign::Plus, Sign::Minus] {
                    // Keep lazy storage intact rather than having multiplication
                    // canonicalize the test input before the facts query.
                    let mut value = root.clone();
                    value.rational = Rational::from_parts_raw_unreduced(
                        sign, &common * numerator, &common * denominator,
                    );
                    let facts = value.structural_facts();
                    assert_eq!(facts.sign, Some(if sign == Sign::Plus {
                        RealSign::Positive
                    } else {
                        RealSign::Negative
                    }));
                    assert_eq!(facts.magnitude, Some(MagnitudeBits { msd, exact_msd }));
                }
            }
        }
        for shift in [-257_i32, 257] {
            let power = BigUint::from(1_u8) << shift.unsigned_abs() as usize;
            let (numerator, denominator) = if shift > 0 {
                (power, BigUint::from(1_u8))
            } else {
                (BigUint::from(1_u8), power)
            };
            let mut value = root.clone();
            value.rational = Rational::from_parts_raw_unreduced(Sign::Plus, numerator, denominator);
            assert_eq!(value.structural_facts().magnitude, Some(MagnitudeBits {
                msd: shift, exact_msd: true,
            }));
        }
    }
'''
try:
 p=SOURCE/'src/real/arithmetic/tests.rs';before=p.read_text();anchor='    use std::mem::size_of;\n';assert before.count(anchor)==1;p.write_text(before.replace(anchor,anchor+test))
 if variant=='reuse':
  p=SOURCE/'src/rational/arithmetic/tests.rs';before=p.read_text();assert before.count(anchor)==1;p.write_text(before.replace(anchor,anchor+(Q/'rational_magnitude_oracle_draft.rs').read_text()))
  if run('rational-oracle-reference',['cargo','test','--locked','--offline','--lib','rational_magnitude_certificate_matches_exact_intervals']):raise SystemExit(1)
 if run('oracle-reference',['cargo','test','--locked','--offline','--lib','radical_magnitude_facts_']):raise SystemExit(1)
 patch=ROOT/{'comparison':'change.patch','bounded':'bounded-check.patch','reuse':'reuse-comparison.patch'}[variant];subprocess.run(['git','apply',str(patch)],cwd=SOURCE,check=True)
 if variant=='reuse':
  p=SOURCE/'src/rational/arithmetic/tests.rs';before=p.read_text();expression='value.msd_exact().map(|msd| (msd, value.power_of_two_shift().is_some()))';assert before.count(expression)==1;p.write_text(before.replace(expression,'value.msd_exact_with_power_of_two()'))
 if run('format-overlay',['cargo','fmt','--all']):raise SystemExit(1)
 changed=subprocess.check_output(['git','diff','--name-only'],cwd=SOURCE,text=True).splitlines();assert set(changed)<=set(names),changed
 (OUT/'change.patch').write_bytes(subprocess.check_output(['git','diff'],cwd=SOURCE))
 if variant=='reuse' and run('rational-oracle-candidate',['cargo','test','--locked','--offline','--lib','rational_magnitude_certificate_matches_exact_intervals']):raise SystemExit(1)
 for step,command in [
  ('oracle-candidate',['cargo','test','--locked','--offline','--lib','radical_magnitude_facts_']),
  ('tests-default',['cargo','test','--locked','--offline','--all-targets','--no-fail-fast']),
  ('tests-all',['cargo','test','--locked','--offline','--all-features','--all-targets','--no-fail-fast']),
  ('representation-matrix',['bash','scripts/representation_coverage.sh']),
  ('clippy-all',['cargo','clippy','--locked','--offline','--all-features','--all-targets','--','-D','warnings']),
 ]:run(step,command)
 if any(r['exit_code'] for r in records):raise SystemExit(1)
 if run('bench-build',['cargo','bench','--locked','--offline','--features','simple','--benches','--no-run','--message-format=json']):raise SystemExit(1)
 for line in (OUT/'validation/bench-build.stdout').read_text().splitlines():
  a=json.loads(line)
  if a.get('reason')!='compiler-artifact' or not a.get('executable') or a['target']['kind']!=['bench']:continue
  dest=OUT/'bin'/a['target']['name'];shutil.copy2(a['executable'],dest)
  binaries[dest.name]={'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'bytes':dest.stat().st_size,'features':a['features'],'target':a['target']}
 record_json('binaries.json',binaries)
finally:
 for n,data in originals.items():(SOURCE/n).write_bytes(data)
 status=subprocess.check_output(['git','status','--porcelain'],cwd=SOURCE,text=True);(OUT/'restored-status.txt').write_text(status);assert not status,status
