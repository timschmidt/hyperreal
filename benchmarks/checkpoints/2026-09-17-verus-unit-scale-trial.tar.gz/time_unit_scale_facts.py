#!/usr/bin/env python3
"""Balanced original-harness comparison of the isolated metadata shortcut."""
import hashlib
import itertools
import json
import os
from pathlib import Path
import re
import shutil
import statistics
import subprocess
import time

Q = Path(__file__).resolve().parent
CONFIG = json.loads((Q / 'run.json').read_text())
OUT = Q / 'unit-scale-facts-timings'
RUNTIME = Q / 'unit-scale-facts-runtime'
OUT.mkdir()
RUNTIME.mkdir()
CRITERION = RUNTIME / 'criterion'
variants = {
    'baseline': {'revision': CONFIG['baseline'], 'folder': 'baseline'},
    'shared': {'revision': '561e36a6df4a91e9ede58a74eaea64dad0370238', 'folder': 'clone-shared-v3'},
    'bounded': {'revision': '561e36a6df4a91e9ede58a74eaea64dad0370238+bounded-unit-overlay', 'folder': 'unit-scale-facts-experiment/bounded'},
}
cases = ['structural_query_speed/' + name + '_' + query
         for name in ['one', 'pi', 'e', 'tau', 'sqrt_two', 'dense_expr']
         for query in ['structural_facts', 'detailed_facts']]
cases += ['structural_query_speed/sqrt_two_msd_query', 'construction_speed/rational_from_i8_minus_four',
          'symbolic_reductions/inverse_pi', 'symbolic_reductions/mul_pi_e_sqrt_two',
          'pure_scalar_algorithm_speed/rational_mul']
orders = [list(order) for order in itertools.permutations(variants)]
ENV = CONFIG['environment'] | {'CRITERION_HOME': str(CRITERION), 'LC_ALL': 'C'}
for label, item in variants.items():
    path = Q / item['folder'] / 'bin/scalar_micro'
    item['sha256'] = hashlib.sha256(path.read_bytes()).hexdigest()
    metadata = json.loads((Q / item['folder'] / 'binaries.json').read_text())['scalar_micro']
    assert metadata['sha256'] == item['sha256']
    item['features'] = metadata['features']
    assert item['features'] == ['default', 'simple']
pattern = '^(?:' + '|'.join(re.escape(name) for name in cases) + ')$'
command = ['taskset', '-c', '2', str(RUNTIME / 'scalar_micro'), '--bench', pattern,
           '--warm-up-time', '0.3', '--measurement-time', '1', '--sample-size', '30', '--nresamples', '100000', '--noplot']
config = {'variants': variants, 'orders': orders, 'cases': cases, 'command': command,
          'cwd': str(Q / 'source'), 'environment': ENV, 'compiler': CONFIG['compiler'],
          'limits': ['All six three-variant orders at identical executable and Criterion paths.',
                     'Host frequency, thermal state, ASLR and unrelated user activity are uncontrolled.',
                     'The bounded overlay is based on 561e36a; the newer cancellation kernel is outside this isolated comparison.',
                     'Focused investigation, not whole-repository acceptance.']}
(OUT / 'config.json').write_text(json.dumps(config, indent=2) + '\n')
runs = []
for round_, order in enumerate(orders, 1):
    for label in order:
        folder = OUT / str(round_) / label
        folder.mkdir(parents=True)
        assert not CRITERION.exists()
        shutil.copy2(Q / variants[label]['folder'] / 'bin/scalar_micro', RUNTIME / 'scalar_micro')
        before = os.getloadavg()
        start = time.time()
        with (folder / 'run.log').open('w') as output:
            result = subprocess.run(command, cwd=Q / 'source', env=os.environ | ENV, stdout=output, stderr=subprocess.STDOUT)
        if CRITERION.exists():
            CRITERION.rename(folder / 'criterion')
        runs.append({'round': round_, 'label': label, 'revision': variants[label]['revision'],
                     'command': command, 'exit_code': result.returncode, 'start_unix': start, 'seconds': time.time() - start,
                     'load_before': before, 'load_after': os.getloadavg(), 'binary_sha256': variants[label]['sha256']})
        pending = OUT / 'runs.next.json'
        pending.write_text(json.dumps(runs, indent=2) + '\n')
        pending.replace(OUT / 'runs.json')
        print(round_, label, result.returncode, round(time.time() - start, 1), flush=True)
        if result.returncode:
            raise SystemExit(result.returncode)
estimates = {}
for round_ in range(1, 7):
    estimates[round_] = {}
    for label in variants:
        found = {json.loads(path.read_text())['full_id']: json.loads((path.parent / 'estimates.json').read_text())
                 for path in (OUT / str(round_) / label / 'criterion').glob('**/new/benchmark.json')}
        assert set(found) == set(cases)
        estimates[round_][label] = found
rows = []
for name in cases:
    row = {'case': name}
    for reference in ['baseline', 'shared']:
        changes = [100 * (estimates[i]['bounded'][name]['mean']['point_estimate'] /
                          estimates[i][reference][name]['mean']['point_estimate'] - 1) for i in range(1, 7)]
        bootstrap = sorted(statistics.median(sample) for sample in itertools.product(changes, repeat=6))
        def quantile(p):
            position = p * (len(bootstrap) - 1)
            lower = int(position)
            part = position - lower
            return bootstrap[lower] * (1 - part) + bootstrap[min(lower + 1, len(bootstrap) - 1)] * part
        row['versus_' + reference] = {'paired_mean_changes_percent': changes,
            'median': statistics.median(changes), 'all_slower': all(change > 0 for change in changes),
            'all_faster': all(change < 0 for change in changes),
            'paired_median_interval': {'confidence_level': 0.95, 'lower_bound': quantile(.025), 'upper_bound': quantile(.975)}}
    rows.append(row)
report = {'status': 'focused_follow_up_not_acceptance', 'config': config, 'rows': rows,
          'interval_method': 'Exact percentile bootstrap of median percentage changes over six complete round pairs.'}
(OUT / 'comparison.json').write_text(json.dumps(report, indent=2) + '\n')
for row in rows:
    print(row['case'], 'vs baseline', round(row['versus_baseline']['median'], 2),
          'vs shared', round(row['versus_shared']['median'], 2), flush=True)
